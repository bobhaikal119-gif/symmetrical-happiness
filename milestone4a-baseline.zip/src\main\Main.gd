extends Node2D

class_name Main

signal game_started()
signal game_paused()
signal game_resumed()
signal game_over()

const CAMERA_SHAKE_DURATION: float = 0.28
const ITEM_PICKUP_SCENE: PackedScene = preload("res://src/entities/items/ItemPickup.tscn")

@export var world_seed: int = 12345

@onready var world_generator: WorldGenerator = $WorldGenerator as WorldGenerator
@onready var world_renderer: WorldRenderer = $WorldRenderer as WorldRenderer
@onready var player: Player = $Player as Player
@onready var camera: Camera2D = $Camera2D as Camera2D
@onready var machine_container: Node2D = $MachineContainer as Node2D
@onready var enemy_container: Node2D = $EnemyContainer as Node2D
@onready var item_container: Node2D = $ItemContainer as Node2D
@onready var storm_wave_director: StormWaveDirector = $StormWaveDirector as StormWaveDirector
@onready var canvas_modulate: CanvasModulate = $CanvasModulate as CanvasModulate

var world_grid: WorldGrid
var power_grid: PowerGridSystem
var structural_integrity: StructuralIntegritySystem

var _signal_bus: SignalBus
var _camera_shake_tween: Tween
var _last_depth: int = -1
var _last_biome: String = ""
var _power_recalculation_queued: bool = false
var _checking_structural_integrity: bool = false
var _machine_grid_positions: Dictionary = {}
var _power_sync_elapsed: float = 0.0


func _ready() -> void:
	_signal_bus = SignalBus.get_instance()
	_connect_signals_once()
	_initialize_world()
	_initialize_simulation_systems()
	_initialize_player()
	_initialize_scene_nodes()
	GlobalGameState.reset()
	_update_player_depth(true)
	game_started.emit()


func _process(delta: float) -> void:
	if not is_instance_valid(player):
		return
	camera.global_position = player.global_position
	GlobalGameState.set_player_position(player.global_position)
	_update_player_depth(false)
	_power_sync_elapsed += delta
	if _power_sync_elapsed >= 0.25:
		_power_sync_elapsed = 0.0
		_synchronize_machine_power_nodes()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		toggle_pause()
		get_viewport().set_input_as_handled()


func _connect_signals_once() -> void:
	if not _signal_bus.tile_broken.is_connected(_on_tile_broken):
		_signal_bus.tile_broken.connect(_on_tile_broken)
	if not _signal_bus.tile_placed.is_connected(_on_tile_placed):
		_signal_bus.tile_placed.connect(_on_tile_placed)
	if not _signal_bus.structure_placed.is_connected(_on_structure_placed):
		_signal_bus.structure_placed.connect(_on_structure_placed)
	if not _signal_bus.cave_in_triggered.is_connected(_on_cave_in_triggered):
		_signal_bus.cave_in_triggered.connect(_on_cave_in_triggered)
	if not _signal_bus.player_died.is_connected(_on_player_died):
		_signal_bus.player_died.connect(_on_player_died)
	if not machine_container.child_entered_tree.is_connected(_on_machine_added):
		machine_container.child_entered_tree.connect(_on_machine_added)
	if not machine_container.child_exiting_tree.is_connected(_on_machine_removed):
		machine_container.child_exiting_tree.connect(_on_machine_removed)


func _initialize_world() -> void:
	world_grid = WorldGrid.new(world_seed)
	world_generator.seed = world_seed
	world_generator.generate(world_grid)
	world_renderer.world_grid = world_grid
	world_renderer.sync_all_tiles()


func _initialize_simulation_systems() -> void:
	power_grid = PowerGridSystem.new()
	_set_property_if_present(power_grid, &"world_grid", world_grid)
	_set_property_if_present(power_grid, &"signal_bus", _signal_bus)
	_invoke_setup_with_dependencies(power_grid)

	if power_grid.has_signal(&"network_totals_updated"):
		var totals_callable: Callable = _on_network_totals_updated
		if not power_grid.is_connected(&"network_totals_updated", totals_callable):
			power_grid.connect(&"network_totals_updated", totals_callable)

	structural_integrity = StructuralIntegritySystem.new(world_grid, _signal_bus)
	storm_wave_director.setup(player, world_grid, enemy_container)

	for machine: Node in machine_container.get_children():
		_configure_machine(machine)
	_recalculate_power_grid()


func _initialize_player() -> void:
	if player == null:
		push_error("Main requires the Player scene instance.")
		return

	var oxygen: OxygenComponent = player.get_node_or_null("OxygenComponent") as OxygenComponent
	if oxygen == null:
		oxygen = OxygenComponent.new()
		oxygen.name = "OxygenComponent"
		player.add_child(oxygen)
	_set_property_if_present(oxygen, &"world_grid", world_grid)

	var crafting: CraftingComponent = player.get_node_or_null("CraftingComponent") as CraftingComponent
	if crafting == null:
		crafting = CraftingComponent.new()
		crafting.name = "CraftingComponent"
		player.add_child(crafting)
	_set_property_if_present(crafting, &"signal_bus", _signal_bus)
	_set_property_if_present(crafting, &"recipe_registry", RecipeRegistry.get_instance())
	_set_property_if_present(crafting, &"item_registry", ItemRegistry.get_instance())

	var placement: PlacementComponent = player.get_node_or_null("PlacementComponent") as PlacementComponent
	if placement == null:
		placement = PlacementComponent.new()
		placement.name = "PlacementComponent"
		player.add_child(placement)
	_set_property_if_present(placement, &"signal_bus", _signal_bus)
	_set_property_if_present(placement, &"world_grid", world_grid)
	_set_property_if_present(placement, &"power_grid", power_grid)
	_set_property_if_present(placement, &"oxygen", oxygen)
	_set_property_if_present(placement, &"crafting", crafting)
	_set_property_if_present(placement, &"machine_parent", machine_container)
	_set_property_if_present(placement, &"structure_parent", machine_container)

	_set_property_if_present(player, &"oxygen", oxygen)
	_set_property_if_present(player, &"crafting", crafting)
	_set_property_if_present(player, &"placement", placement)

	_inject_player_component_dependencies(player)
	player.global_position = world_grid.find_safe_spawn()
	if _signal_bus.has_signal(&"player_spawned"):
		_signal_bus.emit_signal(&"player_spawned", player.global_position)


func _initialize_scene_nodes() -> void:
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
	camera.offset = Vector2.ZERO
	camera.global_position = player.global_position
	canvas_modulate.color = Color(0.12, 0.14, 0.19, 1.0)


func _inject_player_component_dependencies(root: Node) -> void:
	for child: Node in root.get_children():
		_set_property_if_present(child, &"world_grid", world_grid)
		_set_property_if_present(child, &"power_grid", power_grid)
		_set_property_if_present(child, &"machine_parent", machine_container)
		_invoke_setup_with_dependencies(child)
		_inject_player_component_dependencies(child)


func _configure_machine(machine: Node) -> void:
	if not is_instance_valid(machine):
		return
	var already_configured: bool = bool(machine.get_meta(&"deepwell_main_configured", false))
	machine.add_to_group(&"base_structures")
	machine.add_to_group(&"base_targets")
	machine.add_to_group(&"machines")
	_set_property_if_present(machine, &"world_grid", world_grid)
	_set_property_if_present(machine, &"power_grid", power_grid)
	_set_property_if_present(machine, &"signal_bus", _signal_bus)
	_set_property_if_present(machine, &"grid_pos", _grid_position_for_node(machine))
	if not already_configured:
		_invoke_setup_with_dependencies(machine)
		machine.set_meta(&"deepwell_main_configured", true)
	_register_or_update_machine_power(machine)
	_schedule_power_grid_recalculation()


func _on_machine_added(machine: Node) -> void:
	_configure_machine(machine)


func _on_machine_removed(machine: Node) -> void:
	_unregister_machine_power(machine)
	_schedule_power_grid_recalculation()


func _on_tile_broken(grid_pos: Vector2i, tile_id: int) -> void:
	_spawn_mined_item(grid_pos, tile_id)
	if structural_integrity != null and not _checking_structural_integrity:
		_checking_structural_integrity = true
		structural_integrity.check_tile_break(grid_pos.x, grid_pos.y, tile_id)
		_checking_structural_integrity = false
	_schedule_power_grid_recalculation()


func _spawn_mined_item(grid_pos: Vector2i, tile_id: int) -> void:
	var item_id: String = _tile_id_to_item_id(tile_id)
	if item_id.is_empty() or ITEM_PICKUP_SCENE == null:
		return
	var pickup := ITEM_PICKUP_SCENE.instantiate() as ItemPickup
	if pickup == null:
		return
	pickup.setup(item_id, 1)
	pickup.global_position = Vector2(grid_pos * WorldGrid.TILE_SIZE) + Vector2.ONE * (WorldGrid.TILE_SIZE * 0.5)
	item_container.add_child(pickup)


func _tile_id_to_item_id(tile_id: int) -> String:
	match tile_id:
		WorldGrid.TILE_STONE: return "stone"
		WorldGrid.TILE_IRON_ORE: return "iron_ore"
		WorldGrid.TILE_COAL: return "coal"
		WorldGrid.TILE_COPPER: return "copper_ore"
		WorldGrid.TILE_QUARTZ: return "quartz"
		WorldGrid.TILE_TITANIUM: return "titanium"
		WorldGrid.TILE_SUPPORT_BEAM: return "support_beam"
		WorldGrid.TILE_POWER_CABLE: return "power_cable"
		_: return ""


func _on_tile_placed(_grid_pos: Vector2i, _tile_id: int) -> void:
	_schedule_power_grid_recalculation()


func _on_structure_placed(_grid_pos: Vector2i, _item_id: String) -> void:
	call_deferred(&"_refresh_machines_and_power")


func _refresh_machines_and_power() -> void:
	for machine: Node in machine_container.get_children():
		_configure_machine(machine)
	_schedule_power_grid_recalculation()


func _schedule_power_grid_recalculation() -> void:
	if _power_recalculation_queued:
		return
	_power_recalculation_queued = true
	call_deferred(&"_recalculate_power_grid")


func _recalculate_power_grid() -> void:
	_power_recalculation_queued = false
	if power_grid == null:
		return
	for method_name: StringName in [
		&"recalculate_networks",
		&"recalculate_power_grid",
		&"recalculate",
		&"rebuild_networks",
		&"refresh_networks",
		&"update_networks",
	]:
		if _invoke_method_with_dependencies(power_grid, method_name):
			return


func _on_network_totals_updated(totals: Dictionary) -> void:
	var produced_watts: float = float(totals.get("produced_watts", 0.0))
	var demand_watts: float = float(totals.get("demand_watts", 0.0))
	var efficiency: float = float(totals.get("efficiency", 1.0))
	_signal_bus.power_grid_updated.emit(produced_watts, demand_watts, efficiency)


func _synchronize_machine_power_nodes() -> void:
	if power_grid == null:
		return
	for machine: Node in machine_container.get_children():
		_register_or_update_machine_power(machine)


func _register_or_update_machine_power(machine: Node) -> void:
	if power_grid == null or not is_instance_valid(machine) or not power_grid.has_method(&"register_node"):
		return
	var has_power_contract: bool = (
		machine.has_method(&"get_power_output")
		or machine.has_method(&"get_power_draw")
		or machine.has_method(&"get_power_consumption")
	)
	if not has_power_contract:
		return
	var grid_pos: Vector2i = _grid_position_for_node(machine)
	var wattage_delta: float = _machine_wattage_delta(machine)
	var registered_nodes: Dictionary = {}
	if power_grid.has_method(&"get_registered_nodes"):
		var registered_value: Variant = power_grid.call(&"get_registered_nodes")
		if registered_value is Dictionary:
			registered_nodes = registered_value
	var previous_position: Variant = _machine_grid_positions.get(machine.get_instance_id())
	if previous_position is Vector2i and previous_position != grid_pos:
		power_grid.call(&"unregister_node", previous_position)
	if registered_nodes.has(grid_pos) and is_equal_approx(float(registered_nodes[grid_pos]), wattage_delta):
		_machine_grid_positions[machine.get_instance_id()] = grid_pos
		return
	power_grid.call(&"register_node", grid_pos, wattage_delta)
	_machine_grid_positions[machine.get_instance_id()] = grid_pos


func _unregister_machine_power(machine: Node) -> void:
	if power_grid == null or not power_grid.has_method(&"unregister_node"):
		return
	var instance_id: int = machine.get_instance_id()
	var grid_position_value: Variant = _machine_grid_positions.get(instance_id)
	if grid_position_value is Vector2i:
		power_grid.call(&"unregister_node", grid_position_value)
	_machine_grid_positions.erase(instance_id)


func _machine_wattage_delta(machine: Node) -> float:
	if machine.has_method(&"get_power_output"):
		return maxf(0.0, float(machine.call(&"get_power_output")))
	if machine.has_method(&"get_power_draw"):
		return -maxf(0.0, float(machine.call(&"get_power_draw")))
	if machine.has_method(&"get_power_consumption"):
		return -maxf(0.0, float(machine.call(&"get_power_consumption")))
	return 0.0


func _grid_position_for_node(node: Node) -> Vector2i:
	if node is Node2D:
		var node_2d: Node2D = node as Node2D
		return Vector2i(
			floori(node_2d.global_position.x / float(WorldGrid.TILE_SIZE)),
			floori(node_2d.global_position.y / float(WorldGrid.TILE_SIZE))
		)
	return Vector2i.ZERO


func _update_player_depth(force: bool) -> void:
	if world_grid == null or player == null:
		return
	var depth: int = maxi(0, floori(player.global_position.y / float(WorldGrid.TILE_SIZE)))
	var biome: String = world_grid.get_biome_at_depth(depth)
	if not force and depth == _last_depth and biome == _last_biome:
		return
	_last_depth = depth
	_last_biome = biome
	_signal_bus.depth_changed.emit(depth, biome)
	var oxygen: Node = player.get_node_or_null("OxygenComponent")
	if oxygen != null and oxygen.has_method(&"set_depth"):
		oxygen.call(&"set_depth", depth)


func _on_cave_in_triggered(_origin_grid: Vector2i, collapsed_tiles: Array[Vector2i]) -> void:
	if camera == null:
		return
	if _camera_shake_tween != null and _camera_shake_tween.is_valid():
		_camera_shake_tween.kill()
	camera.offset = Vector2.ZERO
	var strength: float = clampf(3.0 + float(collapsed_tiles.size()) * 0.35, 4.0, 14.0)
	_camera_shake_tween = create_tween()
	_camera_shake_tween.tween_property(camera, "offset", _random_shake_offset(strength), CAMERA_SHAKE_DURATION * 0.2)
	_camera_shake_tween.tween_property(camera, "offset", _random_shake_offset(strength * 0.65), CAMERA_SHAKE_DURATION * 0.25)
	_camera_shake_tween.tween_property(camera, "offset", Vector2.ZERO, CAMERA_SHAKE_DURATION * 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _random_shake_offset(strength: float) -> Vector2:
	return Vector2(randf_range(-strength, strength), randf_range(-strength, strength))


func _on_player_died() -> void:
	game_over.emit()


func set_darkness_intensity(intensity: float) -> void:
	var normalized: float = clampf(intensity, 0.0, 1.0)
	canvas_modulate.color = Color(0.12, 0.14, 0.19, 1.0).lerp(Color(0.025, 0.03, 0.05, 1.0), normalized)


func toggle_pause() -> void:
	get_tree().paused = not get_tree().paused
	if get_tree().paused:
		game_paused.emit()
	else:
		game_resumed.emit()


func _set_property_if_present(target: Object, property_name: StringName, value: Variant) -> bool:
	if target == null:
		return false
	for property_info: Dictionary in target.get_property_list():
		if StringName(property_info.get("name", &"")) == property_name:
			target.set(property_name, value)
			return true
	return false


func _invoke_setup_with_dependencies(target: Object) -> bool:
	return _invoke_method_with_dependencies(target, &"setup")


func _invoke_method_with_dependencies(target: Object, method_name: StringName) -> bool:
	if target == null or not target.has_method(method_name):
		return false
	for method_info: Dictionary in target.get_method_list():
		if StringName(method_info.get("name", &"")) != method_name:
			continue
		var argument_info: Array = method_info.get("args", [])
		var default_arguments: Array = method_info.get("default_args", [])
		var required_count: int = argument_info.size() - default_arguments.size()
		var values: Array = []
		for index: int in range(argument_info.size()):
			var descriptor: Dictionary = argument_info[index]
			var argument_name: String = String(descriptor.get("name", "")).to_lower()
			var resolution: Dictionary = _resolve_dependency(argument_name, target)
			if not bool(resolution.get("resolved", false)):
				if index < required_count:
					return false
				break
			values.append(resolution.get("value"))
		target.callv(method_name, values)
		return true
	return false


func _resolve_dependency(argument_name: String, target: Object) -> Dictionary:
	if "power" in argument_name and "grid" in argument_name:
		return {"resolved": true, "value": power_grid}
	if "grid_pos" in argument_name or "cell_pos" in argument_name:
		if target is Node:
			return {"resolved": true, "value": _grid_position_for_node(target as Node)}
		return {"resolved": false, "value": null}
	if "world" in argument_name or argument_name == "grid" or "tile_grid" in argument_name:
		return {"resolved": true, "value": world_grid}
	if "signal" in argument_name or "bus" in argument_name:
		return {"resolved": true, "value": _signal_bus}
	if "player" in argument_name:
		return {"resolved": true, "value": player}
	if "enemy" in argument_name and ("parent" in argument_name or "container" in argument_name):
		return {"resolved": true, "value": enemy_container}
	if "machine" in argument_name or "structure" in argument_name or "parent" in argument_name or "container" in argument_name:
		return {"resolved": true, "value": machine_container}
	return {"resolved": false, "value": null}
