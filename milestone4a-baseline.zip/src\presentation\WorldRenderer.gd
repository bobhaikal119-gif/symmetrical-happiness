extends Node2D

class_name WorldRenderer

## Procedural world renderer. It keeps no external texture assets and only
## submits draw commands for the tiles around the current viewport.

const GRID_SIZE: int = 512
const TILE_SIZE: int = 16
const ATLAS_COLUMNS: int = 4
const TILE_COUNT: int = 15
const REDRAW_ANIMATION_INTERVAL: float = 0.14

const TILE_AIR := 0
const TILE_SNOW := 1
const TILE_DIRT := 2
const TILE_STONE := 3
const TILE_IRON_ORE := 4
const TILE_COAL := 5
const TILE_COPPER := 6
const TILE_QUARTZ := 7
const TILE_TITANIUM := 8
const TILE_BIOLUME_STONE := 9
const TILE_BASALT := 10
const TILE_LAVA := 11
const TILE_ACID := 12
const TILE_SUPPORT_BEAM := 13
const TILE_POWER_CABLE := 14

@export var world_grid: WorldGrid

var _atlas_texture: ImageTexture = null
var _tile_atlas_coords: Dictionary = {}
var _last_visible_bounds := Rect2i()
var _animation_time: float = 0.0
var _animation_redraw_elapsed: float = 0.0
var _visible_has_animated_tiles: bool = false
var _collision_body: StaticBody2D
var _collision_bounds := Rect2i()
var _collision_rebuild_queued: bool = false


func _ready() -> void:
	_build_tile_data()
	_create_procedural_atlas()
	_collision_body = StaticBody2D.new()
	_collision_body.name = "VisibleWorldCollision"
	_collision_body.collision_layer = 1
	_collision_body.collision_mask = 1
	add_child(_collision_body)
	_connect_signals()
	set_process(true)
	sync_all_tiles()


func _build_tile_data() -> void:
	_tile_atlas_coords.clear()
	for tile_id: int in range(TILE_COUNT):
		_tile_atlas_coords[tile_id] = Vector2i(
			tile_id % ATLAS_COLUMNS,
			int(tile_id / ATLAS_COLUMNS)
		)


func _create_procedural_atlas() -> void:
	var atlas_rows: int = ceili(float(TILE_COUNT) / float(ATLAS_COLUMNS))
	var atlas := Image.create(
		ATLAS_COLUMNS * TILE_SIZE,
		atlas_rows * TILE_SIZE,
		false,
		Image.FORMAT_RGBA8
	)

	for tile_id: int in range(TILE_COUNT):
		var atlas_coords: Vector2i = _tile_atlas_coords[tile_id]
		var origin := atlas_coords * TILE_SIZE
		for pixel_y: int in range(TILE_SIZE):
			for pixel_x: int in range(TILE_SIZE):
				atlas.set_pixel(
					origin.x + pixel_x,
					origin.y + pixel_y,
					_procedural_pixel(tile_id, pixel_x, pixel_y)
				)

	_atlas_texture = ImageTexture.create_from_image(atlas)


func _procedural_pixel(tile_id: int, x: int, y: int) -> Color:
	if tile_id == TILE_AIR:
		return Color(0.0, 0.0, 0.0, 0.0)
	if tile_id == TILE_SUPPORT_BEAM:
		return _support_beam_pixel(x, y)
	if tile_id == TILE_POWER_CABLE:
		return _power_cable_pixel(x, y)

	var base: Color = _get_tile_color(tile_id)
	var noise_value: float = float(_pixel_hash(tile_id, x, y) % 100) / 100.0
	var shade: float = 0.82 + noise_value * 0.18
	if x == 0 or y == 0:
		shade += 0.10
	if x == TILE_SIZE - 1 or y == TILE_SIZE - 1:
		shade -= 0.16
	var result: Color = _shade_color(base, shade)

	match tile_id:
		TILE_SNOW:
			if y <= 2:
				result = Color(0.98, 0.99, 1.0, 1.0)
			elif y >= 12:
				result = result.lerp(Color(0.55, 0.68, 0.78, 1.0), 0.22)
		TILE_DIRT:
			if _pixel_hash(tile_id + 19, x, y) % 17 == 0:
				result = Color(0.30, 0.18, 0.09, 1.0)
		TILE_STONE:
			if (x + y * 3 + tile_id) % 19 == 0:
				result = Color(0.23, 0.25, 0.29, 1.0)
		TILE_IRON_ORE:
			result = _ore_fleck(result, x, y, Color(0.83, 0.49, 0.25, 1.0), 9)
		TILE_COAL:
			result = _ore_fleck(result, x, y, Color(0.04, 0.05, 0.07, 1.0), 7)
		TILE_COPPER:
			result = _ore_fleck(result, x, y, Color(1.0, 0.53, 0.13, 1.0), 8)
		TILE_QUARTZ:
			result = _ore_fleck(result, x, y, Color(0.80, 1.0, 1.0, 1.0), 7)
		TILE_TITANIUM:
			result = _ore_fleck(result, x, y, Color(0.72, 0.84, 1.0, 1.0), 10)
		TILE_BIOLUME_STONE:
			if _pixel_hash(tile_id + 31, x, y) % 13 <= 1:
				result = Color(0.27, 1.0, 0.67, 1.0)
		TILE_BASALT:
			if (x * 2 + y * 5) % 23 <= 1:
				result = Color(0.10, 0.11, 0.15, 1.0)
		TILE_LAVA:
			if (y + int(sin(float(x) * 0.8) * 2.0)) % 6 <= 1:
				result = Color(1.0, 0.72, 0.08, 1.0)
		TILE_ACID:
			var bubble_distance := Vector2(float(x - 5), float(y - 6)).length()
			if bubble_distance > 1.4 and bubble_distance < 2.4:
				result = Color(0.72, 1.0, 0.18, 1.0)

	return result


func _ore_fleck(background: Color, x: int, y: int, ore_color: Color, spacing: int) -> Color:
	var pattern: int = _pixel_hash(spacing, x, y) % spacing
	if pattern <= 1 and x > 1 and y > 1 and x < 14 and y < 14:
		return ore_color if pattern == 0 else ore_color.darkened(0.25)
	return background


func _support_beam_pixel(x: int, y: int) -> Color:
	var frame: bool = x == 2 or x == 3 or x == 12 or x == 13
	frame = frame or y == 2 or y == 3 or y == 12 or y == 13
	var diagonal: bool = abs(x - y) <= 1 or abs((TILE_SIZE - 1 - x) - y) <= 1
	if not frame and not diagonal:
		return Color(0.04, 0.06, 0.09, 0.20)
	var highlight: bool = x == 2 or y == 2 or ((x + y) % 5 == 0)
	return Color(0.66, 0.73, 0.82, 1.0) if highlight else Color(0.29, 0.34, 0.43, 1.0)


func _power_cable_pixel(x: int, y: int) -> Color:
	var center := Vector2(7.5, 7.5)
	var distance: float = Vector2(float(x), float(y)).distance_to(center)
	if distance <= 2.0:
		return Color(1.0, 0.76, 0.18, 1.0)
	if distance <= 3.3:
		return Color(0.70, 0.31, 0.08, 1.0)
	if distance <= 4.2 and (x + y) % 2 == 0:
		return Color(1.0, 0.62, 0.10, 0.42)
	return Color(0.03, 0.04, 0.06, 0.12)


func _pixel_hash(tile_id: int, x: int, y: int) -> int:
	return absi(tile_id * 92821 + x * 68917 + y * 28387 + x * y * 101)


func _shade_color(color: Color, shade: float) -> Color:
	return Color(
		clampf(color.r * shade, 0.0, 1.0),
		clampf(color.g * shade, 0.0, 1.0),
		clampf(color.b * shade, 0.0, 1.0),
		color.a
	)


func _get_tile_color(tile_id: int) -> Color:
	var registry := TileRegistry.get_instance()
	var tile_def := registry.get_tile_def(tile_id)
	if tile_def != null:
		return tile_def.color

	match tile_id:
		TILE_AIR: return Color(0.0, 0.0, 0.0, 0.0)
		TILE_SNOW: return Color(0.91, 0.95, 1.0, 1.0)
		TILE_DIRT: return Color(0.57, 0.36, 0.17, 1.0)
		TILE_STONE: return Color(0.42, 0.44, 0.48, 1.0)
		TILE_IRON_ORE: return Color(0.43, 0.40, 0.39, 1.0)
		TILE_COAL: return Color(0.25, 0.26, 0.28, 1.0)
		TILE_COPPER: return Color(0.47, 0.40, 0.34, 1.0)
		TILE_QUARTZ: return Color(0.47, 0.51, 0.57, 1.0)
		TILE_TITANIUM: return Color(0.42, 0.48, 0.57, 1.0)
		TILE_BIOLUME_STONE: return Color(0.20, 0.42, 0.34, 1.0)
		TILE_BASALT: return Color(0.18, 0.19, 0.23, 1.0)
		TILE_LAVA: return Color(0.91, 0.20, 0.03, 1.0)
		TILE_ACID: return Color(0.20, 0.77, 0.13, 1.0)
		TILE_SUPPORT_BEAM: return Color(0.55, 0.62, 0.72, 1.0)
		TILE_POWER_CABLE: return Color(0.95, 0.55, 0.12, 1.0)
		_: return Color.MAGENTA


func sync_all_tiles() -> void:
	queue_redraw()
	_schedule_collision_rebuild()


func sync_tile(x: int, y: int) -> void:
	if x < 0 or x >= GRID_SIZE or y < 0 or y >= GRID_SIZE:
		return
	queue_redraw()
	if _collision_bounds.has_point(Vector2i(x, y)):
		_schedule_collision_rebuild()


func _schedule_collision_rebuild() -> void:
	if _collision_rebuild_queued or not is_inside_tree():
		return
	_collision_rebuild_queued = true
	call_deferred(&"_rebuild_visible_collisions")


func _rebuild_visible_collisions() -> void:
	_collision_rebuild_queued = false
	if world_grid == null or _collision_body == null:
		return
	for child: Node in _collision_body.get_children():
		child.free()

	var visible_bounds: Rect2i = _get_visible_tile_bounds()
	var start_x: int = maxi(0, visible_bounds.position.x - 4)
	var start_y: int = maxi(0, visible_bounds.position.y - 4)
	var end_x: int = mini(GRID_SIZE, visible_bounds.end.x + 4)
	var end_y: int = mini(GRID_SIZE, visible_bounds.end.y + 4)
	_collision_bounds = Rect2i(start_x, start_y, end_x - start_x, end_y - start_y)
	var registry: TileRegistry = TileRegistry.get_instance()

	for y: int in range(start_y, end_y):
		var run_start: int = -1
		for x: int in range(start_x, end_x + 1):
			var is_solid: bool = false
			if x < end_x:
				var tile_id: int = world_grid.get_tile(x, y)
				is_solid = registry.get_is_solid(tile_id)
			if is_solid and run_start < 0:
				run_start = x
			elif not is_solid and run_start >= 0:
				_add_collision_run(run_start, x, y)
				run_start = -1


func _add_collision_run(start_x: int, end_x: int, y: int) -> void:
	var width_tiles: int = end_x - start_x
	if width_tiles <= 0:
		return
	var shape := RectangleShape2D.new()
	shape.size = Vector2(float(width_tiles * TILE_SIZE), float(TILE_SIZE))
	var collision := CollisionShape2D.new()
	collision.shape = shape
	collision.position = Vector2(
		float(start_x * TILE_SIZE) + shape.size.x * 0.5,
		float(y * TILE_SIZE) + float(TILE_SIZE) * 0.5
	)
	_collision_body.add_child(collision)


func _draw() -> void:
	if world_grid == null or _atlas_texture == null:
		_visible_has_animated_tiles = false
		return

	var bounds: Rect2i = _get_visible_tile_bounds()
	_last_visible_bounds = bounds
	_visible_has_animated_tiles = false
	for y: int in range(bounds.position.y, bounds.end.y):
		for x: int in range(bounds.position.x, bounds.end.x):
			var tile_id: int = world_grid.get_tile(x, y)
			if tile_id == TILE_AIR:
				continue
			_draw_tile(Vector2i(x, y), tile_id)


func _draw_tile(grid_pos: Vector2i, tile_id: int) -> void:
	var atlas_coords: Vector2i = _tile_atlas_coords.get(tile_id, Vector2i.ZERO)
	var destination := Rect2(Vector2(grid_pos * TILE_SIZE), Vector2(TILE_SIZE, TILE_SIZE))
	var source := Rect2(Vector2(atlas_coords * TILE_SIZE), Vector2(TILE_SIZE, TILE_SIZE))
	draw_texture_rect_region(_atlas_texture, destination, source)

	if tile_id == TILE_POWER_CABLE:
		_visible_has_animated_tiles = true
		_draw_cable_connections(grid_pos)
	elif tile_id == TILE_LAVA or tile_id == TILE_ACID:
		_visible_has_animated_tiles = true
		_draw_hazard_glint(grid_pos, tile_id)


func _draw_cable_connections(grid_pos: Vector2i) -> void:
	var center := Vector2(grid_pos * TILE_SIZE) + Vector2(7.5, 7.5)
	var pulse: float = 0.58 + sin(_animation_time * 5.0) * 0.16
	for direction: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		var neighbor := grid_pos + direction
		if world_grid.get_tile(neighbor.x, neighbor.y) != TILE_POWER_CABLE:
			continue
		var endpoint := center + Vector2(direction) * 8.5
		draw_line(center, endpoint, Color(0.17, 0.08, 0.03, 1.0), 5.0)
		draw_line(center, endpoint, Color(0.83, 0.36, 0.07, 1.0), 3.0)
		draw_line(center, endpoint, Color(1.0, 0.78, 0.24, pulse), 1.0)
	draw_circle(center, 2.0, Color(1.0, 0.80, 0.26, pulse + 0.15))


func _draw_hazard_glint(grid_pos: Vector2i, tile_id: int) -> void:
	var center := Vector2(grid_pos * TILE_SIZE) + Vector2(8.0, 8.0)
	var wave: float = 0.5 + sin(_animation_time * (5.0 if tile_id == TILE_LAVA else 3.0)) * 0.5
	var glow_color := Color(1.0, 0.68, 0.08, 0.08 + wave * 0.12)
	if tile_id == TILE_ACID:
		glow_color = Color(0.54, 1.0, 0.18, 0.07 + wave * 0.11)
	draw_circle(center, 5.0 + wave, glow_color)


func _get_visible_tile_bounds() -> Rect2i:
	if not is_inside_tree():
		return Rect2i(0, 0, GRID_SIZE, GRID_SIZE)

	var viewport_size: Vector2 = get_viewport_rect().size
	var inverse_view_transform: Transform2D = get_global_transform_with_canvas().affine_inverse()
	var local_a: Vector2 = inverse_view_transform * Vector2.ZERO
	var local_b: Vector2 = inverse_view_transform * viewport_size
	var local_min := Vector2(minf(local_a.x, local_b.x), minf(local_a.y, local_b.y))
	var local_max := Vector2(maxf(local_a.x, local_b.x), maxf(local_a.y, local_b.y))

	var start_x: int = clampi(floori(local_min.x / TILE_SIZE) - 2, 0, GRID_SIZE)
	var start_y: int = clampi(floori(local_min.y / TILE_SIZE) - 2, 0, GRID_SIZE)
	var end_x: int = clampi(ceili(local_max.x / TILE_SIZE) + 2, 0, GRID_SIZE)
	var end_y: int = clampi(ceili(local_max.y / TILE_SIZE) + 2, 0, GRID_SIZE)
	return Rect2i(start_x, start_y, end_x - start_x, end_y - start_y)


func _connect_signals() -> void:
	var signal_bus := SignalBus.get_instance()
	if not signal_bus.tile_damaged.is_connected(_on_signal_bus_tile_damaged):
		signal_bus.tile_damaged.connect(_on_signal_bus_tile_damaged)
	if not signal_bus.tile_broken.is_connected(_on_signal_bus_tile_broken):
		signal_bus.tile_broken.connect(_on_signal_bus_tile_broken)
	if not signal_bus.tile_placed.is_connected(_on_signal_bus_tile_placed):
		signal_bus.tile_placed.connect(_on_signal_bus_tile_placed)


func _on_signal_bus_tile_damaged(
	grid_pos: Vector2i,
	_current_hp: float,
	_max_hp: float
) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _on_signal_bus_tile_broken(grid_pos: Vector2i, _tile_id: int) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _on_signal_bus_tile_placed(grid_pos: Vector2i, _tile_id: int) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _process(delta: float) -> void:
	_animation_time += delta
	var visible_bounds: Rect2i = _get_visible_tile_bounds()
	if visible_bounds != _last_visible_bounds:
		queue_redraw()
		_schedule_collision_rebuild()

	if not _visible_has_animated_tiles:
		return
	_animation_redraw_elapsed += delta
	if _animation_redraw_elapsed >= REDRAW_ANIMATION_INTERVAL:
		_animation_redraw_elapsed = 0.0
		queue_redraw()
