extends Node2D

class_name MiningLaserComponent

"""Player mining tool that damages target tiles and draws a procedural beam."""

@export var reach_distance: float = 64.0
@export var mining_damage: float = 5.0
@export var beam_width: float = 2.0
@export var beam_color: Color = Color(1.0, 0.78, 0.2)

var laser_beam: Line2D
var world_grid: WorldGrid
var is_active: bool = false
var target_grid_pos: Vector2i = Vector2i.ZERO

func _ready() -> void:
	laser_beam = get_node_or_null("LaserBeam") as Line2D
	if laser_beam == null:
		laser_beam = Line2D.new()
		laser_beam.name = "LaserBeam"
		add_child(laser_beam)
	laser_beam.width = beam_width
	laser_beam.default_color = beam_color
	laser_beam.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("mine"):
		activate()
	elif event.is_action_released("mine"):
		deactivate()

func _process(delta: float) -> void:
	if not is_active or world_grid == null:
		if laser_beam != null:
			laser_beam.visible = false
		return
	var mouse_pos: Vector2 = get_global_mouse_position()
	target_grid_pos = Vector2i(floori(mouse_pos.x / WorldGrid.TILE_SIZE), floori(mouse_pos.y / WorldGrid.TILE_SIZE))
	if _is_target_valid(target_grid_pos):
		world_grid.damage_tile(target_grid_pos.x, target_grid_pos.y, mining_damage * delta)
		_update_laser_beam(mouse_pos)
	else:
		laser_beam.visible = false

func _is_target_valid(grid_pos: Vector2i) -> bool:
	var tile_world_pos := Vector2(grid_pos * WorldGrid.TILE_SIZE) + Vector2.ONE * (WorldGrid.TILE_SIZE * 0.5)
	if global_position.distance_to(tile_world_pos) > reach_distance:
		return false
	var tile_id: int = world_grid.get_tile(grid_pos.x, grid_pos.y)
	return tile_id != WorldGrid.TILE_AIR and tile_id != WorldGrid.TILE_LAVA and tile_id != WorldGrid.TILE_ACID and tile_id != WorldGrid.TILE_SUPPORT_BEAM and tile_id != WorldGrid.TILE_POWER_CABLE

func _update_laser_beam(mouse_pos: Vector2) -> void:
	laser_beam.visible = true
	laser_beam.points = PackedVector2Array([Vector2.ZERO, to_local(mouse_pos)])

func activate() -> void:
	is_active = true

func deactivate() -> void:
	is_active = false
	if laser_beam != null:
		laser_beam.visible = false

func toggle() -> void:
	if is_active:
		deactivate()
	else:
		activate()
