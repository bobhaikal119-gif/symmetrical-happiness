extends PanelContainer

class_name CraftingPanel

"""
CraftingPanel: SignalBus-only crafting UI. Recipe buttons emit craft requests;
the panel never reaches into the player or inventory directly.
"""

@onready var recipe_list: VBoxContainer = %RecipeList
@onready var status_label: Label = %StatusLabel

var signal_bus: SignalBus
var recipe_registry: RecipeRegistry
var is_open: bool = false

func _ready() -> void:
	signal_bus = SignalBus.get_instance()
	recipe_registry = RecipeRegistry.get_instance()
	signal_bus.crafting_menu_toggled.connect(_on_crafting_menu_toggled)
	signal_bus.craft_completed.connect(_on_craft_completed)
	%CloseButton.pressed.connect(_close_panel)
	_build_recipe_buttons()
	visible = false

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("craft"):
		set_open(not is_open)
		get_viewport().set_input_as_handled()
	elif is_open and event.is_action_pressed("ui_cancel"):
		set_open(false)
		get_viewport().set_input_as_handled()

func set_open(open: bool) -> void:
	if is_open == open:
		return
	is_open = open
	visible = open
	signal_bus.crafting_menu_toggled.emit(open)

func _close_panel() -> void:
	set_open(false)

func _on_crafting_menu_toggled(open: bool) -> void:
	is_open = open
	visible = open

func _build_recipe_buttons() -> void:
	for child: Node in recipe_list.get_children():
		child.queue_free()
	for recipe_variant: Variant in recipe_registry.get_all_recipes():
		var recipe: RecipeDef = recipe_variant as RecipeDef
		if recipe == null:
			continue
		var button := Button.new()
		button.text = _format_recipe(recipe)
		button.custom_minimum_size = Vector2(280.0, 34.0)
		button.pressed.connect(_request_craft.bind(recipe.id))
		recipe_list.add_child(button)

func _format_recipe(recipe: RecipeDef) -> String:
	var ingredient_parts: PackedStringArray = []
	for ingredient_variant: Variant in recipe.ingredients.keys():
		ingredient_parts.append("%s x%d" % [str(ingredient_variant), int(recipe.ingredients[ingredient_variant])])
	return "%s x%d  <-  %s" % [recipe.output_item_id, recipe.output_count, ", ".join(ingredient_parts)]

func _request_craft(recipe_id: String) -> void:
	status_label.text = "Crafting %s..." % recipe_id
	signal_bus.craft_requested.emit(recipe_id)

func _on_craft_completed(recipe_id: String, success: bool) -> void:
	status_label.text = "%s: %s" % [recipe_id, "crafted" if success else "missing materials"]
