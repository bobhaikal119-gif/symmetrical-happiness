extends CanvasLayer

class_name HudController

const TEMPERATURE_MINIMUM: float = -50.0

@onready var temperature_bar: ProgressBar = %TemperatureBar
@onready var temperature_value: Label = %TemperatureValue
@onready var battery_bar: ProgressBar = %BatteryBar
@onready var battery_value: Label = %BatteryValue
@onready var hp_bar: ProgressBar = %HPBar
@onready var hp_value: Label = %HPValue
@onready var oxygen_bar: ProgressBar = %OxygenBar
@onready var oxygen_value: Label = %OxygenValue
@onready var depth_label: Label = %DepthLabel
@onready var biome_label: Label = %BiomeLabel
@onready var storm_timer_label: Label = %StormTimerLabel
@onready var grid_power_label: Label = %GridPowerLabel
@onready var grid_efficiency_label: Label = %GridEfficiencyLabel
@onready var storm_wave_alert: PanelContainer = %StormWaveAlert
@onready var storm_wave_alert_label: Label = %StormWaveAlertLabel
@onready var controls_hint_label: Label = %ControlsHintLabel

var _signal_bus: SignalBus
var _wave_alert_tween: Tween
var _hint_tween: Tween


func _ready() -> void:
	_signal_bus = SignalBus.get_instance()
	_connect_bus_signals()
	_initialize_display()


func _connect_bus_signals() -> void:
	if not _signal_bus.temperature_changed.is_connected(_on_temperature_changed):
		_signal_bus.temperature_changed.connect(_on_temperature_changed)
	if not _signal_bus.battery_changed.is_connected(_on_battery_changed):
		_signal_bus.battery_changed.connect(_on_battery_changed)
	if not _signal_bus.hp_changed.is_connected(_on_hp_changed):
		_signal_bus.hp_changed.connect(_on_hp_changed)
	if not _signal_bus.oxygen_changed.is_connected(_on_oxygen_changed):
		_signal_bus.oxygen_changed.connect(_on_oxygen_changed)
	if not _signal_bus.depth_changed.is_connected(_on_depth_changed):
		_signal_bus.depth_changed.connect(_on_depth_changed)
	if not _signal_bus.cryo_storm_timer_updated.is_connected(_on_cryo_storm_timer_updated):
		_signal_bus.cryo_storm_timer_updated.connect(_on_cryo_storm_timer_updated)
	if not _signal_bus.power_grid_updated.is_connected(_on_power_grid_updated):
		_signal_bus.power_grid_updated.connect(_on_power_grid_updated)
	if not _signal_bus.storm_wave_started.is_connected(_on_storm_wave_started):
		_signal_bus.storm_wave_started.connect(_on_storm_wave_started)
	if not _signal_bus.show_hud_hint.is_connected(show_controls_hint):
		_signal_bus.show_hud_hint.connect(show_controls_hint)
	if not _signal_bus.hide_hud_hint.is_connected(hide_controls_hint):
		_signal_bus.hide_hud_hint.connect(hide_controls_hint)


func _initialize_display() -> void:
	_update_bar(temperature_bar, 20.0, 100.0, TEMPERATURE_MINIMUM)
	temperature_value.text = "20.0 °C"
	_update_bar(battery_bar, 100.0, 100.0)
	battery_value.text = "100 / 100"
	_update_bar(hp_bar, 100.0, 100.0)
	hp_value.text = "100 / 100"
	_update_bar(oxygen_bar, 100.0, 100.0)
	oxygen_value.text = "100 / 100"
	depth_label.text = "Depth: 0 m"
	biome_label.text = "Biome: Permafrost Surface"
	storm_timer_label.text = "Cryo Storm: 03:00"
	grid_power_label.text = "Grid Power: 0.0 W / 0.0 W"
	grid_efficiency_label.text = "Efficiency: 100%"
	storm_wave_alert.visible = false
	controls_hint_label.visible = false


func _on_temperature_changed(current: float, max_value: float) -> void:
	_update_bar(temperature_bar, current, max_value, TEMPERATURE_MINIMUM)
	temperature_value.text = "%.1f °C" % current


func _on_battery_changed(current: float, max_value: float) -> void:
	_update_bar(battery_bar, current, max_value)
	battery_value.text = "%.0f / %.0f" % [current, max_value]


func _on_hp_changed(current: float, max_value: float) -> void:
	_update_bar(hp_bar, current, max_value)
	hp_value.text = "%.0f / %.0f" % [current, max_value]


func _on_oxygen_changed(current: float, max_value: float) -> void:
	_update_bar(oxygen_bar, current, max_value)
	oxygen_value.text = "%.0f / %.0f" % [current, max_value]


func _on_depth_changed(meters: int, biome_name: String) -> void:
	depth_label.text = "Depth: %d m" % meters
	biome_label.text = "Biome: %s" % biome_name


func _on_cryo_storm_timer_updated(time_left: float) -> void:
	var total_seconds: int = maxi(0, ceili(time_left))
	var minutes: int = total_seconds / 60
	var seconds: int = total_seconds % 60
	storm_timer_label.text = "Cryo Storm: %02d:%02d" % [minutes, seconds]
	if total_seconds <= 15:
		storm_timer_label.add_theme_color_override("font_color", Color(1.0, 0.34, 0.24))
	else:
		storm_timer_label.add_theme_color_override("font_color", Color(0.55, 0.9, 1.0))


func _on_power_grid_updated(produced_watts: float, demand_watts: float, efficiency: float) -> void:
	grid_power_label.text = "Grid Power: %.1f W / %.1f W" % [produced_watts, demand_watts]
	var normalized_efficiency: float = efficiency
	if normalized_efficiency <= 1.0:
		normalized_efficiency *= 100.0
	normalized_efficiency = clampf(normalized_efficiency, 0.0, 100.0)
	grid_efficiency_label.text = "Efficiency: %.0f%%" % normalized_efficiency
	var efficiency_color: Color = Color(0.45, 1.0, 0.62)
	if normalized_efficiency < 50.0:
		efficiency_color = Color(1.0, 0.34, 0.24)
	elif normalized_efficiency < 85.0:
		efficiency_color = Color(1.0, 0.76, 0.28)
	grid_efficiency_label.add_theme_color_override("font_color", efficiency_color)


func _on_storm_wave_started(wave_number: int, enemy_count: int) -> void:
	if _wave_alert_tween != null and _wave_alert_tween.is_valid():
		_wave_alert_tween.kill()
	storm_wave_alert_label.text = "STORM WAVE %d  •  %d CRAWLERS" % [wave_number, enemy_count]
	storm_wave_alert.visible = true
	storm_wave_alert.modulate = Color.WHITE
	storm_wave_alert.scale = Vector2(0.94, 0.94)
	_wave_alert_tween = create_tween()
	_wave_alert_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	_wave_alert_tween.tween_property(storm_wave_alert, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_wave_alert_tween.tween_interval(2.5)
	_wave_alert_tween.tween_property(storm_wave_alert, "modulate:a", 0.0, 1.0).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_wave_alert_tween.tween_callback(_hide_wave_alert)


func show_controls_hint(text: String) -> void:
	if _hint_tween != null and _hint_tween.is_valid():
		_hint_tween.kill()
	controls_hint_label.text = text
	controls_hint_label.visible = not text.is_empty()
	controls_hint_label.modulate = Color.WHITE
	if text.is_empty():
		return
	_hint_tween = create_tween()
	_hint_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	_hint_tween.tween_interval(3.0)
	_hint_tween.tween_property(controls_hint_label, "modulate:a", 0.0, 0.5)
	_hint_tween.tween_callback(hide_controls_hint)


func hide_controls_hint() -> void:
	controls_hint_label.visible = false
	controls_hint_label.modulate = Color.WHITE


func _hide_wave_alert() -> void:
	storm_wave_alert.visible = false
	storm_wave_alert.modulate = Color.WHITE
	storm_wave_alert.scale = Vector2.ONE


func _update_bar(bar: ProgressBar, current: float, max_value: float, min_value: float = 0.0) -> void:
	bar.min_value = min_value
	bar.max_value = maxf(max_value, min_value + 0.001)
	bar.value = clampf(current, bar.min_value, bar.max_value)
