extends CharacterBody2D

class_name Player

"""Main player character composed from survival and tool components."""

@export var move_speed: float = 150.0
@export var jump_velocity: float = -330.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var flashlight: PointLight2D = $Flashlight
@onready var battery: BatteryComponent = $BatteryComponent
@onready var thermal: ThermalComponent = $ThermalComponent
@onready var mining_laser: MiningLaserComponent = $MiningLaserComponent
@onready var hazard_detector: HazardDetectorComponent = $HazardDetectorComponent
@onready var oxygen: OxygenComponent = $OxygenComponent
@onready var crafting: CraftingComponent = $CraftingComponent
@onready var placement: PlacementComponent = $PlacementComponent

var signal_bus: SignalBus
var _gravity: float = 980.0

func _ready() -> void:
	add_to_group("player")
	signal_bus = SignalBus.get_instance()
	_gravity = float(ProjectSettings.get_setting("physics/2d/default_gravity", 980.0))
	_create_procedural_sprite()
	flashlight.texture = ProceduralLightTexture.create_radial_texture(128)
	flashlight.texture_scale = 1.2
	flashlight.energy = 1.1
	flashlight.color = Color(0.78, 0.9, 1.0)
	if not battery.is_node_ready():
		await battery.ready
	battery.set_flashlight_active(true)
	if not signal_bus.battery_changed.is_connected(_on_battery_changed):
		signal_bus.battery_changed.connect(_on_battery_changed)
	if not hazard_detector.hazard_damage.is_connected(_on_hazard_damage):
		hazard_detector.hazard_damage.connect(_on_hazard_damage)

func _physics_process(delta: float) -> void:
	var input_axis: float = Input.get_axis("move_left", "move_right")
	velocity.x = move_toward(velocity.x, input_axis * move_speed, move_speed * 8.0 * delta)
	if not is_on_floor():
		velocity.y += _gravity * delta
	elif Input.is_action_just_pressed("ui_jump") or Input.is_action_just_pressed("move_up"):
		velocity.y = jump_velocity
	move_and_slide()
	hazard_detector.player_position = global_position
	oxygen.set_depth(maxi(0, floori(global_position.y / WorldGrid.TILE_SIZE)))
	GlobalGameState.set_player_position(global_position)
	flashlight.rotation = 0.0 if input_axis >= 0.0 else PI

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("flashlight_toggle"):
		flashlight.visible = not flashlight.visible
		battery.set_flashlight_active(flashlight.visible)

func _create_procedural_sprite() -> void:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	var dark := Color("182231")
	var steel := Color("8aa3b8")
	var frost := Color("d9f4ff")
	var amber := Color("f0a22e")
	for y in range(4, 13):
		for x in range(4, 12):
			image.set_pixel(x, y, steel if x < 9 else dark)
	for y in range(1, 6):
		for x in range(5, 11):
			image.set_pixel(x, y, frost if y < 3 else steel)
	image.set_pixel(6, 3, amber)
	image.set_pixel(9, 3, amber)
	for x in range(3, 6):
		image.set_pixel(x, 8, dark)
	for x in range(11, 14):
		image.set_pixel(x, 8, dark)
	for y in range(13, 16):
		image.set_pixel(5, y, dark)
		image.set_pixel(10, y, dark)
	sprite.texture = ImageTexture.create_from_image(image)

func _on_battery_changed(current: float, max_value: float) -> void:
	var ratio: float = current / maxf(max_value, 0.001)
	flashlight.energy = 0.3 + ratio
	if current <= 0.0:
		flashlight.visible = false

func _on_hazard_damage(amount: float, _world_pos: Vector2) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() - amount)

func take_damage(amount: float) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() - maxf(0.0, amount))

func get_battery() -> BatteryComponent:
	return battery

func get_thermal() -> ThermalComponent:
	return thermal

func get_mining_laser() -> MiningLaserComponent:
	return mining_laser
