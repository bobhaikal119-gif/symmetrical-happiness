extends Node

class_name SignalBus

## Centralized dispatcher for gameplay, presentation, and UI events.

# Milestone 1-3 world and player contracts.
signal tile_damaged(grid_pos: Vector2i, current_hp: float, max_hp: float)
signal tile_broken(grid_pos: Vector2i, tile_id: int)
signal tile_placed(grid_pos: Vector2i, tile_id: int)
signal temperature_changed(current: float, maximum: float)
signal battery_changed(current: float, maximum: float)
signal hp_changed(current: float, maximum: float)
signal oxygen_changed(current: float, maximum: float)
signal heater_deployed(world_pos: Vector2, radius: float)
signal camp_heater_placed(world_pos: Vector2)
signal cryo_storm_timer_updated(time_left: float)
signal depth_changed(meters: int, biome_name: String)
signal cave_in_triggered(origin_grid: Vector2i, collapsed_tiles: Array[Vector2i])
signal cave_in_visual(origin_grid: Vector2i)
signal crafting_menu_toggled(is_open: bool)
signal craft_requested(recipe_id: String)
signal structure_placed(grid_pos: Vector2i, item_id: String)

# Compatibility contracts used by existing game-state, pickup, crafting, and UI callers.
signal player_spawned(world_pos: Vector2)
signal player_died
signal item_collected(item_id: String, count: int)
signal craft_completed(recipe_id: String, success: bool)
signal show_hud_hint(message: String)
signal hide_hud_hint

# Legacy HUD aliases retained for Milestone 1-3 scenes.
signal temperature_updated(current: float, maximum: float)
signal battery_updated(current: float, maximum: float)
signal hp_updated(current: float, maximum: float)

# Milestone 4 automation, power, and combat contracts.
signal power_grid_updated(produced_watts: float, demand_watts: float, efficiency: float)
signal auto_drill_extracted(grid_pos: Vector2i, item_id: String)
signal storm_wave_started(wave_number: int, enemy_count: int)
signal enemy_defeated(world_pos: Vector2, drop_item_id: String)

static var _instance: SignalBus = null


static func get_instance() -> SignalBus:
	## Return the process-local signal bus, creating it before SceneTree attachment if needed.
	if not is_instance_valid(_instance):
		_instance = SignalBus.new()
	return _instance


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
