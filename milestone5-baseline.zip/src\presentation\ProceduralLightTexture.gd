extends RefCounted

class_name ProceduralLightTexture

"""
ProceduralLightTexture: Generates smooth radial light falloff textures via Image
so PointLight2D nodes illuminate scenes without any external .png assets.
"""

static var _cached_textures: Dictionary = {}

static func create_radial_texture(size: int = 128) -> ImageTexture:
	if _cached_textures.has(size):
		return _cached_textures[size] as ImageTexture

	var image := Image.create_empty(size, size, false, Image.FORMAT_RGBA8)
	var center: float = (size - 1) * 0.5
	var max_dist: float = maxf(1.0, center)

	for y in range(size):
		for x in range(size):
			var dx: float = (x - center) / max_dist
			var dy: float = (y - center) / max_dist
			var dist: float = sqrt(dx * dx + dy * dy)
			var alpha: float = clampf(1.0 - dist, 0.0, 1.0)
			alpha = alpha * alpha
			image.set_pixel(x, y, Color(1.0, 1.0, 1.0, alpha))

	var tex := ImageTexture.create_from_image(image)
	_cached_textures[size] = tex
	return tex
