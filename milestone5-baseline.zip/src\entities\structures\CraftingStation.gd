extends InteractableEntity

class_name CraftingStation

@export var station_kind: String = ""
@export var station_radius: float = 80.0

var world_grid: WorldGrid
var _display_name: String = "Crafting station"
var _sprite: Sprite2D
var _light: PointLight2D
var _pulse_time: float = 0.0


func configure_item(definition: ItemDef, cell: Vector2i, grid: WorldGrid) -> void:
	item_id = definition.id
	grid_pos = cell
	world_grid = grid
	station_kind = definition.station_kind
	housing_tags.assign(definition.housing_tags)
	_display_name = definition.display_name
	_publish_metadata()
	if is_node_ready():
		_update_visual()


func _ready() -> void:
	super._ready()
	add_to_group(&"crafting_stations")
	add_to_group(&"placed_structures")
	if station_kind.is_empty() and not item_id.is_empty():
		var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
		if definition != null:
			configure_item(definition, grid_pos, world_grid)
	_publish_metadata()
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_light = get_node_or_null("PointLight2D") as PointLight2D
	if _light == null:
		_light = PointLight2D.new()
		_light.name = "PointLight2D"
		add_child(_light)
	_light.texture = ProceduralLightTexture.create_radial_texture(64)
	_light.texture_scale = 0.75
	_update_visual()


func _publish_metadata() -> void:
	set_meta(&"item_id", item_id)
	set_meta(&"grid_pos", grid_pos)
	set_meta(&"housing_tags", housing_tags.duplicate())


func interact(actor: Node) -> void:
	if can_interact(actor):
		# CraftingComponent refreshes typed nearby stations when this signal opens.
		SignalBus.get_instance().crafting_menu_toggled.emit(true)


func get_prompt_text() -> String:
	return "Use %s" % _display_name


func _update_visual() -> void:
	if _sprite != null and not item_id.is_empty():
		_sprite.texture = ProceduralEntitySprites.get_texture(item_id)
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if _light != null and definition != null:
		_light.color = definition.color
		_light.energy = 0.45


func _process(delta: float) -> void:
	_pulse_time += delta
	if _light != null:
		_light.energy = 0.42 + sin(_pulse_time * 2.0) * 0.05
