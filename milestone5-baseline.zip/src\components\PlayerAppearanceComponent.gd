extends Node
class_name PlayerAppearanceComponent

## Presentation, flashlight intent and damage telemetry are not movement policy.
var actor: CharacterBody2D
var sprite: Sprite2D
var flashlight: PointLight2D
var battery: BatteryComponent
var hazard_detector: HazardDetectorComponent
var _flashlight_requested: bool = true
var _configured: bool = false

func configure(owner_actor: CharacterBody2D) -> void:
	if _configured:
		return
	_configured = true
	actor = owner_actor
	sprite = actor.get_node("Sprite2D") as Sprite2D
	flashlight = actor.get_node("Flashlight") as PointLight2D
	battery = actor.get_node("BatteryComponent") as BatteryComponent
	hazard_detector = actor.get_node("HazardDetectorComponent") as HazardDetectorComponent
	_create_sprite()
	sprite.modulate = SettingsManager.get_setting("profile", "suit_color", Color.WHITE)
	flashlight.texture = ProceduralLightTexture.create_radial_texture(128)
	flashlight.texture_scale = 1.2
	flashlight.color = Color(0.78, 0.9, 1.0)
	var bus: SignalBus = SignalBus.get_instance()
	bus.setting_changed.connect(_on_setting_changed)
	bus.battery_changed.connect(_on_battery_changed)
	hazard_detector.hazard_damage.connect(_on_hazard_damage)
	battery.set_flashlight_active(true)

func _unhandled_input(event: InputEvent) -> void:
	if not _configured or SettingsManager.is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if event.is_action_pressed("flashlight_toggle"):
		_flashlight_requested = not _flashlight_requested
		battery.set_flashlight_active(_flashlight_requested)
		get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	if _configured and not is_zero_approx(actor.velocity.x):
		flashlight.rotation = 0.0 if actor.velocity.x > 0.0 else PI

func _create_sprite() -> void:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	const DARK := Color("182231")
	const STEEL := Color("8aa3b8")
	const FROST := Color("d9f4ff")
	for y: int in range(4, 13):
		for x: int in range(4, 12):
			image.set_pixel(x, y, STEEL if x < 9 else DARK)
	for y: int in range(1, 6):
		for x: int in range(5, 11):
			image.set_pixel(x, y, FROST if y < 3 else STEEL)
	image.set_pixel(6, 3, Color("f0a22e"))
	image.set_pixel(9, 3, Color("f0a22e"))
	for x: int in [3, 4, 5, 11, 12, 13]:
		image.set_pixel(x, 8, DARK)
	for y: int in range(13, 16):
		image.set_pixel(5, y, DARK)
		image.set_pixel(10, y, DARK)
	sprite.texture = ImageTexture.create_from_image(image)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func take_damage(amount: float) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() - maxf(0.0, amount))

func _on_hazard_damage(amount: float, _position: Vector2) -> void:
	take_damage(amount)

func _on_battery_changed(current: float, maximum: float) -> void:
	flashlight.energy = 0.3 + current / maxf(maximum, 0.001)
	flashlight.visible = _flashlight_requested and current > 0.0

func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section == "profile" and key == "suit_color":
		sprite.modulate = value as Color
