extends RefCounted
class_name StructuralIntegritySystem

## Pure cave-in simulation; local signals are bridged by the scene service.
signal cave_in_triggered(origin_grid: Vector2i, collapsed_tiles: Array[Vector2i])
const CAVE_IN_DEPTH_THRESHOLD: int = 150
const MAX_UNSUPPORTED_SPAN: int = 6
var world_grid: WorldGrid

func _init(grid: WorldGrid = null) -> void:
	world_grid = grid

func check_tile_break(x: int, y: int, _broken_tile_id: int = 0) -> Array[Vector2i]:
	var collapsed: Array[Vector2i] = []
	if world_grid == null or y < CAVE_IN_DEPTH_THRESHOLD:
		return collapsed
	var row: int = y - 1
	while row >= 0:
		if not world_grid.is_solid(x, row):
			break
		if _unsupported_span(x, row) > MAX_UNSUPPORTED_SPAN:
			_collapse(Vector2i(x, row), collapsed)
			break
		row -= 1
	return collapsed

func _supported(x: int, y: int) -> bool:
	if not world_grid.is_valid_position(x, y + 1):
		return true
	return world_grid.is_solid(x, y + 1) or world_grid.get_tile(x, y + 1) == WorldGrid.TILE_SUPPORT_BEAM

func _unsupported_span(x: int, y: int) -> int:
	var count: int = 0
	for direction: int in [-1, 1]:
		var scan: int = x if direction == -1 else x + 1
		while world_grid.is_valid_position(scan, y) and world_grid.is_solid(scan, y) and not _supported(scan, y):
			count += 1
			scan += direction
			if count > MAX_UNSUPPORTED_SPAN:
				return count
	return count

func _collapse(origin: Vector2i, collapsed: Array[Vector2i]) -> void:
	var pending: Array[Vector2i] = [origin]
	var visited: Dictionary = {}
	var detached: Array[Vector2i] = []
	var tile_types: Array[int] = []
	while not pending.is_empty() and detached.size() < 64:
		var cell: Vector2i = pending.pop_back()
		if visited.has(cell) or not world_grid.is_valid_position(cell.x, cell.y):
			continue
		visited[cell] = true
		if not world_grid.is_solid(cell.x, cell.y) or _supported(cell.x, cell.y):
			continue
		detached.append(cell)
		tile_types.append(world_grid.get_tile(cell.x, cell.y))
		pending.append(cell + Vector2i.UP)
		pending.append(cell + Vector2i.LEFT)
		pending.append(cell + Vector2i.RIGHT)
	for cell: Vector2i in detached:
		world_grid.set_tile(cell.x, cell.y, WorldGrid.TILE_AIR)
	for index: int in range(detached.size() - 1, -1, -1):
		var cell: Vector2i = detached[index]
		while world_grid.is_valid_position(cell.x, cell.y + 1) and not world_grid.is_solid(cell.x, cell.y + 1):
			cell.y += 1
		world_grid.set_tile(cell.x, cell.y, tile_types[index])
		collapsed.append(cell)
	if not collapsed.is_empty():
		cave_in_triggered.emit(origin, collapsed)
