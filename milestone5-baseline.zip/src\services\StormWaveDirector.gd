extends Node

class_name StormWaveDirector

const CRAWLER_SCENE_PATH: String = "res://src/entities/enemies/SubterraneanCrawler.tscn"
const TIMER_EPSILON: float = 0.001

@export_category("Wave Tuning")
@export_range(1, 64, 1) var base_enemy_count: int = 3
@export_range(0, 32, 1) var enemies_added_per_wave: int = 2
@export_range(1, 256, 1) var maximum_enemy_count: int = 32
@export_range(1, 128, 1) var minimum_spawn_radius_cells: int = 6
@export_range(2, 192, 1) var maximum_spawn_radius_cells: int = 22

@export_category("Storm Cycle")
@export_range(5.0, 1200.0, 1.0) var storm_reset_seconds: float = 180.0
@export_range(0.0, 120.0, 1.0) var reset_reduction_per_wave: float = 10.0
@export_range(5.0, 600.0, 1.0) var minimum_reset_seconds: float = 45.0

var player: Node2D
var world_grid: WorldGrid
var enemy_parent: Node

var wave_number: int = 0
var active_wave_number: int = 0
var active_enemy_count: int = 0
var active_wave: bool = false
var next_storm_reset: float = -1.0

var _signal_bus: SignalBus
var _crawler_scene: PackedScene
var _active_enemies: Array[Node] = []
var _previous_storm_time: float = -1.0
var _zero_crossing_armed: bool = false
var _driving_reset_countdown: bool = false
var _last_countdown_second: int = -1
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()


func setup(p_player: Node2D, p_world_grid: WorldGrid, p_enemy_parent: Node) -> void:
	player = p_player
	world_grid = p_world_grid
	enemy_parent = p_enemy_parent


func _ready() -> void:
	_rng.randomize()
	_signal_bus = SignalBus.get_instance()
	if not _signal_bus.cryo_storm_timer_updated.is_connected(_on_cryo_storm_timer_updated):
		_signal_bus.cryo_storm_timer_updated.connect(_on_cryo_storm_timer_updated)
	_load_crawler_scene()


func _process(delta: float) -> void:
	if not _driving_reset_countdown:
		return

	next_storm_reset = maxf(0.0, next_storm_reset - delta)
	var display_second: int = ceili(next_storm_reset)
	if display_second != _last_countdown_second:
		_last_countdown_second = display_second
		_signal_bus.cryo_storm_timer_updated.emit(next_storm_reset)

	if next_storm_reset <= TIMER_EPSILON:
		_driving_reset_countdown = false
		_signal_bus.cryo_storm_timer_updated.emit(0.0)


func start_wave() -> int:
	if not _dependencies_are_valid():
		push_warning("StormWaveDirector cannot start a wave before setup() receives valid dependencies.")
		return 0
	if not _load_crawler_scene():
		push_error("StormWaveDirector could not load %s" % CRAWLER_SCENE_PATH)
		return 0

	wave_number += 1
	active_wave_number = wave_number
	var requested_count: int = mini(
		maximum_enemy_count,
		base_enemy_count + (wave_number - 1) * enemies_added_per_wave
	)
	var spawn_cells: Array[Vector2i] = _find_spawn_cells(requested_count)
	var spawned_count: int = 0
	var base_targets: Array[Node2D] = _collect_base_targets()

	for spawn_cell: Vector2i in spawn_cells:
		var crawler: Node2D = _crawler_scene.instantiate() as Node2D
		if crawler == null:
			continue
		enemy_parent.add_child(crawler)
		crawler.global_position = _cell_to_world(spawn_cell)
		_configure_crawler_ai(crawler, base_targets)
		_active_enemies.append(crawler)
		crawler.tree_exited.connect(_on_enemy_tree_exited.bind(crawler), CONNECT_ONE_SHOT)
		spawned_count += 1

	active_enemy_count = _active_enemies.size()
	active_wave = active_enemy_count > 0
	_signal_bus.storm_wave_started.emit(wave_number, spawned_count)
	return spawned_count


func _on_cryo_storm_timer_updated(time_left: float) -> void:
	var normalized_time: float = maxf(0.0, time_left)
	if normalized_time > TIMER_EPSILON:
		_previous_storm_time = normalized_time
		_zero_crossing_armed = true
		if not _driving_reset_countdown:
			next_storm_reset = normalized_time
		return

	var crossed_zero: bool = _zero_crossing_armed and _previous_storm_time > TIMER_EPSILON
	_previous_storm_time = 0.0
	_zero_crossing_armed = false
	if not crossed_zero:
		return

	start_wave()
	_begin_next_storm_countdown()


func _begin_next_storm_countdown() -> void:
	var reduction: float = float(maxi(0, wave_number - 1)) * reset_reduction_per_wave
	next_storm_reset = maxf(minimum_reset_seconds, storm_reset_seconds - reduction)
	_last_countdown_second = ceili(next_storm_reset)
	_driving_reset_countdown = true
	_signal_bus.cryo_storm_timer_updated.emit(next_storm_reset)


func _dependencies_are_valid() -> bool:
	return is_instance_valid(player) and world_grid != null and is_instance_valid(enemy_parent)


func _load_crawler_scene() -> bool:
	if _crawler_scene != null:
		return true
	if not ResourceLoader.exists(CRAWLER_SCENE_PATH, "PackedScene"):
		return false
	_crawler_scene = load(CRAWLER_SCENE_PATH) as PackedScene
	return _crawler_scene != null


func _find_spawn_cells(count: int) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	var seen: Dictionary = {}
	var center: Vector2i = Vector2i(
		floori(player.global_position.x / float(WorldGrid.TILE_SIZE)),
		floori(player.global_position.y / float(WorldGrid.TILE_SIZE))
	)
	var min_radius: int = mini(minimum_spawn_radius_cells, maximum_spawn_radius_cells)
	var max_radius: int = maxi(minimum_spawn_radius_cells, maximum_spawn_radius_cells)
	var random_attempts: int = maxi(96, count * 32)

	for attempt: int in range(random_attempts):
		if result.size() >= count:
			break
		var angle: float = _rng.randf_range(0.0, TAU)
		var radius: float = _rng.randf_range(float(min_radius), float(max_radius))
		var candidate: Vector2i = center + Vector2i(
			roundi(cos(angle) * radius),
			roundi(sin(angle) * radius)
		)
		_try_add_spawn_cell(candidate, seen, result)

	if result.size() < count:
		for radius: int in range(min_radius, max_radius + 1):
			for x_offset: int in range(-radius, radius + 1):
				_try_add_spawn_cell(center + Vector2i(x_offset, -radius), seen, result)
				_try_add_spawn_cell(center + Vector2i(x_offset, radius), seen, result)
				if result.size() >= count:
					return result
			for y_offset: int in range(-radius + 1, radius):
				_try_add_spawn_cell(center + Vector2i(-radius, y_offset), seen, result)
				_try_add_spawn_cell(center + Vector2i(radius, y_offset), seen, result)
				if result.size() >= count:
					return result

	return result


func _try_add_spawn_cell(candidate: Vector2i, seen: Dictionary, result: Array[Vector2i]) -> void:
	if seen.has(candidate):
		return
	seen[candidate] = true
	if not world_grid.is_valid_position(candidate.x, candidate.y):
		return
	if world_grid.get_tile(candidate.x, candidate.y) != WorldGrid.TILE_AIR:
		return
	result.append(candidate)


func _cell_to_world(cell: Vector2i) -> Vector2:
	var half_tile: float = float(WorldGrid.TILE_SIZE) * 0.5
	return Vector2(
		float(cell.x * WorldGrid.TILE_SIZE) + half_tile,
		float(cell.y * WorldGrid.TILE_SIZE) + half_tile
	)


func _collect_base_targets() -> Array[Node2D]:
	var targets: Array[Node2D] = []
	var seen: Dictionary = {}
	for group_name: StringName in [&"base_targets", &"base_structures", &"power_machines", &"machines"]:
		for candidate: Node in get_tree().get_nodes_in_group(group_name):
			_add_base_target(candidate, seen, targets)

	var machine_container: Node = get_node_or_null("../MachineContainer")
	if machine_container != null:
		_collect_node2d_descendants(machine_container, seen, targets)
	return targets


func _collect_node2d_descendants(root: Node, seen: Dictionary, targets: Array[Node2D]) -> void:
	for child: Node in root.get_children():
		_add_base_target(child, seen, targets)
		_collect_node2d_descendants(child, seen, targets)


func _add_base_target(candidate: Node, seen: Dictionary, targets: Array[Node2D]) -> void:
	if not is_instance_valid(candidate) or not candidate is Node2D:
		return
	var instance_id: int = candidate.get_instance_id()
	if seen.has(instance_id):
		return
	seen[instance_id] = true
	targets.append(candidate as Node2D)


func _configure_crawler_ai(crawler: Node2D, base_targets: Array[Node2D]) -> void:
	_set_property_if_present(crawler, &"world_grid", world_grid)
	_set_property_if_present(crawler, &"signal_bus", _signal_bus)
	_set_property_if_present(crawler, &"target_structures", base_targets)
	_set_property_if_present(crawler, &"base_targets", base_targets)

	for method_name: StringName in [&"set_target_structures", &"set_base_targets", &"set_targets"]:
		if crawler.has_method(method_name):
			crawler.call(method_name, base_targets)
			break

	var nearest_target: Node2D = _nearest_base_target(crawler.global_position, base_targets)
	if nearest_target != null:
		_set_property_if_present(crawler, &"target", nearest_target)
		for method_name: StringName in [&"set_primary_target", &"set_target"]:
			if crawler.has_method(method_name):
				crawler.call(method_name, nearest_target)
				break

	_call_crawler_setup(crawler, base_targets, nearest_target)


func _call_crawler_setup(crawler: Node2D, base_targets: Array[Node2D], nearest_target: Node2D) -> void:
	if not crawler.has_method(&"setup"):
		return
	for method_info: Dictionary in crawler.get_method_list():
		if StringName(method_info.get("name", &"")) != &"setup":
			continue
		var argument_info: Array = method_info.get("args", [])
		var default_arguments: Array = method_info.get("default_args", [])
		var required_count: int = argument_info.size() - default_arguments.size()
		var values: Array = []
		for index: int in range(argument_info.size()):
			var descriptor: Dictionary = argument_info[index]
			var argument_name: String = String(descriptor.get("name", "")).to_lower()
			var value: Variant = null
			var resolved: bool = true
			if "signal" in argument_name or "bus" in argument_name:
				value = _signal_bus
			elif "drop" in argument_name or "parent" in argument_name:
				value = enemy_parent
			elif "world" in argument_name or "grid" in argument_name:
				value = world_grid
			elif "targets" in argument_name or "structures" in argument_name:
				value = base_targets
			elif "target" in argument_name or "base" in argument_name:
				value = nearest_target
			elif "player" in argument_name:
				value = player
			else:
				resolved = false

			if not resolved:
				if index < required_count:
					return
				break
			values.append(value)
		crawler.callv(&"setup", values)
		return


func _nearest_base_target(from_position: Vector2, targets: Array[Node2D]) -> Node2D:
	var nearest: Node2D
	var nearest_distance_squared: float = INF
	for target: Node2D in targets:
		if not is_instance_valid(target):
			continue
		var distance_squared: float = from_position.distance_squared_to(target.global_position)
		if distance_squared < nearest_distance_squared:
			nearest_distance_squared = distance_squared
			nearest = target
	return nearest


func _set_property_if_present(target: Object, property_name: StringName, value: Variant) -> bool:
	for property_info: Dictionary in target.get_property_list():
		if StringName(property_info.get("name", &"")) == property_name:
			target.set(property_name, value)
			return true
	return false


func _on_enemy_tree_exited(enemy: Node) -> void:
	_active_enemies.erase(enemy)
	active_enemy_count = _active_enemies.size()
	active_wave = active_enemy_count > 0
