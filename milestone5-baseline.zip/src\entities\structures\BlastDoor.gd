extends InteractableEntity

class_name BlastDoor

## The door descriptor remains a housing boundary regardless of collision state.
@export var approach_radius: float = 28.0
@export var close_delay: float = 0.7

var world_grid: WorldGrid
var is_open: bool = false
var _opened_for_player: bool = false
var _manual_closed: bool = false
var _close_remaining: float = 0.0
var _sprite: Sprite2D
var _collision: CollisionShape2D


func configure_item(definition: ItemDef, cell: Vector2i, grid: WorldGrid) -> void:
	item_id = definition.id
	grid_pos = cell
	housing_tags.assign(definition.housing_tags)
	world_grid = grid
	_publish_metadata()
	if is_node_ready():
		_update_visual()


func _ready() -> void:
	super._ready()
	add_to_group(&"blast_doors")
	add_to_group(&"placed_structures")
	if not housing_tags.has("door"):
		housing_tags.append("door")
	_publish_metadata()
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	_collision = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	if _collision == null:
		_collision = CollisionShape2D.new()
		_collision.name = "CollisionShape2D"
		add_child(_collision)
	if _collision.shape == null:
		var shape := RectangleShape2D.new()
		shape.size = Vector2(16.0, 16.0)
		_collision.shape = shape
	collision_layer = 1
	collision_mask = 0
	_collision.disabled = is_open
	_update_visual()


func _publish_metadata() -> void:
	set_meta(&"item_id", item_id)
	set_meta(&"grid_pos", grid_pos)
	set_meta(&"housing_tags", housing_tags.duplicate())


func set_open(open: bool) -> void:
	# Never close a collider through an actor. NPC/player callers can safely retry.
	if not open and _actor_overlaps_doorway():
		_close_remaining = close_delay
		return
	if is_open == open:
		return
	is_open = open
	if _collision != null:
		_collision.set_deferred(&"disabled", is_open)
	_update_visual()


func interact(actor: Node) -> void:
	if not can_interact(actor):
		return
	var was_open: bool = is_open
	set_open(not is_open)
	_manual_closed = was_open and not is_open
	if is_open:
		_opened_for_player = true
		_close_remaining = close_delay
	SignalBus.get_instance().show_hud_hint.emit("Hatch open" if is_open else "Hatch sealed")


func get_prompt_text() -> String:
	return "Close hatch" if is_open else "Open hatch"


func _physics_process(delta: float) -> void:
	var player_near: bool = _has_nearby_actor(&"player", approach_radius)
	if not player_near:
		_manual_closed = false
	if player_near and not _manual_closed:
		_opened_for_player = true
		_close_remaining = close_delay
		set_open(true)
	elif _opened_for_player:
		_close_remaining = maxf(0.0, _close_remaining - delta)
		if _close_remaining <= 0.0 and not _has_nearby_actor(&"colonists", approach_radius):
			set_open(false)
			if not is_open:
				_opened_for_player = false


func _has_nearby_actor(group: StringName, radius: float) -> bool:
	if not is_inside_tree():
		return false
	for candidate: Node in get_tree().get_nodes_in_group(group):
		var actor: Node2D = candidate as Node2D
		if actor != null and not actor.is_queued_for_deletion() and actor.global_position.distance_to(global_position) <= radius:
			return true
	return false


func _actor_overlaps_doorway() -> bool:
	if not is_inside_tree():
		return false
	var doorway := Rect2(global_position - Vector2(8.0, 8.0), Vector2(16.0, 16.0))
	for group: StringName in [&"player", &"colonists", &"enemies"]:
		for candidate: Node in get_tree().get_nodes_in_group(group):
			var actor: Node2D = candidate as Node2D
			if actor == null or actor.is_queued_for_deletion():
				continue
			var bounds := Rect2(actor.global_position - Vector2(6.0, 8.0), Vector2(12.0, 16.0))
			var actor_collision: CollisionShape2D = actor.get_node_or_null("CollisionShape2D") as CollisionShape2D
			if actor_collision != null and actor_collision.shape != null:
				bounds = actor_collision.global_transform * actor_collision.shape.get_rect()
			if bounds.intersects(doorway):
				return true
	return false


func _update_visual() -> void:
	if _sprite == null or item_id.is_empty():
		return
	var sprite_id: String = item_id + "_open" if is_open else item_id
	_sprite.texture = ProceduralEntitySprites.get_texture(sprite_id)
