extends Node
class_name HousingCoordinator

## Scene adapter supplies value descriptors to a pure validator, never flood-fills.
const NPC_SCENE: PackedScene = preload("res://src/entities/npcs/ColonistNpc.tscn")
var world_grid: WorldGrid
var machine_container: Node2D
var npc_container: Node2D
var actor: Node2D
var checker: NpcHousingChecker = NpcHousingChecker.new()
var _occupants: Dictionary = {}
var _elapsed: float = 0.0
var _dirty: bool = true
var _status: String = ""

func configure(grid: WorldGrid, structures: Node2D, residents: Node2D, player_actor: Node2D) -> void:
	world_grid = grid
	machine_container = structures
	npc_container = residents
	actor = player_actor
	var bus: SignalBus = SignalBus.get_instance()
	bus.tile_placed.connect(_on_tile_changed)
	bus.background_wall_changed.connect(_on_tile_changed)
	bus.structure_placed.connect(_on_structure_changed)
	machine_container.child_exiting_tree.connect(_on_structure_removed)
	call_deferred("scan_housing")

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed >= 2.0:
		_elapsed = 0.0
		# Periodic revalidation also catches removed doors/lights with no tile event.
		scan_housing()
	elif _dirty and _elapsed >= 0.25:
		scan_housing()

func collect_descriptors() -> Array[Dictionary]:
	var descriptors: Array[Dictionary] = []
	for child: Node in machine_container.get_children():
		if child.is_queued_for_deletion():
			continue
		if child is InteractableEntity:
			descriptors.append((child as InteractableEntity).get_housing_descriptor())
		elif child is Node2D:
			var tags: Array[String] = []
			tags.assign(child.get_meta("housing_tags", []))
			if not tags.is_empty():
				var position: Vector2 = (child as Node2D).global_position
				var cell := Vector2i(floori(position.x / 16.0), floori(position.y / 16.0))
				descriptors.append({"cell": cell, "tags": tags, "item_id": String(child.get_meta("item_id", ""))})
	return descriptors

func scan_housing() -> void:
	if world_grid == null:
		return
	_dirty = false
	var descriptors: Array[Dictionary] = collect_descriptors()
	var rooms: Dictionary = {}
	var failure: String = "Build an enclosed plated room with a door, heater and flare."
	for descriptor: Dictionary in descriptors:
		var tags: Array = descriptor.get("tags", [])
		if not tags.has("door"):
			continue
		var cell: Vector2i = descriptor["cell"]
		for direction: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
			var result: Dictionary = checker.validate_room(world_grid, cell + direction, descriptors)
			if bool(result.get("valid", false)):
				rooms[String(result["room_id"])] = result
			else:
				failure = String(result.get("reason", failure))
	for id: Variant in _occupants.keys():
		var npc: ColonistNpc = _occupants[id] as ColonistNpc
		if not rooms.has(id) or not is_instance_valid(npc):
			if is_instance_valid(npc):
				npc.dehouse()
				npc.queue_free()
			_occupants.erase(id)
	for id: String in rooms:
		if _occupants.has(id):
			continue
		var npc: ColonistNpc = NPC_SCENE.instantiate() as ColonistNpc
		npc.setup(rooms[id], world_grid)
		npc_container.add_child(npc)
		_occupants[id] = npc
		SignalBus.get_instance().npc_housed.emit(npc.npc_name, Vector2(rooms[id]["center"]))
	var message: String = "%d Quartermaster room%s occupied" % [_occupants.size(), "" if _occupants.size() == 1 else "s"] if not _occupants.is_empty() else failure
	if message != _status:
		_status = message
		SignalBus.get_instance().housing_status_changed.emit(message)

func get_housed_count() -> int:
	return _occupants.size()

func _on_tile_changed(_cell: Vector2i, _tile_id: int) -> void:
	_dirty = true

func _on_structure_changed(_cell: Vector2i, _item_id: String) -> void:
	_dirty = true

func _on_structure_removed(_node: Node) -> void:
	_dirty = true
