extends Resource
class_name ItemDef

## Declarative item behavior consumed by placement, crafting and economy services.
@export var id: String = ""
@export var display_name: String = "Item"
@export var stack_size: int = 99
@export var is_consumable: bool = false
@export var base_value: int = 5
@export_enum("foreground", "background_wall", "structure", "consumable") var place_layer: String = "foreground"
@export var description: String = ""
@export var color: Color = Color.WHITE
@export var tile_id: int = -1
@export_file("*.tscn") var scene_path: String = ""
@export var station_kind: String = ""
@export var housing_tags: Array[String] = []
@export var placement_rules: Array[String] = []
## Effect keys are semantic capabilities, never special item-ID branches.
@export var effects: Dictionary = {}
@export var unique_upgrade: bool = false
@export var sellable: bool = false
@export var quick_slot: int = -1
@export var underwater_o2_multiplier: float = 1.0
@export var water_chill_multiplier: float = 1.0
@export var equipment_slot: String = ""
