extends CharacterBody2D

class_name SubterraneanCrawler

const ITEM_PICKUP_SCENE_PATH: String = "res://src/entities/items/ItemPickup.tscn"

@export var signal_bus: SignalBus
@export var move_speed: float = 48.0
@export var acceleration: float = 260.0
@export var jump_velocity: float = -245.0
@export var gravity_scale: float = 1.0
@export var max_health: float = 55.0
@export var contact_damage: float = 10.0
@export var contact_damage_interval: float = 0.8
@export var target_refresh_interval: float = 0.35
@export var drop_item_id: String = "coal"
@export var drop_count: int = 1

var health: float = 55.0

var _target: Node2D
var _target_refresh_remaining: float = 0.0
var _dead: bool = false
var _gravity: float = 980.0
var _sprite: Sprite2D
var _contact_area: Area2D
var _contact_cooldowns: Dictionary = {}
var _drop_parent: Node


func setup(p_signal_bus: SignalBus = null, p_drop_parent: Node = null) -> void:
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	_drop_parent = p_drop_parent


func configure(p_signal_bus: SignalBus = null, p_drop_parent: Node = null) -> void:
	setup(p_signal_bus, p_drop_parent)


func _ready() -> void:
	add_to_group("crawler")
	add_to_group("enemies")
	health = max_health
	_gravity = float(ProjectSettings.get_setting("physics/2d/default_gravity", 980.0))
	_ensure_scene_nodes()
	_create_procedural_sprite()


func _physics_process(delta: float) -> void:
	if _dead:
		return
	_update_contact_cooldowns(delta)
	_apply_contact_damage()

	_target_refresh_remaining -= delta
	if _target_refresh_remaining <= 0.0 or not _is_valid_target(_target):
		_target_refresh_remaining = maxf(0.05, target_refresh_interval)
		_target = _find_nearest_base_target()

	var direction: float = 0.0
	if _is_valid_target(_target):
		direction = signf(_target.global_position.x - global_position.x)
	velocity.x = move_toward(velocity.x, direction * move_speed, acceleration * delta)

	if not is_on_floor():
		velocity.y += _gravity * gravity_scale * delta
	elif velocity.y > 0.0:
		velocity.y = 0.0

	if direction != 0.0 and is_on_floor() and (is_on_wall() or _has_obstacle_ahead(direction)):
		velocity.y = jump_velocity

	move_and_slide()
	if _sprite != null and direction != 0.0:
		_sprite.flip_h = direction < 0.0


func take_damage(amount: float) -> void:
	if _dead or amount <= 0.0:
		return
	health = maxf(0.0, health - amount)
	if health <= 0.0:
		_die()


func apply_damage(amount: float) -> void:
	take_damage(amount)


func damage(amount: float) -> void:
	take_damage(amount)


func get_health() -> float:
	return health


func is_alive() -> bool:
	return not _dead and health > 0.0


func _find_nearest_base_target() -> Node2D:
	var priority_target: Node2D = _find_nearest_target_in_groups([&"power_producers", &"heaters"], true)
	if priority_target != null:
		return priority_target
	return _find_nearest_target_in_groups([&"base_targets"], false)


func _find_nearest_target_in_groups(group_names: Array[StringName], require_power: bool) -> Node2D:
	var nearest: Node2D = null
	var nearest_distance_squared: float = INF
	var seen: Dictionary = {}
	for group_name: StringName in group_names:
		for candidate: Node in get_tree().get_nodes_in_group(group_name):
			var target_2d: Node2D = candidate as Node2D
			if not _is_valid_target(target_2d) or seen.has(candidate.get_instance_id()):
				continue
			seen[candidate.get_instance_id()] = true
			if require_power and not _is_target_powered(target_2d):
				continue
			var distance_squared: float = global_position.distance_squared_to(target_2d.global_position)
			if distance_squared < nearest_distance_squared:
				nearest = target_2d
				nearest_distance_squared = distance_squared
	return nearest


func _is_target_powered(candidate: Node2D) -> bool:
	if candidate.has_method("get_power_output"):
		return float(candidate.call("get_power_output")) > 0.0
	if candidate.has_method("is_powered"):
		return bool(candidate.call("is_powered"))
	return false


func _is_valid_target(candidate: Node2D) -> bool:
	if candidate == null or not is_instance_valid(candidate) or candidate.is_queued_for_deletion():
		return false
	if not candidate.is_inside_tree() or not candidate.is_in_group("base_targets"):
		return false
	if candidate.has_method("is_active"):
		return bool(candidate.call("is_active"))
	if candidate.has_method("is_powered"):
		return bool(candidate.call("is_powered"))
	return true


func _has_obstacle_ahead(direction: float) -> bool:
	if not is_inside_tree():
		return false
	var from := global_position + Vector2(direction * 5.0, 3.0)
	var to := from + Vector2(direction * 8.0, 0.0)
	var query := PhysicsRayQueryParameters2D.create(from, to, collision_mask, [get_rid()])
	query.collide_with_areas = false
	return not get_world_2d().direct_space_state.intersect_ray(query).is_empty()


func _apply_contact_damage() -> void:
	if _contact_area == null:
		return
	for body: Node2D in _contact_area.get_overlapping_bodies():
		var is_player: bool = body.is_in_group("player") or body.name == &"Player"
		if body == self or (not is_player and not body.is_in_group("machines")):
			continue
		var instance_id: int = body.get_instance_id()
		if float(_contact_cooldowns.get(instance_id, 0.0)) > 0.0:
			continue
		_damage_contact_body(body)
		_contact_cooldowns[instance_id] = maxf(0.05, contact_damage_interval)


func _damage_contact_body(body: Node) -> void:
	if body.has_method("take_damage"):
		body.call("take_damage", contact_damage)
	elif body.has_method("apply_damage"):
		body.call("apply_damage", contact_damage)
	elif body.is_in_group("player") or body.name == &"Player":
		GlobalGameState.set_hp(GlobalGameState.get_hp() - contact_damage)


func _update_contact_cooldowns(delta: float) -> void:
	for key: Variant in _contact_cooldowns.keys():
		var remaining: float = float(_contact_cooldowns[key]) - delta
		if remaining <= 0.0:
			_contact_cooldowns.erase(key)
		else:
			_contact_cooldowns[key] = remaining


func _die() -> void:
	if _dead:
		return
	_dead = true
	velocity = Vector2.ZERO
	_spawn_drop()
	var bus: SignalBus = signal_bus
	if bus == null:
		bus = SignalBus.get_instance()
	if bus != null:
		bus.enemy_defeated.emit(global_position, drop_item_id)
	queue_free()


func _spawn_drop() -> void:
	if drop_item_id.is_empty() or drop_count <= 0:
		return
	var pickup_scene: PackedScene = load(ITEM_PICKUP_SCENE_PATH) as PackedScene
	if pickup_scene == null:
		return
	var pickup: Node2D = pickup_scene.instantiate() as Node2D
	if pickup == null:
		return
	if pickup.has_method("setup"):
		pickup.call("setup", drop_item_id, drop_count)
	var parent_for_drop: Node = _drop_parent
	if not is_instance_valid(parent_for_drop):
		parent_for_drop = get_parent()
	if parent_for_drop == null:
		parent_for_drop = get_tree().current_scene
	if parent_for_drop == null:
		parent_for_drop = get_tree().root
	parent_for_drop.add_child(pickup)
	pickup.global_position = global_position


func _ensure_scene_nodes() -> void:
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)

	var body_collision: CollisionShape2D = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if body_collision == null:
		body_collision = CollisionShape2D.new()
		body_collision.name = "CollisionShape2D"
		add_child(body_collision)
	if body_collision.shape == null:
		var body_shape := CapsuleShape2D.new()
		body_shape.radius = 6.0
		body_shape.height = 12.0
		body_collision.shape = body_shape

	_contact_area = get_node_or_null("ContactArea") as Area2D
	if _contact_area == null:
		_contact_area = Area2D.new()
		_contact_area.name = "ContactArea"
		_contact_area.collision_layer = 0
		_contact_area.collision_mask = 3
		add_child(_contact_area)
	var contact_shape_node: CollisionShape2D = _contact_area.get_node_or_null("CollisionShape2D") as CollisionShape2D
	if contact_shape_node == null:
		contact_shape_node = CollisionShape2D.new()
		contact_shape_node.name = "CollisionShape2D"
		_contact_area.add_child(contact_shape_node)
	if contact_shape_node.shape == null:
		var contact_shape := CircleShape2D.new()
		contact_shape.radius = 9.0
		contact_shape_node.shape = contact_shape


func _create_procedural_sprite() -> void:
	if _sprite == null:
		return
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var outline := Color("19161e")
	var shell_dark := Color("49344f")
	var shell := Color("755179")
	var shell_light := Color("a66f91")
	var eye := Color("7af5d2")
	var claw := Color("b7a7a0")

	for y in range(5, 12):
		for x in range(2, 14):
			var dx: float = (float(x) - 7.5) / 6.0
			var dy: float = (float(y) - 8.0) / 4.0
			if dx * dx + dy * dy <= 1.0:
				image.set_pixel(x, y, outline)
	for y in range(6, 11):
		for x in range(3, 13):
			var segment_color: Color = shell if int(x / 2) % 2 == 0 else shell_dark
			image.set_pixel(x, y, segment_color)
	for x in range(5, 11):
		image.set_pixel(x, 6, shell_light)
	image.set_pixel(3, 8, eye)
	image.set_pixel(2, 8, outline)
	for x in range(3, 13, 3):
		image.set_pixel(x, 12, claw)
		if x + 1 < 16:
			image.set_pixel(x + 1, 13, claw)
	image.set_pixel(13, 7, shell_dark)
	image.set_pixel(14, 6, shell_dark)
	_sprite.texture = ImageTexture.create_from_image(image)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
