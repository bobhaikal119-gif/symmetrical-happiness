extends Node2D

class_name LiquidRenderer

## Read-only scene adapter: rendering and finite decorative splash particles only.
## Draw work is restricted to camera visibility intersected with render radius.
const TILE_SIZE: int = WorldGrid.TILE_SIZE
const REDRAW_INTERVAL: float = 0.08
const HARD_PARTICLE_LIMIT: int = 128
const MAX_BURST_PARTICLES: int = 14
const INK := Color("0e1018")

var liquid_grid: LiquidGrid
var _render_distance: int = 64
var _particle_budget: int = 96
var _fast_effects: bool = false
var _animation_time: float = 0.0
var _redraw_elapsed: float = 0.0
var _bounds := Rect2i()
var _dirty: bool = true
var _particles: Array[Dictionary] = []
var _burst_serial: int = 0
var _bus: SignalBus
var _lava_texture: Texture2D = BlockTextures.get_tile_texture(WorldGrid.TILE_LAVA)


func configure(grid: LiquidGrid) -> void:
	if liquid_grid != null and liquid_grid.cells_changed.is_connected(_on_cells_changed):
		liquid_grid.cells_changed.disconnect(_on_cells_changed)
	liquid_grid = grid
	if liquid_grid != null:
		liquid_grid.cells_changed.connect(_on_cells_changed)
	_dirty = true
	queue_redraw()


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# Liquid highlights must remain legible against dark aquifers in either
	# lighting mode. Alpha still reveals terrain/actors below the cyan volume.
	var liquid_material := CanvasItemMaterial.new()
	liquid_material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	material = liquid_material
	z_index = 1
	_render_distance = clampi(int(SettingsManager.get_setting("optimization", "render_distance", 64)), 24, 128)
	_particle_budget = clampi(int(SettingsManager.get_setting("optimization", "max_particles", 96)), 0, HARD_PARTICLE_LIMIT)
	_fast_effects = int(SettingsManager.get_setting("optimization", "lighting_quality", 0)) != 0
	_bus = SignalBus.get_instance()
	_bus.liquid_splashed.connect(_on_liquid_splashed)
	_bus.setting_changed.connect(_on_setting_changed)
	_dirty = true


func _process(delta: float) -> void:
	_animation_time += delta
	_redraw_elapsed += delta
	var next_bounds: Rect2i = _visible_tile_bounds()
	if next_bounds != _bounds:
		_bounds = next_bounds
		_dirty = true
	_update_particles(delta)
	if _dirty or not _particles.is_empty() or _redraw_elapsed >= REDRAW_INTERVAL:
		_redraw_elapsed = 0.0
		_dirty = false
		queue_redraw()


func _draw() -> void:
	if liquid_grid == null:
		return
	for y: int in range(_bounds.position.y, _bounds.end.y):
		for x: int in range(_bounds.position.x, _bounds.end.x):
			var liquid_id: int = liquid_grid.get_liquid(x, y)
			if liquid_id != LiquidGrid.NONE:
				_draw_volume(Vector2i(x, y), liquid_id, liquid_grid.get_volume(x, y))
	for particle: Dictionary in _particles:
		var point: Vector2 = particle["position"]
		if not _bounds.has_point(Vector2i(floori(point.x / TILE_SIZE), floori(point.y / TILE_SIZE))):
			continue
		var life: float = float(particle["life"])
		var lifetime: float = float(particle["lifetime"])
		var color: Color = particle["color"]
		color.a *= clampf(life / lifetime, 0.0, 1.0)
		var pixel_point: Vector2 = point.floor()
		draw_rect(Rect2(pixel_point - Vector2.ONE, Vector2(3.0, 3.0)), Color(INK, color.a * 0.7))
		draw_rect(Rect2(pixel_point, Vector2.ONE), color)


func _draw_volume(cell: Vector2i, liquid_id: int, volume: float) -> void:
	if volume <= 0.0:
		return
	var origin := Vector2(cell * TILE_SIZE)
	var pixel_height: float = maxf(1.0, ceilf(volume * TILE_SIZE))
	var top_y: float = origin.y + TILE_SIZE - pixel_height
	var above_id: int = liquid_grid.get_liquid(cell.x, cell.y - 1)
	var above_volume: float = liquid_grid.get_volume(cell.x, cell.y - 1)
	var surface: bool = volume < 1.0 - 0.00001 or above_id != liquid_id or above_volume <= 0.0
	var depth: int = 0
	for offset: int in range(1, 6):
		if liquid_grid.get_liquid(cell.x, cell.y - offset) != liquid_id or liquid_grid.get_volume(cell.x, cell.y - offset) < 0.99:
			break
		depth += 1
	var base := Color(0.10, 0.47, 0.70, 0.61)
	var highlight := Color(0.61, 0.94, 1.0, 0.90)
	if liquid_id == LiquidGrid.LAVA:
		base = Color(0.96, 0.22, 0.035, 0.90)
		highlight = Color(1.0, 0.82, 0.23, 0.96)
	var depth_shade: float = float(depth) * (0.065 if liquid_id == LiquidGrid.WATER else 0.035)
	base = base.darkened(depth_shade)
	base.a = minf(0.87, base.a + float(depth) * 0.025) if liquid_id == LiquidGrid.WATER else 0.94
	var volume_rect := Rect2(Vector2(origin.x, top_y), Vector2(TILE_SIZE, pixel_height))
	if liquid_id == LiquidGrid.LAVA:
		# Clip the authored magma art at the real fill height; never stretch a
		# whole block into a shallow puddle or change any simulated volume.
		var source_rect := Rect2(0.0, TILE_SIZE - pixel_height, TILE_SIZE, pixel_height)
		draw_texture_rect_region(_lava_texture, volume_rect, source_rect, Color(1.0 - depth_shade, 1.0 - depth_shade, 1.0 - depth_shade, base.a))
	else:
		draw_rect(volume_rect, base)
	if pixel_height > 3.0:
		draw_rect(Rect2(Vector2(origin.x, origin.y + TILE_SIZE - 2.0), Vector2(TILE_SIZE, 2.0)), Color(base.darkened(0.12), base.a))
	if surface:
		draw_rect(Rect2(Vector2(origin.x, top_y), Vector2(TILE_SIZE, 1.0)), Color(INK, 0.45))
		var phase: int = int(_animation_time * (5.0 if liquid_id == LiquidGrid.WATER else 3.0))
		for index: int in range(3):
			var foam_x: int = posmod(cell.x * 7 + cell.y * 3 + index * 5 + phase, TILE_SIZE - 2)
			var foam_y: float = top_y + (1.0 if (index + phase) % 3 == 0 and pixel_height > 2.0 else 0.0)
			draw_rect(Rect2(Vector2(origin.x + foam_x, foam_y), Vector2(3.0, 1.0)), highlight)
	elif not _fast_effects and (cell.x * 7 + cell.y * 11 + int(_animation_time * 3.0)) % 13 == 0:
		draw_rect(Rect2(origin + Vector2(5.0, 9.0), Vector2(3.0, 1.0)), Color(highlight, 0.23))


func _visible_tile_bounds() -> Rect2i:
	if liquid_grid == null or not is_inside_tree():
		return Rect2i()
	var inverse: Transform2D = get_global_transform_with_canvas().affine_inverse()
	var size: Vector2 = get_viewport_rect().size
	var corners: Array[Vector2] = [inverse * Vector2.ZERO, inverse * Vector2(size.x, 0.0), inverse * size, inverse * Vector2(0.0, size.y)]
	var minimum: Vector2 = corners[0]
	var maximum: Vector2 = corners[0]
	for point: Vector2 in corners:
		minimum.x = minf(minimum.x, point.x)
		minimum.y = minf(minimum.y, point.y)
		maximum.x = maxf(maximum.x, point.x)
		maximum.y = maxf(maximum.y, point.y)
	var start := Vector2i(clampi(floori(minimum.x / TILE_SIZE) - 1, 0, liquid_grid.width), clampi(floori(minimum.y / TILE_SIZE) - 1, 0, liquid_grid.height))
	var end := Vector2i(clampi(ceili(maximum.x / TILE_SIZE) + 1, 0, liquid_grid.width), clampi(ceili(maximum.y / TILE_SIZE) + 1, 0, liquid_grid.height))
	var camera_center: Vector2 = inverse * (size * 0.5)
	var center := Vector2i(floori(camera_center.x / TILE_SIZE), floori(camera_center.y / TILE_SIZE))
	var radius_bounds := Rect2i(center - Vector2i.ONE * _render_distance, Vector2i.ONE * (_render_distance * 2 + 1))
	return Rect2i(start, end - start).intersection(radius_bounds)


func _on_cells_changed(cells: Array[Vector2i]) -> void:
	for cell: Vector2i in cells:
		if _bounds.has_point(cell):
			_dirty = true
			return


func _on_liquid_splashed(world_pos: Vector2, liquid_id: int, intensity: float) -> void:
	if liquid_grid == null or not world_pos.is_finite() or not is_finite(intensity) or intensity <= 0.0 or (liquid_id != LiquidGrid.WATER and liquid_id != LiquidGrid.LAVA):
		return
	var origin: Vector2 = to_local(world_pos)
	var cell := Vector2i(floori(origin.x / TILE_SIZE), floori(origin.y / TILE_SIZE))
	if not _bounds.has_point(cell):
		return
	var available: int = _particle_budget - _particles.size()
	var count: int = mini(available, mini(MAX_BURST_PARTICLES, ceili(clampf(intensity, 0.0, 2.0) * (5.0 if _fast_effects else 9.0))))
	if count <= 0:
		return
	_burst_serial += 1
	var color := Color(0.60, 0.92, 1.0, 0.92) if liquid_id == LiquidGrid.WATER else Color(1.0, 0.65, 0.12, 1.0)
	for index: int in range(count):
		var fraction: float = float(index + 1) / float(count + 1)
		var variation: float = float(posmod(_burst_serial * 17 + index * 11, 9)) / 9.0
		var lifetime: float = 0.25 + variation * 0.30
		_particles.append({"position": origin, "velocity": Vector2((fraction - 0.5) * 115.0, -35.0 - variation * 60.0), "life": lifetime, "lifetime": lifetime, "color": color})
	_dirty = true


func _update_particles(delta: float) -> void:
	for index: int in range(_particles.size() - 1, -1, -1):
		var particle: Dictionary = _particles[index]
		var life: float = float(particle["life"]) - delta
		if life <= 0.0:
			_particles.remove_at(index)
			_dirty = true
			continue
		var velocity: Vector2 = particle["velocity"]
		velocity.y += 180.0 * delta
		particle["life"] = life
		particle["velocity"] = velocity
		particle["position"] = Vector2(particle["position"]) + velocity * delta


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section != "optimization":
		return
	if key == "render_distance":
		_render_distance = clampi(int(value), 24, 128)
	elif key == "max_particles":
		_particle_budget = clampi(int(value), 0, HARD_PARTICLE_LIMIT)
		if _particles.size() > _particle_budget:
			_particles.resize(_particle_budget)
	elif key == "lighting_quality":
		_fast_effects = int(value) != 0
	_dirty = true


func get_live_particle_count() -> int:
	return _particles.size()


func get_rendered_tile_bounds() -> Rect2i:
	return _bounds
