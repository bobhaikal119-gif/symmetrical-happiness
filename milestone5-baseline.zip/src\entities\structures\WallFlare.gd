extends Node2D

class_name WallFlare

"""Procedural 16x16 cave light with no external texture dependency."""

@onready var light: PointLight2D = $PointLight2D
@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	_create_procedural_sprite()
	light.texture = ProceduralLightTexture.create_radial_texture(128)
	light.color = Color(1.0, 0.72, 0.22)
	light.energy = 1.2
	light.texture_scale = 0.85

func _create_procedural_sprite() -> void:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	var dark := Color("3c2518")
	var yellow := Color("ffc43d")
	var orange := Color("f06b24")
	var white_hot := Color("fff4bd")
	for y in range(5, 15):
		for x in range(6, 10):
			image.set_pixel(x, y, dark if x == 6 else yellow)
	for x in range(5, 11):
		image.set_pixel(x, 5, dark)
	image.set_pixel(7, 4, orange)
	image.set_pixel(8, 4, orange)
	image.set_pixel(7, 3, white_hot)
	image.set_pixel(8, 2, orange)
	sprite.texture = ImageTexture.create_from_image(image)
