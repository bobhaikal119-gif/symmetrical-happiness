extends Node
class_name SessionPresentation

## Camera/ambience/effect budgets. No world rules or transaction policy live here.
const PICKUP_SCENE: PackedScene = preload("res://src/entities/items/ItemPickup.tscn")
var actor: Node2D
var camera: Camera2D
var ambience: CanvasModulate
var item_parent: Node2D
var inventory: CraftingComponent
var _shake: Tween
var _darkness: float = 0.0
var _emitters: Dictionary = {}
var _budget: int = 96
var _elapsed: float = 0.0

func configure(player_actor: Node2D, view_camera: Camera2D, modulation: CanvasModulate, drops: Node2D, crafting: CraftingComponent) -> void:
	actor = player_actor
	camera = view_camera
	ambience = modulation
	item_parent = drops
	inventory = crafting
	var bus: SignalBus = SignalBus.get_instance()
	bus.setting_changed.connect(_on_setting_changed)
	bus.cave_in_triggered.connect(_on_cave_in)
	get_tree().node_added.connect(_on_node_added)
	_budget = int(SettingsManager.get_setting("optimization", "max_particles", 96))
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
	camera.global_position = actor.global_position
	_apply_darkness()

func _process(delta: float) -> void:
	if actor == null or get_tree().paused:
		return
	camera.global_position = actor.global_position
	_elapsed += delta
	if _elapsed >= 0.25:
		_elapsed = 0.0
		_enforce_budget()

func set_darkness_intensity(value: float) -> void:
	_darkness = clampf(value, 0.0, 1.0)
	_apply_darkness()

func spawn_mined_item(cell: Vector2i, tile_id: int) -> void:
	var item_id: String = ItemRegistry.get_instance().get_drop_item(tile_id)
	if item_id.is_empty():
		return
	if get_tree().get_nodes_in_group("item_pickups").size() >= _budget and _credit(item_id, 1):
		return
	var pickup: ItemPickup = PICKUP_SCENE.instantiate() as ItemPickup
	pickup.setup(item_id, 1)
	item_parent.add_child(pickup)
	pickup.global_position = Vector2(cell * 16) + Vector2(8, 8)

func _credit(item_id: String, quantity: int) -> bool:
	if inventory == null or not inventory.add_item(item_id, quantity):
		return false
	SignalBus.get_instance().item_collected.emit(item_id, quantity)
	return true

func _on_node_added(node: Node) -> void:
	if node is CPUParticles2D or node is GPUParticles2D:
		call_deferred("_register_emitter", node)
	elif node is ItemPickup:
		call_deferred("_enforce_budget")

func _register_emitter(node: Node) -> void:
	if is_instance_valid(node):
		_emitters[node.get_instance_id()] = {"node": node, "amount": int(node.get("amount")), "emitting": bool(node.get("emitting")), "suppressed": false}
		_enforce_budget()

func _enforce_budget() -> void:
	var left: int = _budget
	for id: Variant in _emitters.keys():
		var entry: Dictionary = _emitters[id]
		if not is_instance_valid(entry["node"]):
			_emitters.erase(id)
			continue
		var emitter: Node = entry["node"]
		if not bool(entry["suppressed"]) or bool(emitter.get("emitting")):
			entry["emitting"] = bool(emitter.get("emitting"))
		var allowed: int = mini(int(entry["amount"]), left) if bool(entry["emitting"]) else 0
		if allowed > 0:
			emitter.set("amount", allowed)
			emitter.set("emitting", true)
			entry["suppressed"] = false
			left -= allowed
		elif bool(entry["emitting"]):
			emitter.set("emitting", false)
			entry["suppressed"] = true
	var retained: int = 0
	var stacks: Dictionary = {}
	for node: Node in get_tree().get_nodes_in_group("item_pickups"):
		var pickup: ItemPickup = node as ItemPickup
		if pickup == null or pickup.is_queued_for_deletion() or pickup._collected:
			continue
		if retained < _budget:
			retained += 1
			stacks[pickup.item_id] = pickup
			continue
		var stack: ItemPickup = stacks.get(pickup.item_id) as ItemPickup
		if is_instance_valid(stack):
			stack.setup(stack.item_id, stack.count + pickup.count)
		elif not _credit(pickup.item_id, pickup.count):
			continue
		pickup._collected = true
		pickup.queue_free()

func _apply_darkness() -> void:
	if ambience != null:
		var preferred: float = float(SettingsManager.get_setting("graphics", "ambient_darkness", 0.0))
		var combined: float = 1.0 - (1.0 - preferred) * (1.0 - _darkness)
		ambience.color = Color(0.12, 0.14, 0.19).lerp(Color(0.025, 0.03, 0.05), combined)

func _on_cave_in(_origin: Vector2i, cells: Array[Vector2i]) -> void:
	if _shake != null and _shake.is_valid():
		_shake.kill()
	camera.offset = Vector2.ZERO
	var strength: float = clampf(3.0 + cells.size() * 0.35, 4.0, 14.0) * float(SettingsManager.get_setting("general", "screen_shake", 1.0))
	if is_zero_approx(strength):
		return
	_shake = create_tween()
	_shake.tween_property(camera, "offset", Vector2(randf_range(-strength, strength), randf_range(-strength, strength)), 0.06)
	_shake.tween_property(camera, "offset", Vector2.ZERO, 0.22)

func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section == "graphics" and key == "ambient_darkness":
		_apply_darkness()
	elif section == "optimization" and key == "max_particles":
		_budget = int(value)
		_enforce_budget()
	elif section == "general" and key == "screen_shake":
		if _shake != null and _shake.is_valid():
			_shake.kill()
		camera.offset = Vector2.ZERO
