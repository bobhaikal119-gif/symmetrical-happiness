extends Node

## Explicit liquid-only checkpoints. No class_name: the autoload owns this name.
## A checkpoint belongs to one seed AND exact foreground/background terrain state;
## it never silently imports fluid into a new expedition or restores stale terrain.
const SAVE_VERSION: int = 1
const SAVE_FORMAT: String = "DEEPWELL_LIQUIDS"
const DEFAULT_PATH: String = "user://liquids.save"
const MAX_SAVE_BYTES: int = 128 * 1024 * 1024

var _world: WorldGrid
var _liquids: LiquidGrid
var _bus: SignalBus


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_connect_requests()


func configure(world: WorldGrid, liquids: LiquidGrid) -> void:
	_world = world
	_liquids = liquids
	_connect_requests()
	# Loading is intentionally explicit, even when a default checkpoint exists.


func save_liquids(path: String = DEFAULT_PATH) -> bool:
	var problem: String = _configuration_error(path)
	if not problem.is_empty():
		return _complete(false, problem)
	var signature: String = _terrain_signature()
	if signature.is_empty():
		return _complete(false, "Liquid save failed: terrain identity could not be computed.")
	var snapshot: Dictionary = {
		"format": SAVE_FORMAT,
		"version": SAVE_VERSION,
		"world_seed": _world.seed,
		"width": _liquids.width,
		"height": _liquids.height,
		"terrain_sha256": signature,
		"liquids": _liquids.serialize(),
	}
	var temporary: String = path + ".tmp"
	var output: FileAccess = FileAccess.open(temporary, FileAccess.WRITE)
	if output == null:
		return _complete(false, "Liquid save failed: cannot open checkpoint for writing.")
	output.store_var(snapshot, false)
	output.flush()
	var write_error: Error = output.get_error()
	output.close()
	if write_error != OK:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(temporary))
		return _complete(false, "Liquid save failed: checkpoint write was incomplete.")
	# Replace only after a complete flushed write. A failed rename preserves the old save.
	var rename_error: Error = DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(path))
	if rename_error != OK:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(temporary))
		return _complete(false, "Liquid save failed: cannot atomically replace checkpoint.")
	return _complete(true, "Liquid checkpoint saved for seed %d." % _world.seed)


func load_liquids(path: String = DEFAULT_PATH) -> bool:
	var problem: String = _configuration_error(path)
	if not problem.is_empty():
		return _complete(false, problem)
	var input: FileAccess = FileAccess.open(path, FileAccess.READ)
	if input == null:
		return _complete(false, "Liquid load failed: checkpoint not found or unreadable.")
	if input.get_length() <= 0 or input.get_length() > MAX_SAVE_BYTES:
		input.close()
		return _complete(false, "Liquid load refused: invalid checkpoint size.")
	# Never permit object deserialization or executable resource reconstruction.
	var decoded: Variant = input.get_var(false)
	var read_error: Error = input.get_error()
	var completely_read: bool = input.get_position() == input.get_length()
	input.close()
	if read_error != OK or not completely_read:
		return _complete(false, "Liquid load refused: checkpoint is corrupt or incomplete.")
	problem = _validate_snapshot(decoded)
	if not problem.is_empty():
		return _complete(false, problem)
	var snapshot: Dictionary = decoded
	var liquid_snapshot: Dictionary = snapshot["liquids"]
	# LiquidGrid validates all cells/types/finites/reserves before an atomic replace.
	if not _liquids.deserialize(liquid_snapshot):
		return _complete(false, "Liquid load refused: invalid liquid state; current liquids unchanged.")
	return _complete(true, "Liquid checkpoint restored for seed %d." % _world.seed)


func _configuration_error(path: String) -> String:
	if path.strip_edges().is_empty():
		return "Liquid checkpoint failed: a file path is required."
	if _world == null or _liquids == null:
		return "Liquid checkpoint unavailable: start an expedition first."
	if _liquids.world_grid != _world:
		return "Liquid checkpoint refused: liquid and terrain worlds do not match."
	if _liquids.width <= 0 or _liquids.height <= 0 or _liquids.width > WorldGrid.GRID_SIZE or _liquids.height > WorldGrid.GRID_SIZE:
		return "Liquid checkpoint refused: invalid world dimensions."
	return ""


func _validate_snapshot(value: Variant) -> String:
	if value is not Dictionary:
		return "Liquid load refused: checkpoint is not a value snapshot."
	var snapshot: Dictionary = value
	if snapshot.get("format") is not String or snapshot.get("format") != SAVE_FORMAT:
		return "Liquid load refused: unrecognized checkpoint format."
	if snapshot.get("version") is not int or int(snapshot["version"]) != SAVE_VERSION:
		return "Liquid load refused: unsupported checkpoint version."
	if snapshot.get("world_seed") is not int or int(snapshot["world_seed"]) != _world.seed:
		return "Liquid load refused: checkpoint belongs to a different world seed."
	if snapshot.get("width") is not int or snapshot.get("height") is not int:
		return "Liquid load refused: missing world dimensions."
	if int(snapshot["width"]) != _liquids.width or int(snapshot["height"]) != _liquids.height:
		return "Liquid load refused: checkpoint world dimensions differ."
	if snapshot.get("terrain_sha256") is not String or String(snapshot["terrain_sha256"]).length() != 64:
		return "Liquid load refused: missing terrain identity."
	var signature: String = _terrain_signature()
	if signature.is_empty() or String(snapshot["terrain_sha256"]) != signature:
		return "Liquid load refused: terrain has changed since this checkpoint."
	if snapshot.get("liquids") is not Dictionary:
		return "Liquid load refused: liquid snapshot is missing."
	var liquid_snapshot: Dictionary = snapshot["liquids"]
	if liquid_snapshot.get("width") is not int or liquid_snapshot.get("height") is not int:
		return "Liquid load refused: invalid liquid dimensions."
	if int(liquid_snapshot["width"]) != _liquids.width or int(liquid_snapshot["height"]) != _liquids.height:
		return "Liquid load refused: inconsistent liquid dimensions."
	return ""


func _terrain_signature() -> String:
	# Bounded 512² pass only on explicit save/load; no per-frame hashing or String.hash collisions.
	var terrain := PackedInt32Array()
	terrain.resize(WorldGrid.GRID_SIZE * WorldGrid.GRID_SIZE * 2)
	var index: int = 0
	for y: int in range(WorldGrid.GRID_SIZE):
		for x: int in range(WorldGrid.GRID_SIZE):
			terrain[index] = _world.get_tile(x, y)
			terrain[index + 1] = _world.get_background_wall(x, y)
			index += 2
	var context := HashingContext.new()
	if context.start(HashingContext.HASH_SHA256) != OK or context.update(terrain.to_byte_array()) != OK:
		return ""
	return context.finish().hex_encode()


func _connect_requests() -> void:
	_bus = SignalBus.get_instance()
	if not _bus.liquid_save_requested.is_connected(_on_save_requested):
		_bus.liquid_save_requested.connect(_on_save_requested)
	if not _bus.liquid_load_requested.is_connected(_on_load_requested):
		_bus.liquid_load_requested.connect(_on_load_requested)


func _on_save_requested() -> void:
	save_liquids()


func _on_load_requested() -> void:
	load_liquids()


func _complete(success: bool, message: String) -> bool:
	_connect_requests()
	_bus.liquid_save_completed.emit(success, message)
	return success
