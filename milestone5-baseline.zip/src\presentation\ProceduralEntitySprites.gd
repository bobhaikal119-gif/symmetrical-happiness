extends RefCounted
class_name ProceduralEntitySprites

## Bespoke 16x16 silhouettes: # ink, s shadow, m midtone, h highlight, a accent.
## Every pattern is individually authored; no generic-square fallback is used.
const INK := Color("0e1018")
const PATTERNS: Dictionary = {
	"iron_ingot": ["................", "................", ".....######.....", "....#hhhhh#.....", "...#hhhhhm#.....", "..#hhhhmmm###...", ".#mmmmmmmmmmm#..", ".#hmmmmmmmmmm#..", ".#hmmmmmmmmmss#.", ".#mmmmmmmmssss#.", "..#sssssssssss#.", "...##########...", "................", "................", "................", "................"],
	"copper_ingot": ["................", "................", "................", "...#########....", "..#hhhhhhhhh#...", ".#hhhhmmmmmmh#..", ".#mmmmmmammmm#..", ".#mmmmaaammmm#..", "..#mmmammmmmss#.", "..#mmmmmmsssss#.", "...#sssssssss#..", "....#########...", "................", "................", "................", "................"],
	"titanium_ingot": ["................", "......#####.....", ".....#hhhhh#....", "....#hhahhm#....", "...#hhhahmmm#...", "..#hhhhahmmmm#..", "..#mmmmammmmm#..", "..#mmmmammmmss#.", "..#mmmmammmsss#.", "...#mmmmsssss#..", "....#sssssss#...", ".....#######....", "................", "................", "................", "................"],
	"hull_wall": ["################", "#hhhhhhhhhhhhhs#", "#hmmmmmsmmmmmss#", "#hammmsmmmsamss#", "#hmmmmmsmmmmmss#", "#hmmmmmsmmmmmss#", "#hmmmmmsmmmmmss#", "#ssssssssssssss#", "#hmmmmmsmmmmmss#", "#hmmmmmsmmmmmss#", "#hmmmmmsmmmmmss#", "#hammmsmmmsamss#", "#hmmmmmsmmmmmss#", "#hmmmmmsmmmmmss#", "#ssssssssssssss#", "################"],
	"steel_plate": ["################", "#hhhhhhhhhhhhhh#", "#hmmmmmmmmmmmms#", "#hm#mmmmmmmm#ms#", "#hmmmmmmmmmmmms#", "#hmmmmmmmmmmmms#", "#hmmmmmmmmmmmms#", "#hhhhhhhhhhhhms#", "#ssssssssssssss#", "#hmmmmmmmmmmmms#", "#hmmmmmmmmmmmms#", "#hmmmmmmmmmmmms#", "#hm#mmmmmmmm#ms#", "#hmmmmmmmmmmmms#", "#ssssssssssssss#", "################"],
	"reinforced_glass": ["################", "#hhhhhhhhhhhhhh#", "#hammssssssssmh#", "#hmahssssssssmh#", "#hmshhsssssssmh#", "#hmsshsssssssmh#", "#hmssssssssssmh#", "#hmssssssssssmh#", "#hmssssssssssmh#", "#hmssssssssssmh#", "#hmssssssshssmh#", "#hmsssssshhssmh#", "#hmssssssshasmh#", "#hmmmmmmmmmmmmh#", "#ssssssssssssss#", "################"],
	"blast_door": [".##############.", ".#hhhhhhhhhhhh#.", ".#hmmsm##mmmss#.", ".#hmmsm##mmmss#.", ".#hmmsm##mmmss#.", ".#hmmmm##mmmss#.", ".#hmmmm##mmmss#.", ".#hmaa###aamss#.", ".#hmaa###aamss#.", ".#hmmmm##mmmss#.", ".#hmmmm##mmmss#.", ".#hmmsm##mmmss#.", ".#hmmsm##mmmss#.", ".#hmmsm##mmmss#.", ".#ssssssssssss#.", ".##############."],
	"blast_door_open": [".##############.", ".#hhhhhhhhhhhh#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#a#........#a#.", ".#a#........#a#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#h#........#s#.", ".#ssssssssssss#.", ".##############."],
	"ore_smelter": ["................", "...####..####...", "...#hh#..#ss#...", "..############..", "..#hhhhhhhhss#..", ".##hmmmmmmmss##.", ".#hmm######msss#", ".#hmm#aaaa#mmss#", ".#hmm#ahaa#mmss#", ".#hmm#hhah#mmss#", ".#hmm#ahhh#mmss#", ".#hmm######mmss#", ".#hmmmmmmmmmsss#", ".##############.", "..##........##..", "................"],
	"tech_fabricator": ["................", "..############..", "..#hhhhhhhhss#..", "..#hm######ss#..", "..#hm#ahha#ss#..", "..#hm#amma#ss#..", "..#hm######ss#..", "..#hmmmmmmmss#..", ".##############.", ".#hhhhhhhhhhhss#", ".#hmmm#am#mmmss#", ".#hmmm#am#mmmss#", ".#hmmm####mmmss#", ".##############.", "..##........##..", "................"],
	"colonist": [".....######.....", "....#hhhhhh#....", "....#hmmmmh#....", "....#masamh#....", ".....#hmm#......", "....##mmmm##....", "...#hhmmmmss#...", "..#mhmmammmss#..", "..#mhmmammmss#..", "..#shmmammmss#..", "...#hmmmmmmss#..", "....#mmmmmss#...", "....#m#ss#m#....", "....#m#..#s#....", "...#hh#..#ss#...", "...####..####..."],
	"fuel_cell": ["................", "......####......", ".....#hhhh#.....", "....########....", "....#hmmmss#....", "....#hmamss#....", "....#hmaass#....", "....#hhaass#....", "....#haaass#....", "....#hmaass#....", "....#hmamss#....", "....#hmmmss#....", "....#ssssss#....", ".....######.....", "................", "................"],
	"nano_medkit": ["................", ".....######.....", "....#hhhhhh#....", "...##########...", "..#hhhhhhhhhss#.", "..#hmmmammmmss#.", "..#hmmmammmmss#.", "..#hmaaaaammss#.", "..#hmmmammmmss#.", "..#hmmmammmmss#.", "..#hmmmmmmmmss#.", "..#sssssssssss#.", "...###########..", "................", "................", "................"],
	"drill_overclock_module": ["................", "...###....###...", "..#hhh####sss#..", ".#hhmmmmmmmsss#.", ".#hmmm###mmmss#.", "..#mm#aaa#mmss#.", "..#mm#aha#mmss#.", "..#mm#aaa#mmss#.", "..#mmm###mmmss#.", ".#hmmmmmmmmsss#.", ".#hmmmmmmmssss#.", "..############..", "....#h#..#s#....", "....#a#..#a#....", ".....#....#.....", "................"],
	"extended_o2_tank": ["................", "...####..####...", "...#hh#..#ss#...", "..######.#####..", "..#hmmm#.#mss#..", "..#hamh###mss#..", "..#hamhmmmmas#..", "..#hamh###mas#..", "..#hamh#.#mas#..", "..#hamh#.#mas#..", "..#hmmh#.#mss#..", "..#hmmh###mss#..", "..#ssss#.#sss#..", "...####...###...", "................", "................"],
	"precursor_schematic": ["................", "..###########...", "..#hhhhhhhhhh#..", "..#hmmmmmmmmm#..", "..#hm###m###m#..", "..#hm#ammam#m#..", "..#hm##aa###m#..", "..#hmmmaammmm#..", "..#hm##aa###m#..", "..#hm#ammam#m#..", "..#hm###m###m#..", "..#hmmmmmmmmm#..", "..#ssssssssss#..", "...###########..", "................", "................"]
}
const PALETTES: Dictionary = {
	"iron_ingot": ["596b7e", "9aafbb", "e0edf0", "d2dc9c"],
	"copper_ingot": ["81483b", "cb8558", "ffd4a2", "f3d18e"],
	"titanium_ingot": ["514d79", "9998c4", "e3e2ff", "78e0d6"],
	"hull_wall": ["293943", "4b6570", "8499a1", "b7c6a5"],
	"steel_plate": ["414b60", "8195a6", "c6d5dc", "e3c878"],
	"reinforced_glass": ["284653", "5698ab", "c5f0ec", "f0f4e2"],
	"blast_door": ["49505a", "919eaa", "cbd6d7", "f3bc68"],
	"blast_door_open": ["49505a", "919eaa", "cbd6d7", "76e2ae"],
	"ore_smelter": ["4e3334", "947167", "d7ae7c", "f68b48"],
	"tech_fabricator": ["273e54", "5e8994", "b6e1de", "56e3b4"],
	"colonist": ["314c51", "619b8b", "e8d5ad", "212c42"],
	"fuel_cell": ["3d6046", "76a75b", "d9f3b4", "c6ed6b"],
	"nano_medkit": ["8e716c", "d3b8a5", "fff0ce", "b94756"],
	"drill_overclock_module": ["645138", "b09251", "f3d990", "77dbe5"],
	"extended_o2_tank": ["365575", "699dbb", "c0e6f2", "e9d993"],
	"precursor_schematic": ["645a82", "9f8eb3", "eadcc6", "5ce0c9"]
}
static var _textures: Dictionary = {}

static func has_sprite(sprite_id: String) -> bool:
	return PATTERNS.has(sprite_id)

static func get_texture(sprite_id: String) -> ImageTexture:
	if _textures.has(sprite_id):
		return _textures[sprite_id] as ImageTexture
	if not PATTERNS.has(sprite_id):
		push_error("Missing bespoke procedural sprite: " + sprite_id)
		return null
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	var palette: Array = PALETTES[sprite_id]
	var colors: Dictionary = {"#": INK, "s": Color(palette[0]), "m": Color(palette[1]), "h": Color(palette[2]), "a": Color(palette[3])}
	var rows: Array = PATTERNS[sprite_id]
	for y: int in range(16):
		var row: String = String(rows[y])
		for x: int in range(16):
			var symbol: String = row.substr(x, 1)
			if colors.has(symbol):
				image.set_pixel(x, y, colors[symbol])
	var texture: ImageTexture = ImageTexture.create_from_image(image)
	_textures[sprite_id] = texture
	return texture
