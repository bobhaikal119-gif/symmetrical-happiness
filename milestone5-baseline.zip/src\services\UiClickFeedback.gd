extends Node
class_name UiClickFeedback

## Tiny synthesized tactile click; no external sound asset dependency.
var _voice: AudioStreamPlayer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_voice = AudioStreamPlayer.new()
	_voice.volume_db = -24.0
	var sound := AudioStreamWAV.new()
	sound.format = AudioStreamWAV.FORMAT_8_BITS
	sound.mix_rate = 22050
	var samples := PackedByteArray()
	for index: int in range(220):
		var envelope: float = 1.0 - float(index) / 220.0
		var wave: float = sin(float(index) * 0.5) * envelope * 42.0
		samples.append(int(wave) & 255)
	sound.data = samples
	_voice.stream = sound
	add_child(_voice)
	SignalBus.get_instance().ui_button_clicked.connect(_play)

func _play() -> void:
	_voice.play()
