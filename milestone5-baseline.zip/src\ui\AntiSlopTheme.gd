extends RefCounted
class_name AntiSlopTheme

## Shared sharp-pixel terminal skin. All frame textures are generated in memory.
const INK: Color = Color("0e1018")
const EDGE: Color = Color("14151f")
const SLATE: Color = Color("202936")
const CREAM: Color = Color("f4e8cd")
const TEAL: Color = Color("2e9e7b")
const DISABLED_TEXT: Color = Color("c5c0b3")
static var _theme: Theme

static func create_theme() -> Theme:
	if _theme != null:
		return _theme
	_theme = Theme.new()
	_theme.default_font_size = 16
	# Force tabular numerals for stable CR/price/count columns while retaining
	# the familiar readable body face; labels still align numeric columns right.
	var tabular := FontVariation.new()
	tabular.base_font = ThemeDB.fallback_font
	tabular.opentype_features = {"tnum": 1}
	_theme.default_font = tabular
	for type_name: String in ["Label", "Button", "CheckButton", "CheckBox", "OptionButton", "LineEdit", "TextEdit", "TabBar", "TabContainer", "SpinBox"]:
		_theme.set_font_size("font_size", type_name, 16)
		_theme.set_color("font_color", type_name, CREAM)
		_theme.set_color("font_disabled_color", type_name, DISABLED_TEXT)
		_theme.set_color("font_focus_color", type_name, CREAM)
		_theme.set_color("font_hover_color", type_name, CREAM)
		_theme.set_color("font_pressed_color", type_name, CREAM)
		_theme.set_color("font_hover_pressed_color", type_name, CREAM)
	_theme.set_stylebox("panel", "PanelContainer", _frame(SLATE))
	_theme.set_stylebox("panel", "Panel", _frame(SLATE))
	_theme.set_stylebox("panel", "AcceptDialog", _frame(SLATE))
	_theme.set_stylebox("panel", "PopupMenu", _frame(SLATE))
	_theme.set_stylebox("hover", "PopupMenu", _frame(Color("364657"), TEAL))
	_theme.set_color("font_color", "PopupMenu", CREAM)
	_theme.set_color("font_hover_color", "PopupMenu", CREAM)
	_theme.set_color("font_disabled_color", "PopupMenu", DISABLED_TEXT)
	_theme.set_font_size("font_size", "PopupMenu", 16)
	_theme.set_type_variation("HeaderPanel", "PanelContainer")
	_theme.set_stylebox("panel", "HeaderPanel", _frame(TEAL))
	_theme.set_type_variation("InsetPanel", "PanelContainer")
	_theme.set_stylebox("panel", "InsetPanel", _frame(Color("19212c")))
	_theme.set_type_variation("PaperPanel", "PanelContainer")
	_theme.set_stylebox("panel", "PaperPanel", _frame(CREAM))
	_theme.set_type_variation("PaperLabel", "Label")
	_theme.set_color("font_color", "PaperLabel", INK)
	_theme.set_type_variation("MicroLabel", "Label")
	_theme.set_font_size("font_size", "MicroLabel", 8)
	_theme.set_type_variation("HeaderLabel", "Label")
	_theme.set_color("font_color", "HeaderLabel", INK)
	_theme.set_font_size("font_size", "HeaderLabel", 24)
	for type_name: String in ["Button", "OptionButton", "CheckButton", "CheckBox"]:
		_button_styles(type_name, Color("2a3544"), Color("364657"), EDGE, Color("26313e"))
	_theme.set_type_variation("HeaderButton", "Button")
	_button_styles("HeaderButton", TEAL, Color("5dbb96"), Color("318d70"), Color("638a7c"))
	for state: String in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color", "font_disabled_color"]:
		_theme.set_color(state, "HeaderButton", INK)
	for type_name: String in ["SlotButton", "CategoryButton"]:
		_theme.set_type_variation(type_name, "Button")
		_button_styles(type_name, Color("19212c"), Color("364657"), EDGE, Color("26313e"))
	for type_name: String in ["TabBar", "TabContainer"]:
		_theme.set_stylebox("tab_unselected", type_name, _frame(SLATE))
		_theme.set_stylebox("tab_hovered", type_name, _frame(Color("364657")))
		_theme.set_stylebox("tab_selected", type_name, _frame(EDGE, TEAL))
		_theme.set_stylebox("tab_disabled", type_name, _frame(Color("26313e")))
		_theme.set_stylebox("tab_focus", type_name, _frame(Color.TRANSPARENT, CREAM, true))
		_theme.set_color("font_selected_color", type_name, CREAM)
		_theme.set_color("font_unselected_color", type_name, CREAM)
		_theme.set_color("font_hovered_color", type_name, CREAM)
		_theme.set_stylebox("panel", type_name, _frame(SLATE))
	for type_name: String in ["LineEdit", "TextEdit"]:
		_theme.set_stylebox("normal", type_name, _frame(EDGE))
		_theme.set_stylebox("focus", type_name, _frame(Color.TRANSPARENT, CREAM, true))
		_theme.set_stylebox("read_only", type_name, _frame(Color("26313e")))
		_theme.set_color("font_uneditable_color", type_name, DISABLED_TEXT)
		_theme.set_color("caret_color", type_name, CREAM)
	_theme.set_stylebox("background", "ProgressBar", _frame(EDGE))
	_theme.set_stylebox("fill", "ProgressBar", _frame(TEAL))
	_theme.set_stylebox("panel", "TooltipPanel", _frame(CREAM))
	_theme.set_color("font_color", "TooltipLabel", INK)
	_theme.set_font_size("font_size", "TooltipLabel", 16)
	for type_name: String in ["HSlider", "VSlider"]:
		_theme.set_stylebox("slider", type_name, _frame(EDGE))
		_theme.set_stylebox("grabber_area", type_name, _frame(TEAL))
		_theme.set_stylebox("grabber_area_highlight", type_name, _frame(Color("5dbb96")))
		_theme.set_icon("grabber", type_name, _pixel_glyph(false, CREAM))
		_theme.set_icon("grabber_highlight", type_name, _pixel_glyph(false, Color("8ceac3")))
		_theme.set_icon("grabber_disabled", type_name, _pixel_glyph(false, DISABLED_TEXT))
	for type_name: String in ["HScrollBar", "VScrollBar"]:
		_theme.set_stylebox("scroll", type_name, _frame(EDGE))
		_theme.set_stylebox("scroll_focus", type_name, _frame(Color.TRANSPARENT, CREAM, true))
		_theme.set_stylebox("grabber", type_name, _frame(Color("4d6470")))
		_theme.set_stylebox("grabber_highlight", type_name, _frame(TEAL))
		_theme.set_stylebox("grabber_pressed", type_name, _frame(Color("5dbb96")))
	for type_name: String in ["CheckButton", "CheckBox"]:
		_theme.set_icon("on", type_name, _pixel_glyph(true, CREAM))
		_theme.set_icon("off", type_name, _pixel_glyph(false, CREAM))
		_theme.set_icon("on_disabled", type_name, _pixel_glyph(true, DISABLED_TEXT))
		_theme.set_icon("off_disabled", type_name, _pixel_glyph(false, DISABLED_TEXT))
	for type_name: String in ["HBoxContainer", "VBoxContainer", "GridContainer", "HFlowContainer", "VFlowContainer"]:
		_theme.set_constant("separation", type_name, 8)
		_theme.set_constant("h_separation", type_name, 8)
		_theme.set_constant("v_separation", type_name, 8)
	return _theme

static func apply_to(root: Control) -> void:
	root.theme = create_theme()
	root.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_wire_tree(root)

static func wire_button(button: BaseButton) -> void:
	if button.has_meta(&"deepwell_click_wired"):
		return
	button.set_meta(&"deepwell_click_wired", true)
	button.focus_mode = Control.FOCUS_ALL
	button.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	button.pressed.connect(_emit_click)

static func _wire_tree(node: Node) -> void:
	if node is BaseButton:
		wire_button(node as BaseButton)
	if node is TabBar and not node.has_meta(&"deepwell_tab_wired"):
		node.set_meta(&"deepwell_tab_wired", true)
		(node as TabBar).tab_clicked.connect(_tab_clicked)
	if node is TabContainer:
		_wire_tree((node as TabContainer).get_tab_bar())
	for child: Node in node.get_children():
		_wire_tree(child)

static func _emit_click() -> void:
	SignalBus.get_instance().ui_button_clicked.emit()

static func _tab_clicked(_tab: int) -> void:
	_emit_click()

static func _button_styles(type_name: String, normal: Color, hover: Color, pressed: Color, disabled: Color) -> void:
	_theme.set_stylebox("normal", type_name, _frame(normal))
	_theme.set_stylebox("hover", type_name, _frame(hover, TEAL))
	_theme.set_stylebox("pressed", type_name, _frame(pressed, TEAL))
	_theme.set_stylebox("hover_pressed", type_name, _frame(pressed, TEAL))
	_theme.set_stylebox("disabled", type_name, _frame(disabled))
	_theme.set_stylebox("focus", type_name, _frame(Color.TRANSPARENT, CREAM, true))

static func _pixel_glyph(checked: bool, fill: Color) -> ImageTexture:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(INK)
	for y: int in range(1, 15):
		for x: int in range(1, 15):
			image.set_pixel(x, y, fill if x == 1 or y == 1 else SLATE)
	if checked:
		for step: int in range(7):
			var x: int = 4 + step
			var y: int = 9 - absi(step - 2)
			image.set_pixel(x, y, fill)
			image.set_pixel(x, y + 1, fill)
	return ImageTexture.create_from_image(image)

static func _frame(fill: Color, trim: Color = Color("4d6470"), focus: bool = false) -> StyleBoxTexture:
	var image: Image = Image.create(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(fill)
	for y: int in range(16):
		for x: int in range(16):
			var rim: int = mini(mini(x, 15 - x), mini(y, 15 - y))
			if rim == 0:
				image.set_pixel(x, y, trim if focus else INK)
			elif rim == 1:
				image.set_pixel(x, y, trim if focus else EDGE)
			elif rim == 2 and not focus:
				image.set_pixel(x, y, trim if x == 2 or y == 2 else fill.darkened(0.25))
	var style := StyleBoxTexture.new()
	style.texture = ImageTexture.create_from_image(image)
	for side: int in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]:
		style.set_texture_margin(side, 4.0)
		style.set_content_margin(side, 8.0)
		if focus:
			style.set_expand_margin(side, 2.0)
	style.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	style.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	return style
