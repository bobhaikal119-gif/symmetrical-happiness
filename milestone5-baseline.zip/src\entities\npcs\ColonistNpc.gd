extends InteractableEntity
class_name ColonistNpc

## A housed merchant walks only along the validated room's safe floor cells.
@export var npc_name: String = "Quartermaster"
@export var walk_speed: float = 22.0
@onready var sprite: Sprite2D = $Sprite2D
@onready var speech: Label = $Speech
var world_grid: WorldGrid
var room_id: String = ""
var is_housed: bool = false
var _room_cells: Dictionary = {}
var _floor_cells: Dictionary = {}
var _spawn_position: Vector2 = Vector2.ZERO
var _direction: float = 1.0
var _behavior_elapsed: float = 0.0
var _door_elapsed: float = 0.0
var _speech_elapsed: float = 0.0
var _opened_doors: Array[BlastDoor] = []

func _ready() -> void:
	super._ready()
	add_to_group("colonist_npcs")
	add_to_group("colonists")
	sprite.texture = ProceduralEntitySprites.get_texture("colonist")
	speech.add_theme_color_override("font_color", Color("0e1018"))
	# A literal cream pixel bubble with a one-pixel ink border, not an outline
	# around floating text. The unshaded material preserves readable contrast.
	var bubble := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	bubble.fill(Color("f4e8cd"))
	for index: int in range(16):
		bubble.set_pixel(index, 0, Color("0e1018"))
		bubble.set_pixel(index, 15, Color("0e1018"))
		bubble.set_pixel(0, index, Color("0e1018"))
		bubble.set_pixel(15, index, Color("0e1018"))
	var frame := StyleBoxTexture.new()
	frame.texture = ImageTexture.create_from_image(bubble)
	for side: int in [SIDE_LEFT, SIDE_TOP, SIDE_RIGHT, SIDE_BOTTOM]:
		frame.set_texture_margin(side, 1.0)
		frame.set_content_margin(side, 4.0)
	speech.add_theme_stylebox_override("normal", frame)
	var speech_material := CanvasItemMaterial.new()
	speech_material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	speech.material = speech_material
	speech.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	speech.add_theme_font_size_override("font_size", 8)
	speech.text = "Warm walls. Fair trades."
	speech.visible = is_housed
	_speech_elapsed = 4.0

func setup(room: Dictionary, world: WorldGrid) -> void:
	world_grid = world
	room_id = str(room.get("room_id", ""))
	_room_cells.clear()
	_floor_cells.clear()
	var cells: Array = room.get("cells", [])
	for value: Variant in cells:
		if value is Vector2i:
			_room_cells[value] = true
	var floors: Array = room.get("floor_cells", [])
	for value: Variant in floors:
		if value is Vector2i:
			_floor_cells[value] = true
	# The optional floor snapshot makes checker output directly usable; derive it
	# for callers that supply only the locked base result keys.
	if _floor_cells.is_empty() and world_grid != null:
		for cell: Vector2i in _room_cells:
			if world_grid.is_solid(cell.x, cell.y + 1) and not world_grid.is_hazard(cell.x, cell.y + 1):
				_floor_cells[cell] = true
	is_housed = bool(room.get("valid", false)) and world_grid != null and not room_id.is_empty() and not _floor_cells.is_empty()
	if not is_housed:
		velocity = Vector2.ZERO
		return
	var fallback: Vector2i = _floor_cells.keys()[0]
	var spawn_value: Variant = room.get("spawn_cell", fallback)
	var spawn_cell: Vector2i = spawn_value if spawn_value is Vector2i and _floor_cells.has(spawn_value) else fallback
	_spawn_position = (Vector2(spawn_cell) + Vector2.ONE * 0.5) * WorldGrid.TILE_SIZE
	global_position = _spawn_position
	grid_pos = spawn_cell
	velocity = Vector2.ZERO
	if is_node_ready():
		speech.visible = true
		_speech_elapsed = 4.0

func _physics_process(delta: float) -> void:
	if not is_housed or world_grid == null:
		velocity = Vector2.ZERO
		return
	_speech_elapsed = maxf(0.0, _speech_elapsed - delta)
	speech.visible = _speech_elapsed > 0.0
	_behavior_elapsed += delta
	_door_elapsed += delta
	if _door_elapsed >= 0.2:
		_door_elapsed = 0.0
		_update_doors()
	if _behavior_elapsed >= 4.0:
		_behavior_elapsed = 0.0
		_direction = -_direction
	var old_position: Vector2 = global_position
	var ahead: Vector2 = global_position + Vector2(_direction * (6.0 + walk_speed * delta), 0.0)
	var ahead_cell := Vector2i(floori(ahead.x / WorldGrid.TILE_SIZE), floori(ahead.y / WorldGrid.TILE_SIZE))
	if not _is_safe_floor(ahead_cell):
		_direction = -_direction
		velocity.x = 0.0
	else:
		velocity.x = walk_speed * _direction
	velocity.y = minf(velocity.y + 980.0 * delta, 120.0)
	move_and_slide()
	var cell := Vector2i(floori(global_position.x / WorldGrid.TILE_SIZE), floori(global_position.y / WorldGrid.TILE_SIZE))
	if not _room_cells.has(cell) or world_grid.is_hazard(cell.x, cell.y):
		global_position = old_position if _room_cells.has(grid_pos) else _spawn_position
		velocity = Vector2.ZERO
		_direction = -_direction
	else:
		grid_pos = cell
	sprite.flip_h = _direction < 0.0

func can_interact(actor: Node) -> bool:
	return is_housed and world_grid != null and not is_queued_for_deletion() and super.can_interact(actor)

func interact(actor: Node) -> void:
	if not can_interact(actor):
		return
	velocity.x = 0.0
	speech.text = "Salvage for credits. Supplies for survival."
	speech.visible = true
	_speech_elapsed = 5.0
	SignalBus.get_instance().shop_toggled.emit(true, npc_name)

func get_prompt_text() -> String:
	return "Trade with " + npc_name

func dehouse() -> void:
	is_housed = false
	velocity = Vector2.ZERO
	if is_node_ready():
		speech.visible = false
	SignalBus.get_instance().shop_toggled.emit(false, "")

func _is_safe_floor(cell: Vector2i) -> bool:
	return _floor_cells.has(cell) and not world_grid.is_solid(cell.x, cell.y) and not world_grid.is_hazard(cell.x, cell.y) and world_grid.is_solid(cell.x, cell.y + 1)

func _update_doors() -> void:
	for candidate: Node in get_tree().get_nodes_in_group("blast_doors"):
		var door: BlastDoor = candidate as BlastDoor
		if door == null or door.is_queued_for_deletion() or not _is_room_door(door):
			continue
		var distance: float = global_position.distance_to(door.global_position)
		if distance <= 28.0:
			if not door.is_open:
				door.set_open(true)
				if not _opened_doors.has(door):
					_opened_doors.append(door)
	for index: int in range(_opened_doors.size() - 1, -1, -1):
		var door: BlastDoor = _opened_doors[index]
		if not is_instance_valid(door):
			_opened_doors.remove_at(index)
		elif global_position.distance_to(door.global_position) > 40.0 and not _actor_near_door(door):
			door.set_open(false)
			_opened_doors.remove_at(index)

func _is_room_door(door: BlastDoor) -> bool:
	for offset: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		if _room_cells.has(door.grid_pos + offset):
			return true
	return false

func _actor_near_door(door: BlastDoor) -> bool:
	for group: String in ["player", "colonist_npcs"]:
		for candidate: Node in get_tree().get_nodes_in_group(group):
			var actor: Node2D = candidate as Node2D
			if actor != null and actor.global_position.distance_to(door.global_position) <= 28.0:
				return true
	return false
