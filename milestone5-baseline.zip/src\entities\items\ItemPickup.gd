extends Area2D

class_name ItemPickup

"""
ItemPickup: World drop entity representing a collectible item extracted by
AutoDrills, mined tiles, or defeated enemies. Uses ProceduralItemIcons for its
16x16 texture and adds to the player's CraftingComponent on pickup.
"""

@export var item_id: String = "stone"
@export var count: int = 1
@export var pickup_magnet_radius: float = 36.0
@export var move_speed: float = 120.0

@onready var sprite: Sprite2D = $Sprite2D

var _bob_time: float = 0.0
var _collected: bool = false

func _ready() -> void:
	add_to_group("item_pickups")
	body_entered.connect(_on_body_entered)
	_apply_icon()

func setup(p_item_id: String, p_count: int = 1) -> void:
	item_id = p_item_id
	count = maxi(1, p_count)
	if is_inside_tree():
		_apply_icon()

func _apply_icon() -> void:
	if sprite != null:
		sprite.texture = ProceduralItemIcons.get_instance().get_item_icon_texture(item_id)

func _process(delta: float) -> void:
	if _collected:
		return
	_bob_time += delta * 4.0
	if sprite != null:
		sprite.position.y = sin(_bob_time) * 2.0

	var players := get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		var player := players[0] as Node2D
		if player != null:
			var dist := global_position.distance_to(player.global_position)
			if dist <= pickup_magnet_radius:
				var dir := (player.global_position - global_position).normalized()
				global_position += dir * move_speed * delta
			if dist <= 16.0:
				_try_collect(player)

func _on_body_entered(body: Node2D) -> void:
	if _collected:
		return
	if body.is_in_group("player") or body is Player:
		_try_collect(body)

func _try_collect(player_node: Node) -> void:
	if _collected:
		return
	var crafting := player_node.get_node_or_null("CraftingComponent") as CraftingComponent
	if crafting != null:
		crafting.add_item(item_id, count)
	_collected = true
	SignalBus.get_instance().item_collected.emit(item_id, count)
	queue_free()
