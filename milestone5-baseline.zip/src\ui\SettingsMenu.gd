extends CanvasLayer

## Presentation only: Main owns pause reasons and session lifecycle.
const INK := Color(0.82, 0.9, 0.93)
const MUTED := Color(0.53, 0.69, 0.75)
const AMBER := Color(0.97, 0.74, 0.34)
const CYAN := Color(0.36, 0.87, 0.87)
const ACTION_LABELS: Dictionary = {
	"move_left": "Move left", "move_right": "Move right", "move_up": "Climb / move up", "move_down": "Climb / move down",
	"jump": "Jump", "mine_primary": "Mine / primary tool", "place_heater": "Place / use selected item",
	"toggle_crafting": "Open crafting", "toggle_smart_cursor": "Toggle Smart Cursor",
	"interact": "Interact", "flashlight_toggle": "Toggle flashlight",
}

@onready var _layout: Control = %Layout
@onready var _window_panel: PanelContainer = %Window
@onready var _tabs: TabContainer = %SettingsTabs
@onready var _footer: Label = %FooterStatus
@onready var _rebind_dialog: ConfirmationDialog = %RebindConfirmation
@onready var _session_dialog: ConfirmationDialog = %SessionConfirmation
@onready var _defaults_dialog: ConfirmationDialog = %DefaultsConfirmation

var is_open: bool = false
var _bus: SignalBus
var _controls: Dictionary = {}
var _number_labels: Dictionary = {}
var _key_buttons: Dictionary = {}
var _key_notes: Dictionary = {}
var _seed_label: Label
var _binding_status: Label
var _listening_action: StringName = &""
var _pending_action: StringName = &""
var _pending_event: InputEventKey


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 60
	_bus = SignalBus.get_instance()
	_build_tabs()
	AntiSlopTheme.apply_to(_layout)
	for dialog: ConfirmationDialog in [_rebind_dialog, _session_dialog, _defaults_dialog]:
		dialog.theme = AntiSlopTheme.create_theme()
		AntiSlopTheme._wire_tree(dialog)
		AntiSlopTheme.wire_button(dialog.get_ok_button())
		AntiSlopTheme.wire_button(dialog.get_cancel_button())
	(%CloseButton as Button).pressed.connect(func() -> void: set_open(false))
	(%DefaultsButton as Button).pressed.connect(func() -> void: _defaults_dialog.popup_centered())
	_rebind_dialog.confirmed.connect(_accept_rebind)
	_rebind_dialog.canceled.connect(_cancel_rebind)
	_session_dialog.confirmed.connect(_reset_session)
	_defaults_dialog.confirmed.connect(_restore_defaults)
	_bus.setting_changed.connect(_on_setting_changed)
	_bus.keybinds_updated.connect(_refresh_keybinds)
	_bus.liquid_save_completed.connect(_on_liquid_save_completed)
	get_viewport().size_changed.connect(_resize_window)
	_resize_window()
	_sync_controls()
	_layout.hide()


func set_open(open: bool) -> void:
	if is_open == open:
		return
	_cancel_rebind()
	_session_dialog.hide()
	_defaults_dialog.hide()
	is_open = open
	_layout.visible = open
	if open:
		_bus.crafting_menu_toggled.emit(false)
		_bus.shop_toggled.emit(false, "")
		_sync_controls()
		_footer.text = "Changes apply instantly and are saved automatically. Escape resumes."
		(%CloseButton as Button).grab_focus()
	_bus.settings_menu_toggled.emit(is_open)


func _input(event: InputEvent) -> void:
	# Capture remapping BEFORE focused GUI widgets can consume the key.
	if event is not InputEventKey:
		return
	var key: InputEventKey = event as InputEventKey
	if not key.pressed or key.echo:
		return
	var escape: bool = key.keycode == KEY_ESCAPE or key.physical_keycode == KEY_ESCAPE
	if not _listening_action.is_empty() or not _pending_action.is_empty():
		if escape:
			_cancel_rebind()
		elif not _listening_action.is_empty():
			_propose_rebind(key)
		else:
			# Explicit Enter confirms; other keys never leak through to gameplay.
			if key.keycode == KEY_ENTER or key.keycode == KEY_KP_ENTER:
				_rebind_dialog.hide()
				_accept_rebind()
		get_viewport().set_input_as_handled()
		return
	if escape:
		if SettingsManager.shop_menu_open:
			_bus.shop_toggled.emit(false, "")
		elif SettingsManager.crafting_menu_open and not is_open:
			_bus.crafting_menu_toggled.emit(false)
		else:
			set_open(not is_open)
		get_viewport().set_input_as_handled()


func _resize_window() -> void:
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	var margin: float = 18.0 if viewport_size.x > 700.0 else 8.0
	var panel_size := Vector2(minf(1040.0, viewport_size.x - margin * 2.0), minf(760.0, viewport_size.y - margin * 2.0))
	_window_panel.position = (viewport_size - panel_size) * 0.5
	_window_panel.size = panel_size
	var title: Label = $Layout/Window/Content/Header/TitleBlock/Title
	title.text = "DEEPWELL / FIELD CONFIGURATION" if viewport_size.x > 740.0 else "DEEPWELL / SETTINGS"
	title.add_theme_font_size_override("font_size", 24 if viewport_size.x > 1000.0 else 16)


func _build_tabs() -> void:
	var general: VBoxContainer = _page("General")
	_section(general, "EXPEDITION / ACCESSIBILITY", "Tune feedback without changing the world's rules.")
	_add_number(general, "general", "screen_shake", "Screen shake", "Camera impact strength. Zero removes shake entirely.", 0.0, 1.5, 0.05)
	_add_toggle(general, "general", "floating_popups", "Floating feedback", "Show temporary pickup and integrity-change labels. Respects the effect budget.")
	_add_toggle(general, "general", "auto_pause", "Auto-Pause in Menus", "Pause the expedition while crafting is open. Settings always pause; Main manages independent menu pause reasons.")
	_add_number(general, "general", "hud_scale", "HUD scale", "Scale suit telemetry and notifications; viewport edges remain anchored.", 0.75, 1.5, 0.05)

	var profile: VBoxContainer = _page("Profile")
	_section(profile, "PIONEER IDENTIFICATION", "Your field identity and suit appearance, applied immediately.")
	var name_row: HBoxContainer = _row(profile, "Pioneer name", "1–32 characters. Blank names revert to Pioneer.")
	var name_edit := LineEdit.new()
	name_edit.custom_minimum_size.x = 248.0
	name_edit.max_length = 32
	name_edit.placeholder_text = "Pioneer"
	name_row.add_child(name_edit)
	_controls["profile/pioneer_name"] = name_edit
	name_edit.text_submitted.connect(func(_text: String) -> void: _save_name(name_edit))
	name_edit.focus_exited.connect(func() -> void: _save_name(name_edit))
	var color_row: HBoxContainer = _row(profile, "Suit color", "Opaque suit tint. World lighting can affect its appearance.")
	var picker := ColorPickerButton.new()
	picker.custom_minimum_size = Vector2(248.0, 40.0)
	picker.edit_alpha = false
	color_row.add_child(picker)
	_controls["profile/suit_color"] = picker
	picker.color_changed.connect(func(value: Color) -> void: SettingsManager.set_setting("profile", "suit_color", value))
	_section(profile, "WORLD TELEMETRY / READ ONLY", "The current expedition is generated from this seed. Reset Session restarts it.")
	_seed_label = _label("", 24, AMBER)
	profile.add_child(_seed_label)
	_section(profile, "SESSION CONTROL", "Resetting the expedition does not erase your preferences or keyboard bindings.")
	var reset: Button = _button("Reset Session…")
	reset.pressed.connect(func() -> void: _session_dialog.popup_centered())
	profile.add_child(reset)
	_section(profile, "LIQUID SNAPSHOT", "Save or restore water/lava for this exact world seed and terrain. This is not a full expedition save; terrain changes invalidate old fluid snapshots.")
	var save_liquid: Button = _button("Save Water / Lava Snapshot")
	save_liquid.pressed.connect(func() -> void: _bus.liquid_save_requested.emit())
	profile.add_child(save_liquid)
	var load_liquid: Button = _button("Restore Water / Lava Snapshot")
	load_liquid.pressed.connect(func() -> void: _bus.liquid_load_requested.emit())
	profile.add_child(load_liquid)

	var graphics: VBoxContainer = _page("Graphics")
	_section(graphics, "DISPLAY / ATMOSPHERE", "Display changes apply live; no restart required.")
	_add_options(graphics, "graphics", "window_mode", "Window mode", "Borderless fullscreen or a normal desktop window.", ["Windowed", "Borderless Fullscreen"], [0, 1])
	_add_toggle(graphics, "graphics", "vsync", "Vertical sync", "Synchronize presentation with the display to reduce tearing.")
	_add_number(graphics, "graphics", "ambient_darkness", "Ambient darkness", "Add darkness to the underground atmosphere. Does not change collision or simulation.", 0.0, 1.0, 0.05)
	_add_toggle(graphics, "graphics", "pixel_snap", "Pixel snapping", "Align 2D transforms and vertices with screen pixels for a crisp industrial image.")

	var optimization: VBoxContainer = _page("Optimization")
	_section(optimization, "RENDER BUDGET", "Lower presentation costs without removing collision, simulation, or item rewards.")
	_add_number(optimization, "optimization", "render_distance", "Render distance", "Active radius in tiles around the camera. Distant render chunks unload; world data and collision remain intact.", 24.0, 128.0, 8.0)
	_add_options(optimization, "optimization", "lighting_quality", "Lighting quality", "Full uses detailed lighting; Fast favors a cheaper presentation.", ["Full PointLight2D", "Fast Performance"], [0, 1])
	_add_number(optimization, "optimization", "max_particles", "Max rubble / particles", "Caps particles, pickup entities and floating notices. Excess drops merge or safely credit inventory; rewards are never deleted.", 0.0, 512.0, 16.0)
	_add_options(optimization, "optimization", "fps_limit", "FPS limit", "A frame cap saves power. VSync can impose an additional display limit.", ["30 FPS", "60 FPS", "120 FPS", "Unlimited"], [30, 60, 120, 0])
	_add_toggle(optimization, "optimization", "performance_overlay", "Performance overlay", "FPS + active processing nodes / total SceneTree nodes. Active = processable with a frame or physics callback; total includes UI and hidden chunks, not tiles.")

	var mouse: VBoxContainer = _page("Controls")
	_section(mouse, "TOOL TARGETING", "Aim directly with the mouse, or use Smart Cursor to select along your aim direction.")
	_add_toggle(mouse, "mouse", "smart_cursor", "Smart Cursor", "Directional target assistance. Toggle here, on the HUD badge, or with its keyboard binding.")
	_add_number(mouse, "mouse", "aim_smoothing", "Aim smoothing", "Zero follows aim immediately; higher values gently ease the shared mining/build target.", 0.0, 1.0, 0.05)
	_add_toggle(mouse, "mouse", "swap_buttons", "Swap mouse buttons", "Default: left mines, right places. Swapped: right mines, left places. Keyboard bindings remain intact.")
	_section(mouse, "REACH / TARGET COLORS", "Yellow = valid Smart lock; cyan = valid direct aim; red = invalid or out of reach. Mining locks exposed terrain in your aim direction. Building chooses empty cells beside terrain, avoiding pioneers and structures. A buildable hotbar item previews building; holding Mine previews mining. Smart Cursor never extends tool reach or bypasses tile rules.")
	_section(mouse, "KEYBOARD / LIVE INPUT MAP", "Select an action, then press a key. Escape cancels. Conflicts require confirmation; mouse bindings are preserved.")
	_binding_status = _label("All gameplay actions can be remapped below.", 16, CYAN)
	_binding_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mouse.add_child(_binding_status)
	for action: String in SettingsManager.DEFAULT_KEYS:
		var title: String = String(ACTION_LABELS.get(action, "Select hotbar slot %s" % action.trim_prefix("hotbar_")))
		var row: HBoxContainer = _row(mouse, title, "")
		var button: Button = _button("")
		button.custom_minimum_size.x = 240.0
		row.add_child(button)
		_key_buttons[action] = button
		button.pressed.connect(_begin_rebind.bind(StringName(action)))
		var warning: Label = _label("", 16, AMBER)
		warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		mouse.add_child(warning)
		_key_notes[action] = warning
	var reset_keys: Button = _button("Reset Keyboard Bindings")
	reset_keys.pressed.connect(_reset_keybinds)
	mouse.add_child(reset_keys)


func _page(title: String) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	scroll.name = title
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tabs.add_child(scroll)
	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 16)
	scroll.add_child(content)
	return content


func _section(parent: VBoxContainer, title: String, description: String) -> void:
	var line := HSeparator.new()
	parent.add_child(line)
	parent.add_child(_label(title, 16, AMBER))
	var detail: Label = _label(description, 16, MUTED)
	detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(detail)


func _row(parent: VBoxContainer, title: String, description: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	parent.add_child(row)
	var words := VBoxContainer.new()
	words.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(words)
	var heading: Label = _label(title, 16, INK)
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	words.add_child(heading)
	if not description.is_empty():
		var detail: Label = _label(description, 16, MUTED)
		detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		words.add_child(detail)
	return row


func _add_toggle(parent: VBoxContainer, section: String, key: String, title: String, description: String) -> void:
	var row: HBoxContainer = _row(parent, title, description)
	var toggle := CheckButton.new()
	if section == "optimization" and key == "performance_overlay":
		toggle.name = "PerformanceOverlay"
	toggle.custom_minimum_size = Vector2(248.0, 40.0)
	toggle.text = "Enabled"
	row.add_child(toggle)
	if toggle.name == "PerformanceOverlay":
		toggle.owner = self
		toggle.unique_name_in_owner = true
	_controls[section + "/" + key] = toggle
	toggle.toggled.connect(func(value: bool) -> void: SettingsManager.set_setting(section, key, value))


func _add_number(parent: VBoxContainer, section: String, key: String, title: String, description: String, minimum: float, maximum: float, step: float) -> void:
	var row: HBoxContainer = _row(parent, title, description)
	var value_box := VBoxContainer.new()
	value_box.custom_minimum_size.x = 248.0
	row.add_child(value_box)
	var value_label: Label = _label("", 16, CYAN)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	value_box.add_child(value_label)
	var slider := HSlider.new()
	slider.min_value = minimum
	slider.max_value = maximum
	slider.step = step
	slider.custom_minimum_size = Vector2(248.0, 24.0)
	value_box.add_child(slider)
	_controls[section + "/" + key] = slider
	_number_labels[section + "/" + key] = value_label
	slider.value_changed.connect(func(value: float) -> void:
		SettingsManager.set_setting(section, key, int(value) if section == "optimization" else value)
	)


func _add_options(parent: VBoxContainer, section: String, key: String, title: String, description: String, labels: Array, values: Array) -> void:
	var row: HBoxContainer = _row(parent, title, description)
	var choices := OptionButton.new()
	choices.custom_minimum_size = Vector2(248.0, 40.0)
	for index: int in labels.size():
		choices.add_item(String(labels[index]))
		choices.set_item_metadata(index, values[index])
	row.add_child(choices)
	_controls[section + "/" + key] = choices
	choices.item_selected.connect(func(index: int) -> void: SettingsManager.set_setting(section, key, choices.get_item_metadata(index)))


func _on_liquid_save_completed(success: bool, message: String) -> void:
	_footer.text = ("SNAPSHOT / " if success else "SNAPSHOT REJECTED / ") + message


func _save_name(field: LineEdit) -> void:
	SettingsManager.set_setting("profile", "pioneer_name", field.text)
	field.text = str(SettingsManager.get_setting("profile", "pioneer_name", "Pioneer"))


func _sync_controls() -> void:
	for path: String in _controls:
		var parts: PackedStringArray = path.split("/")
		_update_control(path, SettingsManager.get_setting(parts[0], parts[1], SettingsManager.DEFAULTS[parts[0]][parts[1]]))
	_seed_label.text = "ACTIVE WORLD SEED  /  %d" % SettingsManager.active_world_seed
	_refresh_keybinds()


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	_update_control(section + "/" + key, value)


func _update_control(path: String, value: Variant) -> void:
	if not _controls.has(path):
		return
	var control: Control = _controls[path]
	if control is CheckButton:
		(control as CheckButton).set_pressed_no_signal(bool(value))
		(control as CheckButton).text = "On" if bool(value) else "Off"
	elif control is HSlider:
		(control as HSlider).set_value_no_signal(float(value))
		var label: Label = _number_labels[path]
		if path == "general/hud_scale":
			label.text = "%d%%" % roundi(float(value) * 100.0)
		elif path == "optimization/render_distance":
			label.text = "%d tiles" % int(value)
		elif path == "optimization/max_particles":
			label.text = "%d effects" % int(value)
		else:
			label.text = "%d%%" % roundi(float(value) * 100.0)
	elif control is OptionButton:
		var options: OptionButton = control as OptionButton
		for index: int in options.item_count:
			if options.get_item_metadata(index) == value:
				options.select(index)
				break
	elif control is LineEdit:
		(control as LineEdit).text = str(value)
	elif control is ColorPickerButton:
		var color: Color = value
		(control as ColorPickerButton).color = color


func _begin_rebind(action: StringName) -> void:
	_cancel_rebind()
	_listening_action = action
	_binding_status.text = "LISTENING: %s — press a key, or Escape to cancel." % _action_title(action)
	_footer.text = "Keyboard capture active. Mouse bindings will not be replaced."
	_refresh_keybinds()


func _propose_rebind(event: InputEventKey) -> void:
	_pending_action = _listening_action
	_listening_action = &""
	_pending_event = event.duplicate() as InputEventKey
	var conflicts: PackedStringArray = SettingsManager.get_key_conflicts(_pending_action, _pending_event)
	if conflicts.is_empty():
		_accept_rebind()
		return
	var titles: PackedStringArray = []
	for action: String in conflicts:
		titles.append(_action_title(StringName(action)))
	_rebind_dialog.dialog_text = "Bind %s to %s?\n\nThis key is already used by: %s.\nBoth actions will remain bound. Choose another key to avoid overlap." % [_event_label(_pending_event), _action_title(_pending_action), ", ".join(titles)]
	_binding_status.text = "CONFLICT (not applied): %s also controls %s." % [_event_label(_pending_event), ", ".join(titles)]
	_rebind_dialog.popup_centered()
	_refresh_keybinds()


func _accept_rebind() -> void:
	if _pending_action.is_empty() or _pending_event == null:
		return
	var action: StringName = _pending_action
	var conflicts: PackedStringArray = SettingsManager.get_key_conflicts(action, _pending_event)
	SettingsManager.rebind_key(action, _pending_event)
	_pending_action = &""
	_pending_event = null
	_binding_status.text = "%s → %s. %s" % [_action_title(action), SettingsManager.get_key_label(action), "Conflict kept with: " + ", ".join(conflicts) if not conflicts.is_empty() else "No conflicts."]
	_footer.text = "Keyboard binding saved. Existing mouse bindings preserved."
	_refresh_keybinds()


func _cancel_rebind() -> void:
	var was_pending: bool = not _listening_action.is_empty() or not _pending_action.is_empty()
	_listening_action = &""
	_pending_action = &""
	_pending_event = null
	_rebind_dialog.hide()
	if was_pending and is_instance_valid(_binding_status):
		_binding_status.text = "Rebinding canceled. No keyboard binding changed."
		_footer.text = "Changes apply instantly and are saved automatically."
	_refresh_keybinds()


func _refresh_keybinds() -> void:
	for action: String in _key_buttons:
		var button: Button = _key_buttons[action]
		button.text = "Press a key… [Esc cancels]" if StringName(action) == _listening_action else SettingsManager.get_key_label(StringName(action))
		var conflicts: PackedStringArray = []
		for event: InputEvent in InputMap.action_get_events(StringName(action)):
			if event is InputEventKey:
				for other: String in SettingsManager.get_key_conflicts(StringName(action), event as InputEventKey):
					if not conflicts.has(other):
						conflicts.append(other)
		var note: Label = _key_notes[action]
		note.text = "Shared key with: %s" % ", ".join(conflicts)
		note.visible = not conflicts.is_empty()
		button.tooltip_text = "Replace keyboard keys only; mouse input remains bound." if conflicts.is_empty() else note.text


func _reset_keybinds() -> void:
	_cancel_rebind()
	SettingsManager.reset_keybinds()
	_binding_status.text = "Default keyboard bindings restored. Mouse-button preference preserved."


func _restore_defaults() -> void:
	_cancel_rebind()
	SettingsManager.reset_to_defaults()
	_sync_controls()
	_footer.text = "Factory settings restored and saved. Expedition unchanged."


func _reset_session() -> void:
	set_open(false)
	_bus.reset_session_requested.emit()


func _action_title(action: StringName) -> String:
	return String(ACTION_LABELS.get(String(action), String(action).replace("_", " ").capitalize()))


func _event_label(event: InputEventKey) -> String:
	var code: int = event.get_physical_keycode_with_modifiers() if event.physical_keycode != KEY_NONE else event.get_keycode_with_modifiers()
	return OS.get_keycode_string(code)


func _label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


func _button(text: String) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 38.0
	return button


