extends StaticBody2D

class_name AutoTurret

const POWER_DRAW: float = 30.0
const POWER_DEMAND_WATTS: float = POWER_DRAW

var world_grid: WorldGrid
@export var signal_bus: SignalBus
@export var grid_pos: Vector2i = Vector2i.ZERO
@export var attack_range: float = 144.0
@export var attack_damage: float = 18.0
@export var fire_interval: float = 0.65
@export_flags_2d_physics var line_of_sight_mask: int = 0x7FFFFFFF
@export var max_health: float = 90.0

var power_consumption: float = POWER_DRAW
var power_draw: float = POWER_DRAW
var power_grid: PowerGridSystem
var health: float = 90.0
var active: bool = true

var _charge: float = 0.0
var _bolt_time_remaining: float = 0.0
var _registered_with_power_grid: bool = false
var _sprite: Sprite2D
var _plasma_bolt: Line2D


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	if _registered_with_power_grid and power_grid != null:
		power_grid.unregister_node(grid_pos)
		_registered_with_power_grid = false
	world_grid = p_world_grid
	power_grid = p_power_grid
	grid_pos = p_grid_pos
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	if is_inside_tree():
		_register_power_node()


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	setup(p_world_grid, p_power_grid, p_grid_pos, p_signal_bus)


func _ready() -> void:
	add_to_group("machines")
	add_to_group("base_targets")
	add_to_group("powered_consumers")
	health = max_health
	_ensure_scene_nodes()
	_create_procedural_sprite()
	_register_power_node()


func _exit_tree() -> void:
	if _registered_with_power_grid and is_instance_valid(power_grid):
		power_grid.unregister_node(grid_pos)
	_registered_with_power_grid = false


func _process(delta: float) -> void:
	_update_bolt(delta)
	if not active:
		return
	var efficiency: float = get_power_efficiency()
	if efficiency <= 0.0:
		return
	_charge += delta * efficiency
	if _charge < maxf(0.05, fire_interval):
		return
	var target: Node2D = _find_visible_target()
	if target != null:
		_charge = 0.0
		_fire_at(target)


func get_power_draw() -> float:
	return power_draw if active else 0.0


func get_power_consumption() -> float:
	return get_power_draw()


func get_power_efficiency() -> float:
	if not active or power_grid == null:
		return 0.0
	return clampf(power_grid.get_efficiency_at(grid_pos), 0.0, 1.0)


func is_active() -> bool:
	return active and health > 0.0


func take_damage(amount: float) -> void:
	if not active or amount <= 0.0:
		return
	health = maxf(0.0, health - amount)
	if health <= 0.0:
		active = false
		if power_grid != null:
			power_grid.recalculate_networks()
		queue_free()


func apply_damage(amount: float) -> void:
	take_damage(amount)


func _register_power_node() -> void:
	if power_grid != null:
		power_grid.register_node(grid_pos, -POWER_DRAW)
		power_grid.recalculate_networks()
		_registered_with_power_grid = true


func _find_visible_target() -> Node2D:
	var best_target: Node2D = null
	var best_distance: float = attack_range
	for candidate: Node in get_tree().get_nodes_in_group("crawler"):
		var crawler: Node2D = candidate as Node2D
		if crawler == null or not is_instance_valid(crawler):
			continue
		if crawler.has_method("is_alive") and not bool(crawler.call("is_alive")):
			continue
		var distance: float = global_position.distance_to(crawler.global_position)
		if distance > best_distance:
			continue
		if not _has_line_of_sight(crawler):
			continue
		best_target = crawler
		best_distance = distance
	return best_target


func _has_line_of_sight(target: Node2D) -> bool:
	if not is_inside_tree():
		return false
	var query := PhysicsRayQueryParameters2D.create(
		global_position,
		target.global_position,
		line_of_sight_mask,
		[get_rid()]
	)
	query.collide_with_areas = true
	query.collide_with_bodies = true
	var hit: Dictionary = get_world_2d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return true
	var collider: Node = hit.get("collider") as Node
	if collider == target:
		return true
	return collider != null and target.is_ancestor_of(collider)


func _fire_at(target: Node2D) -> void:
	if target.has_method("take_damage"):
		target.call("take_damage", attack_damage)
	elif target.has_method("apply_damage"):
		target.call("apply_damage", attack_damage)
	if _plasma_bolt != null:
		_plasma_bolt.clear_points()
		_plasma_bolt.add_point(Vector2.ZERO)
		_plasma_bolt.add_point(to_local(target.global_position))
		_plasma_bolt.default_color = Color(0.25, 0.95, 1.0, 1.0)
		_plasma_bolt.visible = true
		_bolt_time_remaining = 0.09


func _update_bolt(delta: float) -> void:
	if _plasma_bolt == null or _bolt_time_remaining <= 0.0:
		return
	_bolt_time_remaining = maxf(0.0, _bolt_time_remaining - delta)
	if _bolt_time_remaining <= 0.0:
		_plasma_bolt.visible = false
		_plasma_bolt.clear_points()
	else:
		var alpha: float = clampf(_bolt_time_remaining / 0.09, 0.0, 1.0)
		_plasma_bolt.default_color = Color(0.25, 0.95, 1.0, alpha)


func _ensure_scene_nodes() -> void:
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)

	_plasma_bolt = get_node_or_null("PlasmaBolt") as Line2D
	if _plasma_bolt == null:
		_plasma_bolt = Line2D.new()
		_plasma_bolt.name = "PlasmaBolt"
		add_child(_plasma_bolt)
	_plasma_bolt.width = 2.0
	_plasma_bolt.antialiased = true
	_plasma_bolt.visible = false
	_plasma_bolt.z_index = 4

	var collision: CollisionShape2D = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision == null:
		collision = CollisionShape2D.new()
		collision.name = "CollisionShape2D"
		add_child(collision)
	if collision.shape == null:
		var shape := RectangleShape2D.new()
		shape.size = Vector2(12.0, 14.0)
		collision.shape = shape


func _create_procedural_sprite() -> void:
	if _sprite == null:
		return
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var outline := Color("1d222a")
	var steel := Color("586572")
	var highlight := Color("91a4b1")
	var plasma := Color("41e5f2")

	for y in range(8, 14):
		for x in range(4, 12):
			image.set_pixel(x, y, outline)
	for y in range(9, 13):
		for x in range(5, 11):
			image.set_pixel(x, y, steel)
	for y in range(4, 9):
		for x in range(3, 13):
			image.set_pixel(x, y, outline)
	for y in range(5, 8):
		for x in range(4, 12):
			image.set_pixel(x, y, highlight)
	for x in range(11, 16):
		image.set_pixel(x, 6, outline)
	for x in range(12, 16):
		image.set_pixel(x, 5, plasma)
	image.set_pixel(7, 10, plasma)
	image.set_pixel(8, 10, plasma)
	for x in range(3, 6):
		image.set_pixel(x, 14, outline)
	for x in range(10, 13):
		image.set_pixel(x, 14, outline)
	_sprite.texture = ImageTexture.create_from_image(image)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
