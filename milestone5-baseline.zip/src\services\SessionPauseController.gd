extends Node
class_name SessionPauseController

signal game_paused()
signal game_resumed()
var menu: Node
var _settings_open: bool = false
var _crafting_open: bool = false
var _shop_open: bool = false
var _resetting: bool = false

func configure(settings_menu: Node) -> void:
	menu = settings_menu
	var bus: SignalBus = SignalBus.get_instance()
	bus.settings_menu_toggled.connect(_on_settings)
	bus.crafting_menu_toggled.connect(_on_crafting)
	bus.shop_toggled.connect(_on_shop)
	bus.setting_changed.connect(_on_setting)
	bus.reset_session_requested.connect(_request_reset)
	process_mode = Node.PROCESS_MODE_ALWAYS

func toggle_pause() -> void:
	menu.call("set_open", not _settings_open)

func _on_settings(open: bool) -> void:
	_settings_open = open
	_update_pause()

func _on_crafting(open: bool) -> void:
	_crafting_open = open
	_update_pause()

func _on_shop(open: bool, _npc: String) -> void:
	_shop_open = open
	_update_pause()

func _on_setting(section: String, key: String, _value: Variant) -> void:
	if section == "general" and key == "auto_pause":
		_update_pause()

func _update_pause() -> void:
	var should_pause: bool = _settings_open or ((_crafting_open or _shop_open) and bool(SettingsManager.get_setting("general", "auto_pause", true)))
	if get_tree().paused == should_pause:
		return
	get_tree().paused = should_pause
	if should_pause:
		game_paused.emit()
	else:
		game_resumed.emit()

func _request_reset() -> void:
	if not _resetting:
		_resetting = true
		call_deferred("_reset")

func _reset() -> void:
	menu.call("set_open", false)
	var bus: SignalBus = SignalBus.get_instance()
	bus.settings_menu_toggled.emit(false)
	bus.crafting_menu_toggled.emit(false)
	bus.shop_toggled.emit(false, "")
	get_tree().paused = false
	var error: Error = get_tree().reload_current_scene()
	if error != OK:
		_resetting = false
		bus.show_hud_hint.emit("Session reset failed: %d" % error)
