extends Node
class_name EconomyComponent

## Trade and item-use authority. Item behavior is dispatched by semantic effect keys.
const MAX_CREDITS: int = 1000000000
var credits: int = 0
var crafting: CraftingComponent
var oxygen: OxygenComponent
var battery: BatteryComponent
var mining_laser: MiningLaserComponent
var installed_upgrades: Dictionary = {}
var last_trade_message: String = ""
var _bus: SignalBus
var _shop_open: bool = false
var _shop_name: String = ""
var _transaction_active: bool = false
var _effect_handlers: Dictionary = {}
var _effect_validators: Dictionary = {}

func _ready() -> void:
	_bus = SignalBus.get_instance()
	_register_effects()
	_bus.trade_requested.connect(_on_trade_requested)
	_bus.shop_toggled.connect(_on_shop_toggled)
	_bus.inventory_snapshot_requested.connect(publish_credits_snapshot)
	_bus.item_use_requested.connect(_on_item_use_requested)
	publish_credits_snapshot()

func configure(p_crafting: CraftingComponent, p_oxygen: OxygenComponent, p_battery: BatteryComponent, p_mining_laser: MiningLaserComponent) -> void:
	crafting = p_crafting
	oxygen = p_oxygen
	battery = p_battery
	mining_laser = p_mining_laser
	_register_effects()

func trade(is_buy: bool, item_id: String, quantity: int) -> bool:
	if _transaction_active:
		return false
	if not _has_valid_shop():
		return _report(false, "Trade rejected: open the nearby housed Quartermaster's shop.")
	if quantity < 1 or quantity > ShopRegistry.MAX_QUANTITY or crafting == null:
		return _report(false, "Trade rejected: quantity must be 1–99 and inventory must be available.")
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	var price: int = ShopRegistry.quote(is_buy, definition, quantity)
	if definition == null or price <= 0:
		return _report(false, "The Quartermaster does not accept that trade.")
	var removals: Dictionary = {}
	var additions: Dictionary = {}
	var installs_upgrade: bool = is_buy and definition.unique_upgrade
	if is_buy:
		if credits < price:
			return _report(false, "Insufficient credits: need %d CR." % price)
		if installs_upgrade:
			if quantity != 1 or is_upgrade_installed(item_id):
				return _report(false, "This permanent upgrade installs once; quantity must be 1.")
			if not _can_apply_effects(definition.effects):
				return _report(false, "Upgrade unavailable: required equipment or effect is missing.")
		else:
			additions[item_id] = quantity
	else:
		if credits > MAX_CREDITS - price:
			return _report(false, "Credit capacity reached; trade was not changed.")
		removals[item_id] = quantity
	if not installs_upgrade and not crafting.can_apply_inventory_transaction(removals, additions):
		return _report(false, "Insufficient inventory or item capacity; nothing was changed.")
	_transaction_active = true
	var previous_credits: int = credits
	credits += -price if is_buy else price
	if installs_upgrade:
		installed_upgrades[item_id] = true
		_apply_effects(definition.effects)
		crafting.publish_inventory_snapshot()
	elif not crafting.apply_inventory_transaction(removals, additions):
		credits = previous_credits
		_transaction_active = false
		return _report(false, "Inventory changed; trade cancelled without charging credits.")
	publish_credits_snapshot()
	var verb: String = "Installed" if installs_upgrade else ("Bought" if is_buy else "Sold")
	# Keep the lock through all callbacks to prevent nested signal trades.
	var success: bool = _report(true, "%s %d × %s · %d CR." % [verb, quantity, definition.display_name, price])
	_transaction_active = false
	return success

func use_item(item_id: String) -> bool:
	if _transaction_active or crafting == null:
		return false
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if definition == null or definition.effects.is_empty():
		return _report(false, "That item has no usable effect.")
	if definition.unique_upgrade and is_upgrade_installed(item_id):
		return _report(false, "That permanent upgrade is already installed.")
	if crafting.get_inventory_count(item_id) < 1 or not _can_apply_effects(definition.effects):
		return _report(false, "Item unavailable or its effect cannot be applied.")
	_transaction_active = true
	# Validate the full effect set first, then consume exactly one item.
	if not crafting.remove_item(item_id, 1):
		_transaction_active = false
		return _report(false, "The item is no longer in inventory.")
	if definition.unique_upgrade:
		installed_upgrades[item_id] = true
	_apply_effects(definition.effects)
	publish_credits_snapshot()
	var success: bool = _report(true, ("Installed " if definition.unique_upgrade else "Used ") + definition.display_name + ".")
	_transaction_active = false
	return success

func is_upgrade_installed(item_id: String) -> bool:
	return bool(installed_upgrades.get(item_id, false))

func get_installed_upgrades() -> Dictionary:
	return installed_upgrades.duplicate(true)

func publish_credits_snapshot() -> void:
	if _bus != null:
		_bus.credits_changed.emit(credits)
		_bus.upgrades_updated.emit(get_installed_upgrades())

func _has_valid_shop() -> bool:
	if not _shop_open or not is_inside_tree() or crafting == null:
		return false
	var actor: Node2D = get_parent() as Node2D
	if actor == null or actor.is_queued_for_deletion():
		return false
	for candidate: Node in get_tree().get_nodes_in_group("colonist_npcs"):
		var colonist: ColonistNpc = candidate as ColonistNpc
		if colonist != null and not colonist.is_queued_for_deletion() and colonist.npc_name == _shop_name and colonist.can_interact(actor):
			return true
	return false

func _on_shop_toggled(is_open: bool, npc_name: String) -> void:
	_shop_open = is_open
	_shop_name = npc_name if is_open else ""
	publish_credits_snapshot()

func _on_trade_requested(is_buy: bool, item_id: String, quantity: int) -> void:
	trade(is_buy, item_id, quantity)

func _on_item_use_requested(item_id: String) -> void:
	use_item(item_id)

func _report(success: bool, message: String) -> bool:
	last_trade_message = message
	if _bus != null:
		_bus.trade_completed.emit(success, message)
	return success

func _register_effects() -> void:
	_effect_handlers = {"oxygen_restore": _restore_oxygen, "battery_restore": _restore_battery, "health_restore": _restore_health, "mining_multiplier": _upgrade_mining, "oxygen_capacity": _upgrade_oxygen}
	_effect_validators = {"oxygen_restore": _has_oxygen, "battery_restore": _has_battery, "health_restore": _can_restore_health, "mining_multiplier": _has_mining_laser, "oxygen_capacity": _has_oxygen}

func _can_apply_effects(effects: Dictionary) -> bool:
	if _effect_handlers.is_empty():
		_register_effects()
	if effects.is_empty():
		return false
	for key: Variant in effects:
		var value: Variant = effects[key]
		if not _effect_handlers.has(key) or not (typeof(value) == TYPE_FLOAT or typeof(value) == TYPE_INT):
			return false
		if not is_finite(float(value)) or float(value) <= 0.0:
			return false
		var validator: Callable = _effect_validators[key]
		if not bool(validator.call()):
			return false
	return true

func _apply_effects(effects: Dictionary) -> void:
	for key: Variant in effects:
		var effect: Callable = _effect_handlers[key]
		effect.call(float(effects[key]))

func _has_oxygen() -> bool:
	return is_instance_valid(oxygen)

func _has_battery() -> bool:
	return is_instance_valid(battery)

func _has_mining_laser() -> bool:
	return is_instance_valid(mining_laser)

func _can_restore_health() -> bool:
	return GlobalGameState.get_hp() > 0.0 and GlobalGameState.get_hp() < 100.0

func _restore_oxygen(amount: float) -> void:
	oxygen.restore_oxygen(amount)

func _restore_battery(amount: float) -> void:
	battery.current_battery = clampf(battery.current_battery + amount, 0.0, battery.max_battery)
	if _bus != null:
		_bus.battery_changed.emit(battery.current_battery, battery.max_battery)

func _restore_health(amount: float) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() + amount)

func _upgrade_mining(multiplier: float) -> void:
	mining_laser.mining_damage *= multiplier

func _upgrade_oxygen(amount: float) -> void:
	oxygen.max_oxygen += amount
	oxygen.restore_oxygen(amount)
