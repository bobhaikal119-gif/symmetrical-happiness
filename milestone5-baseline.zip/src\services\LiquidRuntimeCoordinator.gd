extends Node
class_name LiquidRuntimeCoordinator

## Scene adapter supplies dynamic hatch barriers to the pure liquid solver.
## The solver owns conservative displacement when a barrier closes into water.
var _liquids: LiquidGrid
var _previous_barriers: Array[Vector2i] = []

func _ready() -> void:
	process_priority = -90
	call_deferred("_bind")

func _bind() -> void:
	_liquids = get_parent().get("liquid_grid") as LiquidGrid
	_sync_barriers()

func _physics_process(_delta: float) -> void:
	if _liquids != null:
		_sync_barriers()

func _sync_barriers() -> void:
	if _liquids == null:
		return
	var barriers: Array[Vector2i] = []
	for candidate: Node in get_tree().get_nodes_in_group("blast_doors"):
		var door: BlastDoor = candidate as BlastDoor
		if door != null and not door.is_queued_for_deletion() and not door.is_open:
			barriers.append(door.grid_pos)
	barriers.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.y < b.y or (a.y == b.y and a.x < b.x))
	if barriers != _previous_barriers:
		_previous_barriers = barriers
		_liquids.set_blocked_cells(barriers)
