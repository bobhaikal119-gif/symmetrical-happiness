extends Resource

class_name BiomeDef

"""
BiomeDef: Data structure defining a depth-tiered biome in DEEPWELL.
Each biome has a depth range, color palette, and ambient light color.
"""

# Biome identification

@export var id: int = 0
"""Unique identifier for the biome.
"""

@export var biome_name: String = "Unknown"
"""Human-readable biome name.
"""

# Depth range

@export var depth_min: int = 0
"""Minimum depth (in tiles) where this biome appears.
"""

@export var depth_max: int = 511
"""Maximum depth (in tiles) where this biome appears.
"""

# Color palette

@export var surface_color: Color = Color.WHITE
"""Color for surface tiles in this biome.
"""

@export var stone_color: Color = Color.GRAY
"""Color for stone tiles in this biome.
"""

@export var ore_color: Color = Color.WHITE
"""Color for ore tiles in this biome.
"""

# Ambient lighting

@export var ambient_light: Color = Color(1, 1, 1, 1)
"""Ambient light color multiplier for this biome.
"""

# Static registry for biome lookup

var _registry: Dictionary = {}

func _init(p_id: int = 0, p_name: String = "Unknown", p_depth_min: int = 0, p_depth_max: int = 511, p_surface_color: Color = Color.WHITE, p_stone_color: Color = Color.GRAY, p_ore_color: Color = Color.WHITE, p_ambient_light: Color = Color(1, 1, 1, 1)) -> void:
    """Initialize biome definition.
    
    @param p_id: Biome ID
    @param p_name: Biome name
    @param p_depth_min: Minimum depth
    @param p_depth_max: Maximum depth
    @param p_surface_color: Surface tile color
    @param p_stone_color: Stone tile color
    @param p_ore_color: Ore tile color
    @param p_ambient_light: Ambient light color
    """
    id = p_id
    biome_name = p_name
    depth_min = p_depth_min
    depth_max = p_depth_max
    surface_color = p_surface_color
    stone_color = p_stone_color
    ore_color = p_ore_color
    ambient_light = p_ambient_light

func is_valid() -> bool:
    """Validate biome definition properties.
    
    @return True if biome definition is valid.
    """
    if id < 0:
        return false
    if depth_min > depth_max:
        return false
    if depth_min < 0 or depth_max > 511:
        return false
    return true

# Static registry access

var _biome_registry: Dictionary = {
    0: null,
    1: null,
    2: null,
    3: null
}

func _register_biome(biome: BiomeDef) -> void:
    """Register a biome in the static lookup table.
    
    @param biome: BiomeDef to register.
    """
    if _biome_registry.has(biome.id):
        _biome_registry[biome.id] = biome

func get_biome_for_depth(depth: int) -> BiomeDef:
    """Get the biome definition for a given depth.
    
    @param depth: Depth in tiles (y-coordinate).
    @return BiomeDef matching the depth, or null if none found.
    """
    for biome in _biome_registry.values():
        if biome != null and depth >= biome.depth_min and depth <= biome.depth_max:
            return biome
    return null

# Initialize default biomes on script load

func _setup_default_biomes() -> void:
    """Set up the four default biomes for DEEPWELL."""
    # ID 0: Permafrost Surface (depth 0-63)
    var surface := BiomeDef.new()
    surface.id = 0
    surface.biome_name = "Permafrost Surface"
    surface.depth_min = 0
    surface.depth_max = 63
    surface.surface_color = Color(0.95, 0.95, 0.98, 1.0)
    surface.stone_color = Color(0.8, 0.85, 0.9, 1.0)
    surface.ore_color = Color(0.7, 0.8, 0.9, 1.0)
    surface.ambient_light = Color(1, 1, 1, 0.3)
    _register_biome(surface)

    # ID 1: Shattered Crust (depth 64-191)
    var crust := BiomeDef.new()
    crust.id = 1
    crust.biome_name = "Shattered Crust"
    crust.depth_min = 64
    crust.depth_max = 191
    crust.surface_color = Color(0.3, 0.3, 0.35, 1.0)
    crust.stone_color = Color(0.4, 0.4, 0.45, 1.0)
    crust.ore_color = Color(0.8, 0.5, 0.2, 1.0)
    crust.ambient_light = Color(0.8, 0.8, 0.9, 0.5)
    _register_biome(crust)

    # ID 2: Fungal Biolume Depths (depth 192-319)
    var biolume := BiomeDef.new()
    biolume.id = 2
    biolume.biome_name = "Fungal Biolume Depths"
    biolume.depth_min = 192
    biolume.depth_max = 319
    biolume.surface_color = Color(0.2, 0.1, 0.3, 1.0)
    biolume.stone_color = Color(0.3, 0.2, 0.4, 1.0)
    biolume.ore_color = Color(0.4, 0.9, 0.6, 1.0)
    biolume.ambient_light = Color(0.4, 0.2, 0.6, 0.7)
    _register_biome(biolume)

    # ID 3: Magma Faultline (depth 320-511)
    var magma := BiomeDef.new()
    magma.id = 3
    magma.biome_name = "Magma Faultline"
    magma.depth_min = 320
    magma.depth_max = 511
    magma.surface_color = Color(0.2, 0.1, 0.1, 1.0)
    magma.stone_color = Color(0.25, 0.15, 0.15, 1.0)
    magma.ore_color = Color(0.9, 0.3, 0.1, 1.0)
    magma.ambient_light = Color(0.8, 0.3, 0.1, 0.8)
    _register_biome(magma)

# Run setup on first access

var _initialized: bool = false

func _ensure_initialized() -> void:
    """Ensure default biomes are registered."""
    if not _initialized:
        _setup_default_biomes()
        _initialized = true

# Override get_biome_for_depth to ensure initialization

func get_biome_for_depth_safe(depth: int) -> BiomeDef:
    """Get biome for depth with guaranteed initialization.
    
    @param depth: Depth in tiles.
    @return BiomeDef matching the depth.
    """
    _ensure_initialized()
    return get_biome_for_depth(depth)