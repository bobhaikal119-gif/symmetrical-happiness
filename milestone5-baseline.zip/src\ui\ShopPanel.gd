extends CanvasLayer
class_name ShopPanel

## Quartermaster trading terminal. Business rules remain in EconomyComponent.
var is_open: bool = false
var _bus: SignalBus
var _inventory: Dictionary = {}
var _installed_upgrades: Dictionary = {}
var _credits: int = 0
var _is_buy: bool = true
var _quantities: Dictionary = {}
var _rows: Dictionary = {}
var _overlay: Control
var _window: PanelContainer
var _title: Label
var _balance: Label
var _status: Label
var _list: VBoxContainer
var _buy_tab: Button
var _sell_tab: Button
var _close_button: Button
var _layout_queued: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 45
	_bus = SignalBus.get_instance()
	_build_view()
	_bus.shop_toggled.connect(_on_shop_toggled)
	_bus.inventory_updated.connect(_on_inventory_updated)
	_bus.credits_changed.connect(_on_credits_changed)
	_bus.upgrades_updated.connect(_on_upgrades_updated)
	_bus.trade_completed.connect(_on_trade_completed)
	get_viewport().size_changed.connect(_resize_window)
	_window.minimum_size_changed.connect(_queue_layout)
	_rebuild_rows()
	_resize_window()
	visible = false

func set_open(open: bool, npc_name: String = "Quartermaster") -> void:
	if is_open != open:
		_bus.shop_toggled.emit(open, npc_name)

func _on_shop_toggled(open: bool, npc_name: String) -> void:
	var changed: bool = is_open != open
	is_open = open
	visible = open
	if open:
		_title.text = (npc_name if not npc_name.is_empty() else "Quartermaster").to_upper()
		if changed:
			_bus.crafting_menu_toggled.emit(false)
			_status.text = "Buy supplies or sell recovered materials. Prices shown are final."
			_bus.inventory_snapshot_requested.emit()
			_close_button.grab_focus()
		_refresh_rows()

func _build_view() -> void:
	_overlay = Control.new()
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_overlay)
	_window = PanelContainer.new()
	_overlay.add_child(_window)
	var content := VBoxContainer.new()
	_window.add_child(content)
	var header := PanelContainer.new()
	header.theme_type_variation = &"HeaderPanel"
	content.add_child(header)
	var header_row := HBoxContainer.new()
	header.add_child(header_row)
	_title = Label.new()
	_title.text = "QUARTERMASTER"
	_title.theme_type_variation = &"HeaderLabel"
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header_row.add_child(_title)
	_close_button = _button("[X]", _close_panel)
	_close_button.theme_type_variation = &"HeaderButton"
	_close_button.tooltip_text = "Close Quartermaster [Esc]"
	header_row.add_child(_close_button)
	var controls := HBoxContainer.new()
	content.add_child(controls)
	_buy_tab = _button("BUY", _set_mode.bind(true))
	_buy_tab.theme_type_variation = &"CategoryButton"
	_buy_tab.toggle_mode = true
	controls.add_child(_buy_tab)
	_sell_tab = _button("SELL", _set_mode.bind(false))
	_sell_tab.theme_type_variation = &"CategoryButton"
	_sell_tab.toggle_mode = true
	controls.add_child(_sell_tab)
	_balance = Label.new()
	_balance.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_balance.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	controls.add_child(_balance)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_list)
	_status = Label.new()
	_status.custom_minimum_size.y = 48.0
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(_status)
	AntiSlopTheme.apply_to(_overlay)

func _queue_layout() -> void:
	if not _layout_queued:
		_layout_queued = true
		call_deferred("_resize_window")

func _resize_window() -> void:
	_layout_queued = false
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	_window.size = Vector2(minf(960.0, viewport_size.x - 32.0), minf(656.0, viewport_size.y - 32.0))
	_window.position = ((viewport_size - _window.size) * 0.5).floor()

func _set_mode(is_buy: bool) -> void:
	_is_buy = is_buy
	_rebuild_rows()

func _rebuild_rows() -> void:
	for child: Node in _list.get_children():
		_list.remove_child(child)
		child.queue_free()
	_rows.clear()
	_buy_tab.set_pressed_no_signal(_is_buy)
	_sell_tab.set_pressed_no_signal(not _is_buy)
	for definition: ItemDef in ItemRegistry.get_instance().get_all_items():
		if _is_buy and not ShopRegistry.can_buy(definition):
			continue
		if not _is_buy and (not ShopRegistry.can_sell(definition) or int(_inventory.get(definition.id, 0)) <= 0):
			continue
		var frame := PanelContainer.new()
		frame.theme_type_variation = &"InsetPanel"
		_list.add_child(frame)
		var column := VBoxContainer.new()
		frame.add_child(column)
		var row := HBoxContainer.new()
		column.add_child(row)
		var icon := TextureRect.new()
		icon.texture = ProceduralItemIcons.get_instance().get_item_icon_texture(definition.id)
		icon.custom_minimum_size = Vector2(32, 32)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		row.add_child(icon)
		var item_label := Label.new()
		item_label.text = definition.display_name
		item_label.tooltip_text = definition.description
		item_label.clip_text = true
		item_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		item_label.custom_minimum_size.x = 64.0
		item_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(item_label)
		var owned := Label.new()
		owned.custom_minimum_size.x = 112.0
		owned.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(owned)
		var minus: Button = _button("-", _change_quantity.bind(definition.id, -1))
		minus.custom_minimum_size.x = 40.0
		minus.tooltip_text = "Reduce trade quantity"
		row.add_child(minus)
		var quantity := Label.new()
		quantity.custom_minimum_size.x = 48.0
		quantity.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(quantity)
		var plus: Button = _button("+", _change_quantity.bind(definition.id, 1))
		plus.custom_minimum_size.x = 40.0
		plus.tooltip_text = "Increase trade quantity (maximum %d)" % ShopRegistry.MAX_QUANTITY
		row.add_child(plus)
		var total := Label.new()
		total.custom_minimum_size.x = 112.0
		total.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(total)
		var trade: Button = _button("BUY" if _is_buy else "SELL", _request_trade.bind(definition.id))
		trade.custom_minimum_size.x = 88.0
		row.add_child(trade)
		var detail := Label.new()
		detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		column.add_child(detail)
		_rows[definition.id] = {"definition": definition, "owned": owned, "minus": minus, "quantity": quantity, "plus": plus, "total": total, "trade": trade, "detail": detail}
	if _rows.is_empty():
		var empty := Label.new()
		empty.text = "No sellable materials in inventory. Mine ore or refine ingots, then return to trade." if not _is_buy else "The Quartermaster has no available stock."
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_list.add_child(empty)
	_refresh_rows()
	call_deferred("_resize_window")

func _refresh_rows() -> void:
	_balance.text = "%d CR" % _credits
	for item_id: String in _rows:
		var entry: Dictionary = _rows[item_id]
		var definition: ItemDef = entry["definition"] as ItemDef
		var owned: int = int(_inventory.get(item_id, 0))
		var maximum: int = 1 if _is_buy and definition.unique_upgrade else (ShopRegistry.MAX_QUANTITY if _is_buy else mini(ShopRegistry.MAX_QUANTITY, owned))
		var quantity: int = clampi(int(_quantities.get(item_id, 1)), 1, maxi(1, maximum))
		_quantities[item_id] = quantity
		var total: int = ShopRegistry.quote(_is_buy, definition, quantity)
		(entry["owned"] as Label).text = "%d OWNED" % owned
		(entry["quantity"] as Label).text = str(quantity)
		(entry["minus"] as Button).disabled = quantity <= 1
		(entry["plus"] as Button).disabled = quantity >= maximum
		(entry["total"] as Label).text = "%d CR" % total
		var installed: bool = _is_buy and definition.unique_upgrade and bool(_installed_upgrades.get(item_id, false))
		var allowed: bool = (_credits >= total if _is_buy else owned >= quantity) and not installed
		var unit_price: int = ShopRegistry.get_buy_price(definition) if _is_buy else ShopRegistry.get_sell_price(definition)
		var reason: String = "%d CR each. %s" % [unit_price, definition.description]
		if not allowed:
			reason = "INSUFFICIENT CREDITS: need %d CR, balance %d CR. %s" % [total, _credits, definition.description] if _is_buy else "Insufficient inventory for this quantity."
		if installed:
			reason = "INSTALLED — permanent upgrade already active."
			(entry["owned"] as Label).text = "INSTALLED"
		(entry["trade"] as Button).disabled = not allowed
		(entry["trade"] as Button).tooltip_text = reason
		(entry["detail"] as Label).text = reason

func _change_quantity(item_id: String, delta: int) -> void:
	_quantities[item_id] = int(_quantities.get(item_id, 1)) + delta
	_refresh_rows()

func _request_trade(item_id: String) -> void:
	_status.text = "Submitting trade..."
	_bus.trade_requested.emit(_is_buy, item_id, int(_quantities.get(item_id, 1)))

func _on_inventory_updated(inventory: Dictionary) -> void:
	_inventory = inventory.duplicate(true)
	if _is_buy:
		_refresh_rows()
	else:
		_rebuild_rows()

func _on_upgrades_updated(installed: Dictionary) -> void:
	_installed_upgrades = installed.duplicate(true)
	_refresh_rows()

func _on_credits_changed(current_credits: int) -> void:
	_credits = current_credits
	_refresh_rows()

func _on_trade_completed(success: bool, message: String) -> void:
	_status.text = "%s: %s" % ["TRADE COMPLETE" if success else "TRADE REJECTED", message]
	_refresh_rows()

func _close_panel() -> void:
	set_open(false)

func _button(text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 40.0
	AntiSlopTheme.wire_button(button)
	button.pressed.connect(callback)
	return button
