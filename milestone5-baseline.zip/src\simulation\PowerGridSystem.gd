extends RefCounted

class_name PowerGridSystem

## Pure power-network simulation. The graph is made from power-cable cells and
## registered power-node coordinates; no scene-tree or entity objects are held.

signal network_totals_updated(totals: Dictionary)

const CARDINAL_DIRECTIONS := [
	Vector2i.LEFT,
	Vector2i.RIGHT,
	Vector2i.UP,
	Vector2i.DOWN,
]
const WATT_EPSILON: float = 0.000001

var world_grid: WorldGrid = null

# Vector2i -> float. Positive values produce power and negative values consume it.
var _node_wattages: Dictionary = {}
# Used when the simulation is run without a WorldGrid (for tests or previews).
var _manual_cable_positions: Dictionary = {}

var _efficiency_by_position: Dictionary = {}
var _network_id_by_position: Dictionary = {}
var _networks: Array[Dictionary] = []
var _totals: Dictionary = {}


func _init(p_world_grid: WorldGrid = null) -> void:
	world_grid = p_world_grid
	_reset_totals()
	recalculate_networks()


func set_world_grid(p_world_grid: WorldGrid) -> void:
	world_grid = p_world_grid
	recalculate_networks()


func set_power_cable_positions(positions: Array[Vector2i]) -> void:
	## Supplies cable cells when no WorldGrid is attached.
	_manual_cable_positions.clear()
	for position: Vector2i in positions:
		_manual_cable_positions[position] = true
	recalculate_networks()


func register_node(grid_pos: Vector2i, wattage_delta: float) -> void:
	_node_wattages[grid_pos] = wattage_delta
	recalculate_networks()


func unregister_node(grid_pos: Vector2i) -> void:
	if _node_wattages.erase(grid_pos):
		recalculate_networks()


func recalculate_networks() -> void:
	_efficiency_by_position.clear()
	_network_id_by_position.clear()
	_networks.clear()

	var cable_positions: Dictionary = _collect_cable_positions()
	var graph_positions: Dictionary = cable_positions.duplicate()
	for node_position: Variant in _node_wattages.keys():
		graph_positions[node_position] = true

	var visited: Dictionary = {}
	var network_id: int = 0
	for start_variant: Variant in graph_positions.keys():
		var start: Vector2i = start_variant
		if visited.has(start):
			continue

		var component: Array[Vector2i] = _breadth_first_component(
			start, graph_positions, visited
		)
		var network: Dictionary = _build_network(
			network_id, component, cable_positions
		)
		_networks.append(network)

		var efficiency: float = float(network["efficiency"])
		for position: Vector2i in component:
			_efficiency_by_position[position] = efficiency
			_network_id_by_position[position] = network_id
		network_id += 1

	_rebuild_totals(cable_positions.size())
	network_totals_updated.emit(get_totals())


func get_efficiency_at(grid_pos: Vector2i) -> float:
	return float(_efficiency_by_position.get(grid_pos, 0.0))


func get_totals() -> Dictionary:
	## Returns a copy so presentation code cannot mutate simulation state.
	return _totals.duplicate(true)


func get_networks() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for network: Dictionary in _networks:
		result.append(network.duplicate(true))
	return result


func get_network_at(grid_pos: Vector2i) -> Dictionary:
	var network_id: int = int(_network_id_by_position.get(grid_pos, -1))
	if network_id < 0 or network_id >= _networks.size():
		return {}
	return _networks[network_id].duplicate(true)


func get_registered_nodes() -> Dictionary:
	return _node_wattages.duplicate()


func clear_nodes() -> void:
	if _node_wattages.is_empty():
		return
	_node_wattages.clear()
	recalculate_networks()


func _collect_cable_positions() -> Dictionary:
	var result: Dictionary = {}
	if world_grid != null:
		for position: Vector2i in world_grid.get_power_cable_positions():
			result[position] = true
	else:
		result = _manual_cable_positions.duplicate()
	return result


func _breadth_first_component(
	start: Vector2i,
	graph_positions: Dictionary,
	visited: Dictionary
) -> Array[Vector2i]:
	var component: Array[Vector2i] = []
	var queue: Array[Vector2i] = [start]
	var read_index: int = 0
	visited[start] = true

	while read_index < queue.size():
		var current: Vector2i = queue[read_index]
		read_index += 1
		component.append(current)

		for direction: Vector2i in CARDINAL_DIRECTIONS:
			var neighbor: Vector2i = current + direction
			if graph_positions.has(neighbor) and not visited.has(neighbor):
				visited[neighbor] = true
				queue.append(neighbor)

	return component


func _build_network(
	network_id: int,
	component: Array[Vector2i],
	cable_positions: Dictionary
) -> Dictionary:
	var produced_watts: float = 0.0
	var demand_watts: float = 0.0
	var node_positions: Array[Vector2i] = []
	var network_cables: Array[Vector2i] = []

	for position: Vector2i in component:
		if cable_positions.has(position):
			network_cables.append(position)
		if not _node_wattages.has(position):
			continue
		node_positions.append(position)
		var wattage_delta: float = float(_node_wattages[position])
		if wattage_delta > 0.0:
			produced_watts += wattage_delta
		elif wattage_delta < 0.0:
			demand_watts += -wattage_delta

	var efficiency: float = _calculate_efficiency(produced_watts, demand_watts)
	return {
		"id": network_id,
		"positions": component.duplicate(),
		"nodes": node_positions,
		"cables": network_cables,
		"produced_watts": produced_watts,
		"demand_watts": demand_watts,
		"net_watts": produced_watts - demand_watts,
		"supplied_watts": minf(produced_watts, demand_watts),
		"unmet_demand_watts": maxf(demand_watts - produced_watts, 0.0),
		"efficiency": efficiency,
	}


func _calculate_efficiency(produced_watts: float, demand_watts: float) -> float:
	if demand_watts <= WATT_EPSILON:
		return 1.0
	return clampf(produced_watts / demand_watts, 0.0, 1.0)


func _rebuild_totals(cable_count: int) -> void:
	var produced_watts: float = 0.0
	var demand_watts: float = 0.0
	var supplied_watts: float = 0.0
	var unmet_demand_watts: float = 0.0
	for network: Dictionary in _networks:
		produced_watts += float(network["produced_watts"])
		demand_watts += float(network["demand_watts"])
		supplied_watts += float(network["supplied_watts"])
		unmet_demand_watts += float(network["unmet_demand_watts"])

	var aggregate_efficiency: float = 1.0
	if demand_watts > WATT_EPSILON:
		aggregate_efficiency = clampf(supplied_watts / demand_watts, 0.0, 1.0)

	_totals = {
		"circuit_count": _networks.size(),
		"node_count": _node_wattages.size(),
		"cable_count": cable_count,
		"produced_watts": produced_watts,
		"demand_watts": demand_watts,
		"net_watts": produced_watts - demand_watts,
		"supplied_watts": supplied_watts,
		"unmet_demand_watts": unmet_demand_watts,
		"efficiency": aggregate_efficiency,
	}


func _reset_totals() -> void:
	_totals = {
		"circuit_count": 0,
		"node_count": 0,
		"cable_count": 0,
		"produced_watts": 0.0,
		"demand_watts": 0.0,
		"net_watts": 0.0,
		"supplied_watts": 0.0,
		"unmet_demand_watts": 0.0,
		"efficiency": 1.0,
	}
