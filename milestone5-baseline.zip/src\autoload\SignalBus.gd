extends Node

class_name SignalBus

## Centralized dispatcher for gameplay, presentation, and UI events.

# Milestone 1-3 world and player contracts.
signal tile_damaged(grid_pos: Vector2i, current_hp: float, max_hp: float)
signal tile_broken(grid_pos: Vector2i, tile_id: int)
signal tile_placed(grid_pos: Vector2i, tile_id: int)
signal temperature_changed(current: float, maximum: float)
signal battery_changed(current: float, maximum: float)
signal hp_changed(current: float, maximum: float)
signal oxygen_changed(current: float, maximum: float)
signal heater_deployed(world_pos: Vector2, radius: float)
signal camp_heater_placed(world_pos: Vector2)
signal cryo_storm_timer_updated(time_left: float)
signal depth_changed(meters: int, biome_name: String)
signal cave_in_triggered(origin_grid: Vector2i, collapsed_tiles: Array[Vector2i])
signal cave_in_visual(origin_grid: Vector2i)
signal crafting_menu_toggled(is_open: bool)
signal craft_requested(recipe_id: String)
signal structure_placed(grid_pos: Vector2i, item_id: String)

# Compatibility contracts used by existing game-state, pickup, crafting, and UI callers.
signal player_spawned(world_pos: Vector2)
signal player_died
signal item_collected(item_id: String, count: int)
signal craft_completed(recipe_id: String, success: bool)
signal show_hud_hint(message: String)
signal hide_hud_hint

# Legacy HUD aliases retained for Milestone 1-3 scenes.
signal temperature_updated(current: float, maximum: float)
signal battery_updated(current: float, maximum: float)
signal hp_updated(current: float, maximum: float)

# Milestone 4 automation, power, and combat contracts.
signal power_grid_updated(produced_watts: float, demand_watts: float, efficiency: float)
signal auto_drill_extracted(grid_pos: Vector2i, item_id: String)
signal storm_wave_started(wave_number: int, enemy_count: int)
signal enemy_defeated(world_pos: Vector2, drop_item_id: String)

# Milestone 4A settings contracts. Existing signal signatures remain unchanged.
signal setting_changed(section: String, key: String, value: Variant)
signal keybinds_updated()
signal smart_cursor_toggled(enabled: bool)

# Presentation/lifecycle requests keep settings UI independent of the world.
signal settings_menu_toggled(is_open: bool)
signal reset_session_requested()

# Milestone 4B locked housing/economy/crafting contracts.
signal credits_changed(current_credits: int)
signal npc_housed(npc_name: String, room_center: Vector2)
signal shop_toggled(is_open: bool, npc_name: String)
signal trade_requested(is_buy: bool, item_id: String, quantity: int)
signal nearby_stations_changed(stations: Array[String])

# Value snapshots keep UI and pure simulation independent from scene entities.
signal ui_button_clicked()
signal inventory_updated(inventory: Dictionary)
signal inventory_snapshot_requested()
signal trade_completed(success: bool, message: String)
signal background_wall_changed(grid_pos: Vector2i, tile_id: int)
signal building_item_selected(item_id: String)
signal item_use_requested(item_id: String)
signal housing_status_changed(message: String)
signal performance_updated(fps: float, active_nodes: int, total_nodes: int)
signal upgrades_updated(installed: Dictionary)

# Milestone 4C locked aim, diving and liquid presentation contracts.
signal aim_telemetry_updated(spread_ratio: float, in_reach: bool, smart_locked: bool)
signal player_submerged_changed(is_submerged: bool, depth_ratio: float)
signal liquid_splashed(world_pos: Vector2, liquid_id: int, intensity: float)

# Equipment snapshots contain metadata, never actor references.
signal equipment_changed(underwater_o2_multiplier: float, water_chill_multiplier: float)
signal equipment_snapshot_requested()
signal liquid_save_requested()
signal liquid_load_requested()
signal liquid_save_completed(success: bool, message: String)

static var _instance: SignalBus = null


static func get_instance() -> SignalBus:
	## Return the process-local signal bus, creating it before SceneTree attachment if needed.
	if not is_instance_valid(_instance):
		_instance = SignalBus.new()
	return _instance


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
