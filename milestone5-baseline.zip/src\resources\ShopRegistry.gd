extends RefCounted
class_name ShopRegistry

## Pure price policy. Callers supply an ItemDef; no world or actor dependencies.
const BUY_CATALOG: PackedStringArray = ["fuel_cell", "nano_medkit", "drill_overclock_module", "extended_o2_tank", "precursor_schematic"]
const MAX_QUANTITY: int = 99

static func get_buy_items() -> PackedStringArray:
	return BUY_CATALOG.duplicate()

static func can_buy(definition: ItemDef) -> bool:
	return definition != null and BUY_CATALOG.has(definition.id)

static func can_sell(definition: ItemDef) -> bool:
	return definition != null and definition.sellable and definition.base_value > 0

static func get_buy_price(definition: ItemDef) -> int:
	return maxi(1, definition.base_value * 2) if can_buy(definition) else 0

static func get_sell_price(definition: ItemDef) -> int:
	return maxi(1, definition.base_value) if can_sell(definition) else 0

static func quote(is_buy: bool, definition: ItemDef, quantity: int) -> int:
	if quantity < 1 or quantity > MAX_QUANTITY:
		return 0
	var unit: int = get_buy_price(definition) if is_buy else get_sell_price(definition)
	return unit * quantity
