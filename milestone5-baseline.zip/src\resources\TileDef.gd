extends Resource

class_name TileDef

"""
TileDef: Data structure representing a tile type in DEEPWELL.
Contains all necessary properties for tile behavior, rendering, and game logic.
"""

# Tile identification

@export var id: int = 0
"""Unique identifier for the tile type.
"""

@export var tile_name: String = "Tile"
"""Human-readable name of the tile.
"""

# Tile properties

@export var max_hp: float = 1.0
"""Maximum health points. 0 means indestructible.
"""

@export var color: Color = Color.WHITE
"""Base color for tile rendering.
"""

@export var is_solid: bool = true
"""Determines if tile provides collision/solid interaction.
"""

@export var min_depth: int = 0
"""Minimum depth level where tile can be placed.
Tiles with higher min_depth can only be placed at deeper levels.
"""

# Hazard properties

@export var is_hazard: bool = false
"""Determines if tile deals damage to entities on contact.
"""

@export var hazard_damage: float = 0.0
"""Damage per second dealt to entities in contact with this hazard tile.
"""

@export var hazard_type: String = "contact"
"""Type of hazard: "thermal" (heat damage) or "contact" (corrosive/physical).
Valid values: "thermal", "contact".
"""

# Helper function

func get_is_destructible() -> bool:
    """Return true if tile can be damaged/destroyed.
    Tiles with max_hp > 0 are destructible.
    """
    return max_hp > 0

func _validate_tile_properties() -> void:
    """Internal validation to ensure tile properties are consistent.
    """
    if id < 0:
        push_error("Tile ID cannot be negative")
    if max_hp < 0:
        push_error("Max HP cannot be negative")
    if min_depth < -1000 or min_depth > 1000:
        push_error("Min depth out of reasonable bounds")
    if hazard_type != "" and hazard_type != "thermal" and hazard_type != "contact":
        push_error("Invalid hazard_type: must be 'thermal' or 'contact'")

func _init() -> void:
    """Initialize default tile properties.
    """
    _validate_tile_properties()