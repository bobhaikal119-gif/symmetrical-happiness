extends Node
class_name ThermalComponent

## Ambient/heater semantics are unchanged; only actual water torso exposure chills.
@export var ambient_cooldown_rate: float = -0.1
@export var heater_restore_rate: float = 0.5
@export var water_chill_rate: float = 1.5
@export var lava_heat_rate: float = 18.0
@export var lava_damage_rate: float = 20.0
@export var max_temperature: float = 100.0
@export var min_temperature: float = -50.0

var current_temperature: float = 20.0
var is_near_heater: bool = false
var water_chill_multiplier: float = 1.0
var liquid_id: int = 0
var liquid_exposure: float = 0.0
var signal_bus: SignalBus
var _last_emitted: float = INF

func _ready() -> void:
	signal_bus = SignalBus.get_instance()
	signal_bus.equipment_changed.connect(_on_equipment_changed)
	_emit_temperature_changed(true)
	signal_bus.equipment_snapshot_requested.emit()

func _process(delta: float) -> void:
	if delta <= 0.0:
		return
	var rate: float = ambient_cooldown_rate
	if is_near_heater:
		rate += heater_restore_rate
	if liquid_id == LiquidGrid.WATER:
		rate -= water_chill_rate * liquid_exposure * water_chill_multiplier
	elif liquid_id == LiquidGrid.LAVA:
		# Cold-water insulation is not lava armor. Never cool or duplicate tile heat.
		rate += lava_heat_rate * liquid_exposure
		if liquid_exposure > 0.0:
			GlobalGameState.set_hp(GlobalGameState.get_hp() - lava_damage_rate * liquid_exposure * delta)
	current_temperature = clampf(current_temperature + rate * delta, min_temperature, max_temperature)
	_emit_temperature_changed(false)

func set_liquid_exposure(exposure_liquid: int, depth_ratio: float) -> void:
	liquid_id = exposure_liquid if exposure_liquid == LiquidGrid.WATER or exposure_liquid == LiquidGrid.LAVA else LiquidGrid.NONE
	liquid_exposure = clampf(depth_ratio, 0.0, 1.0) if is_finite(depth_ratio) else 0.0

func set_submersion(_is_submerged: bool, depth_ratio: float) -> void:
	# The values-only HUD signal cannot identify liquid type; preserve known type.
	set_liquid_exposure(liquid_id, depth_ratio)

func _on_equipment_changed(_o2_multiplier: float, chill_multiplier: float) -> void:
	water_chill_multiplier = clampf(chill_multiplier, 0.0, 10.0) if is_finite(chill_multiplier) else 1.0

func _emit_temperature_changed(force: bool) -> void:
	if signal_bus != null and (force or absf(current_temperature - _last_emitted) >= 0.05):
		_last_emitted = current_temperature
		signal_bus.temperature_changed.emit(current_temperature, max_temperature)

func set_near_heater_near_status(status: bool) -> void:
	is_near_heater = status
	_emit_temperature_changed(true)

func set_near_heater(status: bool) -> void:
	set_near_heater_near_status(status)

func get_temperature() -> float:
	return current_temperature
