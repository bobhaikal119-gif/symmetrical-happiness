extends Node
class_name EquipmentComponent

## Passive suit loadout derives capabilities exclusively from inventory metadata.
## Strongest per slot, then multiplicative across slots; duplicate copies never stack.
var crafting: CraftingComponent
var underwater_o2_multiplier: float = 1.0
var water_chill_multiplier: float = 1.0
var _bus: SignalBus

func _ready() -> void:
	_bus = SignalBus.get_instance()
	_bus.inventory_updated.connect(_on_inventory_updated)
	_bus.equipment_snapshot_requested.connect(publish_snapshot)
	var owner_inventory: CraftingComponent = get_parent().get_node_or_null("CraftingComponent") as CraftingComponent
	configure(owner_inventory)

func configure(inventory: CraftingComponent) -> void:
	crafting = inventory
	if crafting != null:
		_on_inventory_updated(crafting.get_inventory())

func _on_inventory_updated(snapshot: Dictionary) -> void:
	var slots: Dictionary = {}
	for item_id: String in snapshot:
		if int(snapshot[item_id]) <= 0:
			continue
		var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
		if definition == null or definition.equipment_slot.is_empty():
			continue
		var slot: Dictionary = slots.get(definition.equipment_slot, {"oxygen": 1.0, "chill": 1.0})
		var oxygen: float = definition.underwater_o2_multiplier
		var chill: float = definition.water_chill_multiplier
		if is_finite(oxygen):
			slot["oxygen"] = minf(float(slot["oxygen"]), clampf(oxygen, 0.0, 1.0))
		if is_finite(chill):
			slot["chill"] = minf(float(slot["chill"]), clampf(chill, 0.0, 1.0))
		slots[definition.equipment_slot] = slot
	underwater_o2_multiplier = 1.0
	water_chill_multiplier = 1.0
	for slot: Dictionary in slots.values():
		underwater_o2_multiplier *= float(slot["oxygen"])
		water_chill_multiplier *= float(slot["chill"])
	publish_snapshot()

func publish_snapshot() -> void:
	if _bus != null:
		_bus.equipment_changed.emit(underwater_o2_multiplier, water_chill_multiplier)
