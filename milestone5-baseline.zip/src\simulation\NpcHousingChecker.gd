extends RefCounted
class_name NpcHousingChecker

## Bounded value-only enclosure validation; descriptors are immutable snapshots.
const MIN_ROOM_CELLS: int = 12
const MAX_ROOM_CELLS: int = 512
const DIRECTIONS: Array[Vector2i] = [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]

func validate_room(world: WorldGrid, start: Vector2i, structures: Array[Dictionary]) -> Dictionary:
	var cells: Array[Vector2i] = []
	if world == null or not world.is_valid_position(start.x, start.y):
		return _result(false, "Room leaks outside the world.", cells)
	var doors: Dictionary = {}
	for descriptor: Dictionary in structures:
		var cell_value: Variant = descriptor.get("cell")
		var tags: Array = descriptor.get("tags", [])
		if cell_value is Vector2i and tags.has("door"):
			doors[cell_value] = true
	if world.is_solid(start.x, start.y) or doors.has(start):
		return _result(false, "Choose an empty interior cell, not a wall or door.", cells)
	var discovered: Dictionary = {start: true}
	var queue: Array[Vector2i] = [start]
	var head: int = 0
	var has_hazard: bool = false
	var missing_background: bool = false
	while head < queue.size():
		var cell: Vector2i = queue[head]
		head += 1
		cells.append(cell)
		has_hazard = has_hazard or world.is_hazard(cell.x, cell.y)
		missing_background = missing_background or world.get_background_wall(cell.x, cell.y) != WorldGrid.TILE_HULL_WALL
		for direction: Vector2i in DIRECTIONS:
			var neighbor: Vector2i = cell + direction
			if not world.is_valid_position(neighbor.x, neighbor.y):
				return _result(false, "Room leaks through an open tunnel to the world edge.", cells)
			if discovered.has(neighbor) or doors.has(neighbor) or world.is_solid(neighbor.x, neighbor.y):
				continue
			if discovered.size() >= MAX_ROOM_CELLS:
				return _result(false, "Room exceeds 512 interior cells or leaks into an open tunnel.", cells)
			discovered[neighbor] = true
			queue.append(neighbor)
	if cells.size() < MIN_ROOM_CELLS:
		return _result(false, "Room needs at least 12 interior cells.", cells)
	if has_hazard:
		return _result(false, "Remove hazards from the room interior.", cells)
	if missing_background:
		return _result(false, "Cover every interior cell with a Hull Wall background.", cells)
	var has_door: bool = false
	var has_heater: bool = false
	var has_light: bool = false
	for descriptor: Dictionary in structures:
		var cell_value: Variant = descriptor.get("cell")
		if not cell_value is Vector2i:
			continue
		var structure_cell: Vector2i = cell_value
		var tags: Array = descriptor.get("tags", [])
		if tags.has("door") and _is_boundary_door(world, structure_cell, discovered, doors):
			has_door = true
		if discovered.has(structure_cell):
			has_heater = has_heater or tags.has("heater")
			has_light = has_light or tags.has("light")
	if not has_door:
		return _result(false, "Room needs a Blast Door in its boundary.", cells)
	if not has_heater:
		return _result(false, "Room needs a Camp Heater inside.", cells)
	if not has_light:
		return _result(false, "Room needs a Wall Flare or other housing light inside.", cells)
	var result: Dictionary = _result(true, "Habitable: sealed hull, door, warmth and light.", cells)
	var floor_cells: Array[Vector2i] = []
	var spawn_cell: Vector2i = start
	var best_distance: float = INF
	var center: Vector2 = result["center"]
	for cell: Vector2i in cells:
		if not world.is_solid(cell.x, cell.y + 1) or world.is_hazard(cell.x, cell.y + 1):
			continue
		floor_cells.append(cell)
		var distance: float = _cell_center(cell).distance_squared_to(center)
		if distance < best_distance:
			best_distance = distance
			spawn_cell = cell
	if floor_cells.is_empty():
		return _result(false, "Room needs a solid safe floor for a colonist.", cells)
	result["spawn_cell"] = spawn_cell
	result["floor_cells"] = floor_cells
	return result

func _is_boundary_door(world: WorldGrid, cell: Vector2i, interior: Dictionary, doors: Dictionary) -> bool:
	var left: Vector2i = cell + Vector2i.LEFT
	var right: Vector2i = cell + Vector2i.RIGHT
	var above: Vector2i = cell + Vector2i.UP
	var below: Vector2i = cell + Vector2i.DOWN
	var vertical_frame: bool = (world.is_solid(above.x, above.y) or doors.has(above)) and (world.is_solid(below.x, below.y) or doors.has(below))
	var horizontal_frame: bool = (world.is_solid(left.x, left.y) or doors.has(left)) and (world.is_solid(right.x, right.y) or doors.has(right))
	return (vertical_frame and (interior.has(left) != interior.has(right))) or (horizontal_frame and (interior.has(above) != interior.has(below)))

func _result(valid: bool, reason: String, cells: Array[Vector2i]) -> Dictionary:
	var sorted_cells: Array[Vector2i] = cells.duplicate()
	sorted_cells.sort_custom(_cell_before)
	var bounds := Rect2i()
	var cell_codes: PackedInt32Array = []
	if not sorted_cells.is_empty():
		var minimum: Vector2i = sorted_cells[0]
		var maximum: Vector2i = minimum
		for cell: Vector2i in sorted_cells:
			minimum = Vector2i(mini(minimum.x, cell.x), mini(minimum.y, cell.y))
			maximum = Vector2i(maxi(maximum.x, cell.x), maxi(maximum.y, cell.y))
			cell_codes.append(cell.y * WorldGrid.GRID_SIZE + cell.x)
		bounds = Rect2i(minimum, maximum - minimum + Vector2i.ONE)
	var center: Vector2 = (Vector2(bounds.position) + Vector2(bounds.size) * 0.5) * WorldGrid.TILE_SIZE
	return {"valid": valid, "reason": reason, "cells": sorted_cells, "bounds": bounds, "center": center, "room_id": str(hash(cell_codes)) if valid else ""}

func _cell_before(a: Vector2i, b: Vector2i) -> bool:
	return a.y < b.y or (a.y == b.y and a.x < b.x)

func _cell_center(cell: Vector2i) -> Vector2:
	return (Vector2(cell) + Vector2.ONE * 0.5) * WorldGrid.TILE_SIZE
