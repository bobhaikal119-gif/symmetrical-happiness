extends RefCounted

class_name WorldGenerator

## Seeded value-only generation. Terrain algorithms preserve the original strata,
## caves, ore tiers and exposed starter seam. Liquids have a single authority:
## magma is seeded into LiquidGrid, never duplicated as solid/hazard terrain.
var seed: int = 12345

const CAVE_THRESHOLD: float = 0.48
const ORE_THRESHOLD: float = 0.58
const HAZARD_THRESHOLD: float = 0.66
const SURFACE_BASE_Y: int = 24
const AQUIFER_MIN_DEPTH: int = 72
const AQUIFER_COUNT: int = 14

var _surface_noise: FastNoiseLite
var _cave_noise: FastNoiseLite
var _ore_noise: FastNoiseLite
var _hazard_noise: FastNoiseLite


func generate(world: WorldGrid, liquids: LiquidGrid = null) -> void:
	if world == null:
		return
	_configure_noise()
	if liquids != null:
		liquids.clear()
	world.seed = seed
	world.initialize_grid()
	world.generate_strata()
	_shape_surface(world)
	_carve_caves(world)
	_place_ore_veins(world)
	_place_hazards(world, liquids)
	_place_aquifers(world, liquids)
	_place_landing_outcrop(world)


func _place_landing_outcrop(world: WorldGrid) -> void:
	# Preserve the exposed seam, rather than minting a free starter inventory.
	var center_x: int = WorldGrid.GRID_SIZE / 2
	var surface_y: int = SURFACE_BASE_Y
	for y: int in range(8, 40):
		if world.is_solid(center_x, y):
			surface_y = y
			break
	var resources: Array[int] = [WorldGrid.TILE_STONE, WorldGrid.TILE_IRON_ORE, WorldGrid.TILE_COAL, WorldGrid.TILE_COPPER, WorldGrid.TILE_QUARTZ]
	for index: int in range(resources.size()):
		for x_offset: int in range(4):
			for y_offset: int in range(3):
				world.set_tile(center_x - 10 + index * 4 + x_offset, surface_y + 1 + y_offset, resources[index])


func _configure_noise() -> void:
	_surface_noise = FastNoiseLite.new()
	_surface_noise.seed = seed
	_surface_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_surface_noise.frequency = 0.018
	_cave_noise = FastNoiseLite.new()
	_cave_noise.seed = seed + 101
	_cave_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_cave_noise.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	_cave_noise.fractal_octaves = 3
	_cave_noise.frequency = 0.026
	_ore_noise = FastNoiseLite.new()
	_ore_noise.seed = seed + 307
	_ore_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_ore_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_ore_noise.fractal_octaves = 3
	_ore_noise.frequency = 0.075
	_hazard_noise = FastNoiseLite.new()
	_hazard_noise.seed = seed + 701
	_hazard_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_hazard_noise.frequency = 0.045


func _shape_surface(world: WorldGrid) -> void:
	for x: int in range(WorldGrid.GRID_SIZE):
		var height_offset: int = roundi(_surface_noise.get_noise_1d(float(x)) * 6.0)
		var surface_y: int = clampi(SURFACE_BASE_Y + height_offset, 12, 38)
		for y: int in range(surface_y):
			world.set_tile(x, y, WorldGrid.TILE_AIR)
		world.set_tile(x, surface_y, WorldGrid.TILE_SNOW)


func _carve_caves(world: WorldGrid) -> void:
	for y: int in range(SURFACE_BASE_Y + 12, WorldGrid.GRID_SIZE):
		for x: int in range(WorldGrid.GRID_SIZE):
			var value: float = _cave_noise.get_noise_2d(float(x), float(y))
			if value > CAVE_THRESHOLD:
				var tile_id: int = world.get_tile(x, y)
				if tile_id != WorldGrid.TILE_LAVA and tile_id != WorldGrid.TILE_ACID:
					world.set_tile(x, y, WorldGrid.TILE_AIR)


func _place_ore_veins(world: WorldGrid) -> void:
	for y: int in range(64, WorldGrid.GRID_SIZE):
		for x: int in range(WorldGrid.GRID_SIZE):
			var current: int = world.get_tile(x, y)
			if current != WorldGrid.TILE_STONE and current != WorldGrid.TILE_DIRT and current != WorldGrid.TILE_BASALT:
				continue
			var value: float = _ore_noise.get_noise_2d(float(x), float(y))
			if value <= ORE_THRESHOLD:
				continue
			var ore_id: int = _ore_for_depth(y, value)
			if ore_id != WorldGrid.TILE_AIR:
				world.set_tile(x, y, ore_id)


func _ore_for_depth(depth: int, noise_value: float) -> int:
	if depth < 96:
		return WorldGrid.TILE_COAL
	if depth < 128:
		return WorldGrid.TILE_COPPER
	if depth < 160:
		return WorldGrid.TILE_QUARTZ
	if depth < 224:
		return WorldGrid.TILE_TITANIUM if noise_value > 0.64 else WorldGrid.TILE_IRON_ORE
	return WorldGrid.TILE_BIOLUME_STONE


func _place_hazards(world: WorldGrid, liquids: LiquidGrid) -> void:
	for y: int in range(192, WorldGrid.GRID_SIZE):
		for x: int in range(WorldGrid.GRID_SIZE):
			if world.get_tile(x, y) != WorldGrid.TILE_AIR:
				continue
			var value: float = _hazard_noise.get_noise_2d(float(x), float(y))
			if value <= HAZARD_THRESHOLD:
				continue
			if y < 320:
				world.set_tile(x, y, WorldGrid.TILE_ACID)
			elif liquids != null:
				liquids.set_cell(x, y, LiquidGrid.LAVA, 1.0)


func _place_aquifers(world: WorldGrid, liquids: LiquidGrid) -> void:
	if liquids == null:
		return
	var random := RandomNumberGenerator.new()
	random.seed = seed + 1709
	# A bounded number of deterministic flood chambers. Each has a continuous
	# basalt shell, a dry crown and a partial-fill waterline; mining the shell
	# releases real conserved water into the surrounding natural cave network.
	for index: int in range(AQUIFER_COUNT):
		var radius_x: int = random.randi_range(7, 13)
		var radius_y: int = random.randi_range(5, 8)
		var center_x: int = 22 + index * 35 + random.randi_range(-5, 5)
		var center_y: int = random.randi_range(AQUIFER_MIN_DEPTH + radius_y, 300 - radius_y)
		_carve_flood_chamber(world, liquids, Vector2i(center_x, center_y), radius_x, radius_y)
	# Guarantee magma remains a LiquidGrid feature even for a seed whose sparse
	# hazard noise happens to miss the existing deep natural caves.
	for index: int in range(3):
		var center := Vector2i(90 + index * 156 + random.randi_range(-12, 12), random.randi_range(365, 465))
		_carve_flood_chamber(world, liquids, center, 10, 6, LiquidGrid.LAVA)


func _carve_flood_chamber(world: WorldGrid, liquids: LiquidGrid, center: Vector2i, radius_x: int, radius_y: int, liquid_id: int = LiquidGrid.WATER) -> void:
	var interior: Array[Vector2i] = []
	var shell: Dictionary = {}
	for y: int in range(center.y - radius_y, center.y + radius_y + 1):
		for x: int in range(center.x - radius_x, center.x + radius_x + 1):
			var normalized := Vector2(float(x - center.x) / radius_x, float(y - center.y) / radius_y)
			if normalized.length_squared() <= 1.0:
				interior.append(Vector2i(x, y))
	var inside: Dictionary = {}
	for cell: Vector2i in interior:
		inside[cell] = true
		for direction: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
			shell[cell + direction] = true
	for cell: Vector2i in shell:
		if not inside.has(cell):
			world.set_tile(cell.x, cell.y, WorldGrid.TILE_BASALT)
	var waterline: float = float(center.y - 1) + 0.45
	for cell: Vector2i in interior:
		world.set_tile(cell.x, cell.y, WorldGrid.TILE_AIR)
		var fill: float = clampf(float(cell.y + 1) - waterline, 0.0, 1.0)
		if fill > 0.0:
			liquids.set_cell(cell.x, cell.y, liquid_id, fill)
