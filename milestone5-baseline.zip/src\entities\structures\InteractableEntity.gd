@abstract
extends CharacterBody2D

class_name InteractableEntity

## Narrow, typed interaction protocol. CharacterBody2D permits moving colonists;
## stationary implementations simply never call move_and_slide.
@export var interaction_radius: float = 48.0
@export var grid_pos: Vector2i = Vector2i.ZERO
@export var item_id: String = ""
@export var housing_tags: Array[String] = []

func _ready() -> void:
	add_to_group("interactables")

func can_interact(actor: Node) -> bool:
	if not actor is Node2D or not is_inside_tree() or not actor.is_inside_tree():
		return false
	return global_position.distance_to((actor as Node2D).global_position) <= interaction_radius

@abstract
func interact(actor: Node) -> void

@abstract
func get_prompt_text() -> String

func get_housing_descriptor() -> Dictionary:
	return {"cell": grid_pos, "tags": housing_tags.duplicate(), "item_id": item_id}
