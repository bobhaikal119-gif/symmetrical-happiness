extends RefCounted

class_name BlockTextures

## Shared, imported pixel art for the world atlas, construction icons and ghosts.
## ID 18 is presentation-only: exposed dirt still mines/collides as dirt.
const TILE_SIZE: int = 16
const GRASS_VISUAL_ID: int = 18
const VISUAL_TILE_COUNT: int = 19
const TEXTURES: Dictionary = {
	1: preload("res://assets/textures/blocks/snow.png"),
	2: preload("res://assets/textures/blocks/dirt.png"),
	3: preload("res://assets/textures/blocks/stone.png"),
	4: preload("res://assets/textures/blocks/iron_ore.png"),
	5: preload("res://assets/textures/blocks/coal_ore.png"),
	6: preload("res://assets/textures/blocks/copper_ore.png"),
	7: preload("res://assets/textures/blocks/quartz.png"),
	8: preload("res://assets/textures/blocks/titanium.png"),
	9: preload("res://assets/textures/blocks/biolume_stone.png"),
	10: preload("res://assets/textures/blocks/basalt.png"),
	11: preload("res://assets/textures/blocks/lava.png"),
	12: preload("res://assets/textures/blocks/acid.png"),
	13: preload("res://assets/textures/blocks/support_beam.png"),
	14: preload("res://assets/textures/blocks/power_cable.png"),
	15: preload("res://assets/textures/blocks/hull_wall.png"),
	16: preload("res://assets/textures/blocks/steel_plate.png"),
	17: preload("res://assets/textures/blocks/reinforced_glass.png"),
	GRASS_VISUAL_ID: preload("res://assets/textures/blocks/grass.png"),
}


static func get_tile_texture(tile_id: int) -> Texture2D:
	return TEXTURES.get(tile_id) as Texture2D


static func get_tile_image(tile_id: int) -> Image:
	var texture: Texture2D = get_tile_texture(tile_id)
	if texture == null:
		return null
	# Convert a CPU copy, never mutate an imported/shared texture resource.
	var image: Image = texture.get_image()
	if image.is_compressed():
		image.decompress()
	image.convert(Image.FORMAT_RGBA8)
	return image
