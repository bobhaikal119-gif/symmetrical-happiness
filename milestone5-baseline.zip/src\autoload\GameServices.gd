extends Node

"""
GameServices: Lightweight autoload bootstrapper for DEEPWELL.
Ensures core singletons (SignalBus, GlobalGameState, registries) live in the
SceneTree without class_name/autoload shadowing conflicts, and registers
custom InputMap actions.
"""

func _enter_tree() -> void:
	_register_input_actions()
	_attach_singleton(SignalBus.get_instance(), "SignalBusNode")
	_attach_singleton(GlobalGameState.get_instance(), "GlobalGameStateNode")
	_attach_singleton(TileRegistry.get_instance(), "TileRegistryNode")
	_attach_singleton(ItemRegistry.get_instance(), "ItemRegistryNode")
	_attach_singleton(RecipeRegistry.get_instance(), "RecipeRegistryNode")
	_attach_singleton(ProceduralItemIcons.get_instance(), "ProceduralItemIconsNode")

func _attach_singleton(node: Node, node_name: String) -> void:
	if node == null:
		return
	if node.get_parent() == null:
		node.name = node_name
		get_tree().root.call_deferred("add_child", node)

func _register_input_actions() -> void:
	_ensure_key_action("move_left", [KEY_A, KEY_LEFT])
	_ensure_key_action("move_right", [KEY_D, KEY_RIGHT])
	_ensure_key_action("move_up", [KEY_W, KEY_UP])
	_ensure_key_action("move_down", [KEY_S, KEY_DOWN])
	_ensure_key_action("ui_jump", [KEY_SPACE, KEY_W, KEY_UP])
	_ensure_key_action("place_heater", [KEY_E])
	_ensure_key_action("interact", [KEY_F])
	_ensure_key_action("craft", [KEY_C, KEY_TAB])
	_ensure_key_action("flashlight_toggle", [KEY_L])
	_ensure_key_action("mine", [KEY_Q])
	_ensure_mouse_action("mine", MOUSE_BUTTON_LEFT)
	_ensure_key_action("hotbar_1", [KEY_1])
	_ensure_key_action("hotbar_2", [KEY_2])
	_ensure_key_action("hotbar_3", [KEY_3])
	_ensure_key_action("hotbar_4", [KEY_4])
	_ensure_key_action("hotbar_5", [KEY_5])
	_ensure_key_action("hotbar_6", [KEY_6])
	_ensure_key_action("hotbar_7", [KEY_7])
	_ensure_key_action("hotbar_8", [KEY_8])
	_ensure_key_action("hotbar_9", [KEY_9])

func _ensure_key_action(action_name: String, keys: Array[Key]) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	for key_code in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = key_code
		ev.keycode = key_code
		if not InputMap.action_has_event(action_name, ev):
			InputMap.action_add_event(action_name, ev)

func _ensure_mouse_action(action_name: String, button: MouseButton) -> void:
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	var ev := InputEventMouseButton.new()
	ev.button_index = button
	if not InputMap.action_has_event(action_name, ev):
		InputMap.action_add_event(action_name, ev)
