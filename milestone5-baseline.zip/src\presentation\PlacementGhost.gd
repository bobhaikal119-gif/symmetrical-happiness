extends Node2D

class_name PlacementGhost

## One read-only preview of the exact metadata/target consumed by placement.
const VALID_COLOR := Color(0.40, 1.0, 0.72, 0.62)
const INVALID_COLOR := Color(1.0, 0.28, 0.32, 0.62)

var placement: PlacementComponent
var cursor_reticle: CursorReticle
var target_cell: Vector2i = Vector2i(-1, -1)
var is_valid: bool = false
var _preview: Sprite2D
var _preview_item: String = ""
var _definition: ItemDef


func configure(component: PlacementComponent, cursor: CursorReticle = null) -> void:
	placement = component
	cursor_reticle = cursor


func _ready() -> void:
	process_priority = 10
	z_index = 40
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var preview_material := CanvasItemMaterial.new()
	preview_material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	material = preview_material
	_preview = Sprite2D.new()
	_preview.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(_preview)
	visible = false


func _process(_delta: float) -> void:
	if placement == null or placement.world_grid == null or SettingsManager.is_gameplay_input_blocked() or Input.is_action_pressed("mine_primary"):
		visible = false
		return
	if _preview_item != placement.active_item or _definition == null:
		_preview_item = placement.active_item
		_definition = ItemRegistry.get_instance().get_item_def(_preview_item)
		_preview.texture = ProceduralItemIcons.get_instance().get_item_icon_texture(_preview_item) if _definition != null else null
	visible = _definition != null and _definition.place_layer != "consumable"
	if not visible:
		return
	target_cell = placement.get_target_cell()
	global_position = Vector2(target_cell * WorldGrid.TILE_SIZE) + Vector2.ONE * (WorldGrid.TILE_SIZE * 0.5)
	is_valid = placement.can_place_item(_preview_item, target_cell)
	_preview.modulate = VALID_COLOR if is_valid else INVALID_COLOR
	queue_redraw()


func _draw() -> void:
	if not visible:
		return
	var color: Color = VALID_COLOR if is_valid else INVALID_COLOR
	color.a = 0.95
	draw_rect(Rect2(Vector2(-7.5, -7.5), Vector2(15.0, 15.0)), color, false, 1.0)
	# A dashed inset marks the non-colliding background layer explicitly.
	if _definition != null and _definition.place_layer == "background_wall":
		for offset: int in [-5, -1, 3]:
			draw_line(Vector2(float(offset), -5.5), Vector2(float(offset + 2), -5.5), color, 1.0)
			draw_line(Vector2(float(offset), 5.5), Vector2(float(offset + 2), 5.5), color, 1.0)
	if not is_valid:
		draw_line(Vector2(-3.0, -3.0), Vector2(3.0, 3.0), color, 1.0)
		draw_line(Vector2(3.0, -3.0), Vector2(-3.0, 3.0), color, 1.0)
