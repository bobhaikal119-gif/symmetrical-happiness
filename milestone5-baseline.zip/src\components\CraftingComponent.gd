extends Node
class_name CraftingComponent

## Inventory and crafting authority. Transactions commit once, then publish values.
signal inventory_changed(item_id: String, count: int)

const MAX_ITEM_COUNT: int = 1000000
const STATION_REFRESH_SECONDS: float = 0.25
var signal_bus: SignalBus
var recipe_registry: RecipeRegistry
var item_registry: ItemRegistry
var inventory: Dictionary = {}
var last_craft_error: String = ""
var _nearby_stations: Array[String] = ["hand"]
var _station_elapsed: float = 0.0
var _transaction_active: bool = false

func _ready() -> void:
	_ensure_registries()
	if signal_bus == null:
		signal_bus = SignalBus.get_instance()
	signal_bus.craft_requested.connect(_on_craft_requested)
	signal_bus.inventory_snapshot_requested.connect(publish_inventory_snapshot)
	signal_bus.crafting_menu_toggled.connect(_on_crafting_menu_toggled)
	signal_bus.building_item_selected.connect(_on_building_item_selected)
	publish_inventory_snapshot()

func _process(delta: float) -> void:
	_station_elapsed += delta
	if _station_elapsed >= STATION_REFRESH_SECONDS:
		_station_elapsed = 0.0
		refresh_nearby_stations()

func _on_craft_requested(recipe_id: String) -> void:
	var success: bool = craft(recipe_id)
	if signal_bus != null:
		signal_bus.craft_completed.emit(recipe_id, success)
		if not success:
			signal_bus.show_hud_hint.emit(last_craft_error)

func craft(recipe_id: String) -> bool:
	_ensure_registries()
	last_craft_error = "Unknown crafting recipe."
	var recipe: RecipeDef = recipe_registry.get_recipe(recipe_id)
	if recipe == null:
		return false
	# Recompute here: a displayed station badge is never authorization to craft.
	refresh_nearby_stations()
	if not _scan_nearby_stations().has(recipe.station_required):
		last_craft_error = "Move within range of a %s station." % recipe.station_required.capitalize()
		return false
	if recipe.output_count < 1 or recipe.ingredients.is_empty():
		last_craft_error = "Recipe data is invalid."
		return false
	var additions: Dictionary = {recipe.output_item_id: recipe.output_count}
	if not apply_inventory_transaction(recipe.ingredients, additions):
		last_craft_error = "Missing ingredients or inventory capacity."
		return false
	last_craft_error = ""
	return true

func add_item(item_id: String, count: int = 1) -> bool:
	return apply_inventory_transaction({}, {item_id: count})

func remove_item(item_id: String, count: int = 1) -> bool:
	return apply_inventory_transaction({item_id: count}, {})

func can_apply_inventory_transaction(removals: Dictionary, additions: Dictionary) -> bool:
	return not _transaction_active and bool(_prepare_transaction(removals, additions).get("ok", false))

func apply_inventory_transaction(removals: Dictionary, additions: Dictionary) -> bool:
	if _transaction_active:
		return false
	var transaction: Dictionary = _prepare_transaction(removals, additions)
	if not bool(transaction.get("ok", false)):
		return false
	_transaction_active = true
	var previous: Dictionary = inventory
	inventory = transaction["inventory"]
	var changed: Dictionary = {}
	for key: Variant in removals:
		changed[str(key)] = true
	for key: Variant in additions:
		changed[str(key)] = true
	# Commit the entire value set before any observer can run.
	for item_id: String in changed:
		if int(previous.get(item_id, 0)) != get_inventory_count(item_id):
			inventory_changed.emit(item_id, get_inventory_count(item_id))
	_emit_inventory_snapshot()
	_transaction_active = false
	return true

func _prepare_transaction(removals: Dictionary, additions: Dictionary) -> Dictionary:
	_ensure_registries()
	if removals.is_empty() and additions.is_empty():
		return {"ok": false}
	var next: Dictionary = inventory.duplicate(true)
	for item_variant: Variant in removals:
		var item_id: String = str(item_variant)
		var count_value: Variant = removals[item_variant]
		if not _valid_quantity(item_id, count_value):
			return {"ok": false}
		var remaining: int = int(next.get(item_id, 0)) - int(count_value)
		if remaining < 0:
			return {"ok": false}
		if remaining == 0:
			next.erase(item_id)
		else:
			next[item_id] = remaining
	for item_variant: Variant in additions:
		var item_id: String = str(item_variant)
		var count_value: Variant = additions[item_variant]
		if not _valid_quantity(item_id, count_value):
			return {"ok": false}
		var total: int = int(next.get(item_id, 0)) + int(count_value)
		if total < 1 or total > MAX_ITEM_COUNT:
			return {"ok": false}
		next[item_id] = total
	return {"ok": true, "inventory": next}

func _valid_quantity(item_id: String, quantity: Variant) -> bool:
	return typeof(quantity) == TYPE_INT and int(quantity) > 0 and int(quantity) <= MAX_ITEM_COUNT and item_registry.validate_item_id(item_id)

func has_items(ingredients: Dictionary) -> bool:
	_ensure_registries()
	for item_variant: Variant in ingredients:
		var item_id: String = str(item_variant)
		var required: Variant = ingredients[item_variant]
		if not _valid_quantity(item_id, required) or get_inventory_count(item_id) < int(required):
			return false
	return true

func get_inventory_count(item_id: String) -> int:
	return int(inventory.get(item_id, 0))

func get_inventory() -> Dictionary:
	return inventory.duplicate(true)

func get_all_items() -> Dictionary:
	return get_inventory()

func get_nearby_stations() -> Array[String]:
	return _scan_nearby_stations()

func refresh_nearby_stations() -> void:
	var next: Array[String] = _scan_nearby_stations()
	if next != _nearby_stations:
		_nearby_stations = next
		if signal_bus != null:
			signal_bus.nearby_stations_changed.emit(_nearby_stations.duplicate())

func _scan_nearby_stations() -> Array[String]:
	var next: Array[String] = ["hand"]
	var actor: Node2D = get_parent() as Node2D
	if is_inside_tree() and actor != null:
		for candidate: Node in get_tree().get_nodes_in_group("crafting_stations"):
			var station: CraftingStation = candidate as CraftingStation
			if station == null or station.is_queued_for_deletion() or station.station_kind.is_empty():
				continue
			if actor.global_position.distance_to(station.global_position) <= station.station_radius and not next.has(station.station_kind):
				next.append(station.station_kind)
	return next

func publish_inventory_snapshot() -> void:
	refresh_nearby_stations()
	_emit_inventory_snapshot()
	if signal_bus != null:
		signal_bus.nearby_stations_changed.emit(_nearby_stations.duplicate())

func _emit_inventory_snapshot() -> void:
	if signal_bus != null:
		signal_bus.inventory_updated.emit(get_inventory())

func _on_crafting_menu_toggled(is_open: bool) -> void:
	if is_open:
		publish_inventory_snapshot()

func _on_building_item_selected(_item_id: String) -> void:
	publish_inventory_snapshot()

func _ensure_registries() -> void:
	if recipe_registry == null:
		recipe_registry = RecipeRegistry.get_instance()
	if item_registry == null:
		item_registry = ItemRegistry.get_instance()
