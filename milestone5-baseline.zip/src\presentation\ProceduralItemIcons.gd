extends Node

class_name ProceduralItemIcons

## Caches 16x16 icons: placed blocks share their imported world texture;
## loose resources and equipment retain their bespoke generated silhouettes.

const ICON_SIZE: int = 16

static var _instance: ProceduralItemIcons = null

var _cache: Dictionary = {}


static func get_instance() -> ProceduralItemIcons:
	if not is_instance_valid(_instance):
		_instance = ProceduralItemIcons.new()
	return _instance


func get_icon(item_id: String) -> Texture2D:
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if definition != null and definition.tile_id > 0:
		var block_texture: Texture2D = BlockTextures.get_tile_texture(definition.tile_id)
		if block_texture != null:
			return block_texture
	if ProceduralEntitySprites.has_sprite(item_id):
		return ProceduralEntitySprites.get_texture(item_id)
	var image := Image.create(ICON_SIZE, ICON_SIZE, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	match item_id:
		"diving_rebreather":
			_draw_diving_rebreather(image)
		"thermal_wetsuit":
			_draw_thermal_wetsuit(image)
		"stone":
			_draw_stone_icon(image)
		"coal":
			_draw_coal_icon(image)
		"copper_ore":
			_draw_copper_ore_icon(image)
		"iron_ore":
			_draw_iron_ore_icon(image)
		"quartz":
			_draw_quartz_icon(image)
		"titanium":
			_draw_titanium_icon(image)
		"biolume_stone":
			_draw_biolume_stone_icon(image)
		"support_beam":
			_draw_support_beam_icon(image)
		"oxygen_canister":
			_draw_oxygen_canister_icon(image)
		"camp_heater":
			_draw_camp_heater_icon(image)
		"wall_flare":
			_draw_wall_flare_icon(image)
		"power_cable":
			_draw_power_cable_icon(image)
		"coal_generator":
			_draw_coal_generator_icon(image)
		"auto_drill":
			_draw_auto_drill_icon(image)
		"auto_turret":
			_draw_auto_turret_icon(image)
		"storage_crate":
			_draw_storage_crate_icon(image)
		_:
			_draw_fallback_icon(image)
	return ImageTexture.create_from_image(image)


func get_item_icon_texture(item_id: String) -> Texture2D:
	if _cache.has(item_id):
		return _cache.get(item_id) as Texture2D
	var texture := get_icon(item_id)
	_cache[item_id] = texture
	return texture


func clear_cache() -> void:
	_cache.clear()


func _set_pixel(image: Image, x: int, y: int, color: Color) -> void:
	if x >= 0 and x < ICON_SIZE and y >= 0 and y < ICON_SIZE:
		image.set_pixel(x, y, color)


func _fill_rect(image: Image, x: int, y: int, width: int, height: int, color: Color) -> void:
	for row in range(height):
		for column in range(width):
			_set_pixel(image, x + column, y + row, color)


func _draw_circle_outline(image: Image, center_x: float, center_y: float, radius: float, color: Color) -> void:
	for y in range(ICON_SIZE):
		for x in range(ICON_SIZE):
			var delta_x := float(x) - center_x
			var delta_y := float(y) - center_y
			var distance := sqrt(delta_x * delta_x + delta_y * delta_y)
			if distance >= radius - 0.55 and distance <= radius + 0.55:
				_set_pixel(image, x, y, color)


func _draw_diving_rebreather(image: Image) -> void:
	var rows: PackedStringArray = [
		"................", "....########....", "...#hhhhhhhh#...", "..#hmmmmmmmmh#..",
		"..#hm######mh#..", ".##hm#aaa#mhh##.", ".#shm#aha#mhms#.", ".#shm#####mhms#.",
		"..#hmmmmmmmhss#.", "..##hmmmmh##ss#.", ".#hh#aaaa#hh#s#.", ".#mm#aaaa#mm#s#.",
		"..##ssssss##ss#.", "...###########..", "................", "................",
	]
	_paint_gear_pattern(image, rows, [Color("32536b"), Color("5598ad"), Color("b7eef0"), Color("e9c476")])


func _draw_thermal_wetsuit(image: Image) -> void:
	var rows: PackedStringArray = [
		"................", ".....######.....", "....#hhhhhh#....", "...##mmmmmm##...",
		"..#hhmmmmmmss#..", ".#hmhmmammmsss#.", ".#hmhmmammmsss#.", ".#smhmmammmsss#.",
		"..#mhmmammmss#..", "...#hmmammmss#..", "...#hmmmmmmss#..", "...#mmm##msss#..",
		"...#hms##mmss#..", "...#hms##mmss#..", "...#sss##ssss#..", "....###..####...",
	]
	_paint_gear_pattern(image, rows, [Color("25473f"), Color("458d7e"), Color("a9e4c6"), Color("e9c476")])


func _paint_gear_pattern(image: Image, rows: PackedStringArray, palette: Array[Color]) -> void:
	var colors: Dictionary = {"#": Color("0e1018"), "s": palette[0], "m": palette[1], "h": palette[2], "a": palette[3]}
	for y: int in range(16):
		for x: int in range(16):
			var symbol: String = rows[y].substr(x, 1)
			if colors.has(symbol):
				image.set_pixel(x, y, colors[symbol])


func _draw_stone_icon(image: Image) -> void:
	_fill_rect(image, 2, 3, 12, 10, Color(0.31, 0.32, 0.34))
	_fill_rect(image, 3, 2, 8, 1, Color(0.52, 0.53, 0.55))
	_fill_rect(image, 1, 6, 1, 5, Color(0.22, 0.23, 0.25))
	_fill_rect(image, 4, 4, 6, 3, Color(0.43, 0.44, 0.46))
	_set_pixel(image, 5, 5, Color(0.62, 0.63, 0.65))
	_set_pixel(image, 11, 8, Color(0.19, 0.2, 0.22))
	_set_pixel(image, 7, 11, Color(0.24, 0.25, 0.27))


func _draw_coal_icon(image: Image) -> void:
	_fill_rect(image, 3, 3, 10, 10, Color(0.06, 0.065, 0.075))
	_fill_rect(image, 5, 2, 6, 1, Color(0.17, 0.18, 0.2))
	_fill_rect(image, 2, 6, 1, 5, Color(0.025, 0.03, 0.04))
	_fill_rect(image, 5, 4, 4, 2, Color(0.19, 0.2, 0.23))
	_set_pixel(image, 10, 6, Color(0.28, 0.29, 0.32))
	_set_pixel(image, 6, 9, Color(0.13, 0.14, 0.16))
	_set_pixel(image, 11, 11, Color(0.02, 0.02, 0.025))


func _draw_copper_ore_icon(image: Image) -> void:
	_draw_ore_icon(
		image,
		Color(0.34, 0.32, 0.31),
		Color(0.17, 0.16, 0.17),
		Color(0.91, 0.48, 0.18),
		Color(1.0, 0.72, 0.38)
	)


func _draw_iron_ore_icon(image: Image) -> void:
	_draw_ore_icon(
		image,
		Color(0.36, 0.34, 0.33),
		Color(0.18, 0.17, 0.18),
		Color(0.73, 0.47, 0.28),
		Color(0.95, 0.73, 0.5)
	)


func _draw_ore_icon(image: Image, base: Color, shadow: Color, ore: Color, highlight: Color) -> void:
	_fill_rect(image, 2, 3, 12, 10, base)
	_fill_rect(image, 4, 2, 7, 1, base.lightened(0.18))
	_fill_rect(image, 2, 9, 2, 3, shadow)
	_fill_rect(image, 10, 5, 3, 2, ore)
	_fill_rect(image, 5, 8, 3, 3, ore)
	_set_pixel(image, 11, 5, highlight)
	_set_pixel(image, 6, 8, highlight)
	_set_pixel(image, 4, 4, ore.darkened(0.15))


func _draw_quartz_icon(image: Image) -> void:
	_fill_rect(image, 7, 2, 3, 11, Color(0.68, 0.86, 0.94))
	_fill_rect(image, 4, 5, 3, 8, Color(0.5, 0.75, 0.87))
	_fill_rect(image, 10, 6, 2, 7, Color(0.82, 0.94, 1.0))
	_set_pixel(image, 8, 1, Color(0.95, 1.0, 1.0))
	_set_pixel(image, 5, 4, Color(0.84, 0.98, 1.0))
	_fill_rect(image, 4, 12, 8, 2, Color(0.35, 0.58, 0.72))
	_fill_rect(image, 8, 3, 1, 6, Color(1.0, 1.0, 1.0))


func _draw_titanium_icon(image: Image) -> void:
	_fill_rect(image, 2, 4, 12, 8, Color(0.35, 0.42, 0.52))
	_fill_rect(image, 4, 2, 8, 2, Color(0.62, 0.72, 0.83))
	_fill_rect(image, 4, 5, 7, 2, Color(0.76, 0.84, 0.91))
	_fill_rect(image, 3, 10, 10, 2, Color(0.23, 0.29, 0.38))
	_set_pixel(image, 5, 4, Color(0.94, 0.97, 1.0))
	_set_pixel(image, 11, 8, Color(0.18, 0.23, 0.31))


func _draw_biolume_stone_icon(image: Image) -> void:
	_fill_rect(image, 2, 3, 12, 10, Color(0.12, 0.25, 0.23))
	_fill_rect(image, 4, 2, 7, 2, Color(0.22, 0.48, 0.4))
	_fill_rect(image, 3, 10, 10, 3, Color(0.07, 0.16, 0.17))
	_fill_rect(image, 5, 5, 2, 5, Color(0.22, 0.86, 0.5))
	_fill_rect(image, 9, 4, 3, 3, Color(0.31, 1.0, 0.68))
	_set_pixel(image, 5, 5, Color(0.72, 1.0, 0.84))
	_set_pixel(image, 10, 4, Color(0.8, 1.0, 0.9))
	_set_pixel(image, 8, 10, Color(0.18, 0.62, 0.42))


func _draw_support_beam_icon(image: Image) -> void:
	var shadow := Color(0.25, 0.27, 0.34)
	var steel := Color(0.48, 0.52, 0.62)
	var highlight := Color(0.72, 0.76, 0.84)
	_fill_rect(image, 2, 1, 12, 2, steel)
	_fill_rect(image, 2, 13, 12, 2, shadow)
	_fill_rect(image, 7, 3, 3, 10, steel)
	_fill_rect(image, 7, 3, 1, 9, highlight)
	_set_pixel(image, 3, 1, highlight)
	_set_pixel(image, 12, 14, Color(0.12, 0.13, 0.17))


func _draw_oxygen_canister_icon(image: Image) -> void:
	_fill_rect(image, 5, 3, 7, 10, Color(0.1, 0.42, 0.76))
	_fill_rect(image, 6, 2, 5, 2, Color(0.35, 0.72, 1.0))
	_fill_rect(image, 6, 4, 2, 8, Color(0.3, 0.68, 1.0))
	_fill_rect(image, 5, 12, 7, 2, Color(0.05, 0.24, 0.48))
	_draw_circle_outline(image, 9.0, 7.0, 2.0, Color(0.83, 0.9, 0.96))
	_set_pixel(image, 9, 7, Color(0.9, 0.2, 0.2))
	_set_pixel(image, 10, 6, Color(0.9, 0.2, 0.2))


func _draw_camp_heater_icon(image: Image) -> void:
	_fill_rect(image, 3, 4, 10, 9, Color(0.28, 0.17, 0.14))
	_fill_rect(image, 4, 3, 8, 2, Color(0.55, 0.31, 0.2))
	_fill_rect(image, 5, 6, 6, 5, Color(0.76, 0.28, 0.09))
	_fill_rect(image, 6, 7, 4, 3, Color(1.0, 0.55, 0.1))
	_set_pixel(image, 7, 7, Color(1.0, 0.93, 0.38))
	_fill_rect(image, 4, 13, 2, 2, Color(0.16, 0.12, 0.12))
	_fill_rect(image, 10, 13, 2, 2, Color(0.16, 0.12, 0.12))


func _draw_wall_flare_icon(image: Image) -> void:
	_fill_rect(image, 6, 6, 4, 9, Color(0.78, 0.48, 0.08))
	_fill_rect(image, 7, 6, 2, 8, Color(1.0, 0.82, 0.2))
	_fill_rect(image, 5, 5, 6, 2, Color(0.45, 0.29, 0.1))
	_set_pixel(image, 6, 4, Color(1.0, 0.33, 0.03))
	_set_pixel(image, 7, 3, Color(1.0, 0.58, 0.05))
	_set_pixel(image, 8, 2, Color(1.0, 0.85, 0.22))
	_set_pixel(image, 9, 3, Color(1.0, 0.48, 0.03))
	_set_pixel(image, 9, 4, Color(0.85, 0.18, 0.02))


func _draw_power_cable_icon(image: Image) -> void:
	## Coiled copper cable with a highlighted insulated edge and plug.
	var cable_shadow := Color(0.35, 0.19, 0.05)
	var cable := Color(0.86, 0.47, 0.09)
	var cable_light := Color(1.0, 0.75, 0.22)
	_draw_circle_outline(image, 7.5, 7.5, 5.0, cable_shadow)
	_draw_circle_outline(image, 7.5, 7.5, 4.0, cable)
	_fill_rect(image, 2, 6, 2, 4, cable_light)
	_fill_rect(image, 11, 10, 4, 2, cable)
	_fill_rect(image, 13, 9, 2, 4, cable_shadow)
	_set_pixel(image, 14, 9, cable_light)
	_set_pixel(image, 15, 10, Color(0.75, 0.8, 0.86))
	_set_pixel(image, 15, 12, Color(0.75, 0.8, 0.86))


func _draw_coal_generator_icon(image: Image) -> void:
	## Heavy generator housing, coal firebox, vents, and an electrical indicator.
	_fill_rect(image, 2, 3, 12, 11, Color(0.12, 0.14, 0.17))
	_fill_rect(image, 3, 2, 10, 2, Color(0.35, 0.38, 0.42))
	_fill_rect(image, 3, 4, 2, 8, Color(0.43, 0.46, 0.5))
	_fill_rect(image, 6, 8, 6, 4, Color(0.25, 0.08, 0.035))
	_fill_rect(image, 7, 9, 4, 2, Color(0.94, 0.31, 0.04))
	_set_pixel(image, 8, 9, Color(1.0, 0.82, 0.2))
	_fill_rect(image, 7, 5, 5, 1, Color(0.5, 0.54, 0.58))
	_fill_rect(image, 7, 7, 5, 1, Color(0.05, 0.06, 0.08))
	_fill_rect(image, 3, 14, 3, 1, Color(0.05, 0.06, 0.08))
	_fill_rect(image, 10, 14, 3, 1, Color(0.05, 0.06, 0.08))


func _draw_auto_drill_icon(image: Image) -> void:
	## Yellow powered drill head with cool display and a shaded titanium bit.
	_fill_rect(image, 3, 2, 10, 7, Color(0.31, 0.24, 0.09))
	_fill_rect(image, 4, 3, 8, 5, Color(0.82, 0.58, 0.12))
	_fill_rect(image, 5, 3, 5, 1, Color(1.0, 0.82, 0.28))
	_fill_rect(image, 6, 5, 4, 2, Color(0.1, 0.58, 0.72))
	_set_pixel(image, 7, 5, Color(0.62, 0.95, 1.0))
	_fill_rect(image, 6, 9, 4, 2, Color(0.45, 0.5, 0.56))
	_fill_rect(image, 7, 11, 2, 2, Color(0.7, 0.76, 0.82))
	_set_pixel(image, 7, 13, Color(0.55, 0.61, 0.69))
	_set_pixel(image, 8, 13, Color(0.31, 0.36, 0.43))
	_set_pixel(image, 8, 14, Color(0.16, 0.19, 0.24))


func _draw_auto_turret_icon(image: Image) -> void:
	## Red armored turret with a long highlighted barrel and rotating base.
	_fill_rect(image, 5, 5, 7, 5, Color(0.34, 0.08, 0.08))
	_fill_rect(image, 6, 4, 5, 5, Color(0.7, 0.2, 0.17))
	_fill_rect(image, 7, 4, 3, 1, Color(0.96, 0.45, 0.34))
	_fill_rect(image, 10, 5, 5, 2, Color(0.24, 0.27, 0.31))
	_fill_rect(image, 12, 5, 3, 1, Color(0.65, 0.7, 0.74))
	_set_pixel(image, 7, 6, Color(0.3, 0.94, 1.0))
	_fill_rect(image, 7, 9, 3, 3, Color(0.26, 0.29, 0.34))
	_fill_rect(image, 4, 12, 9, 2, Color(0.14, 0.16, 0.2))
	_fill_rect(image, 5, 11, 7, 1, Color(0.5, 0.54, 0.59))


func _draw_storage_crate_icon(image: Image) -> void:
	## Teal reinforced crate with shaded panels, cross braces, and a bright latch.
	_fill_rect(image, 2, 3, 12, 11, Color(0.08, 0.22, 0.23))
	_fill_rect(image, 3, 4, 10, 8, Color(0.19, 0.43, 0.44))
	_fill_rect(image, 3, 4, 10, 2, Color(0.35, 0.64, 0.63))
	_fill_rect(image, 2, 3, 2, 11, Color(0.12, 0.29, 0.31))
	_fill_rect(image, 12, 3, 2, 11, Color(0.05, 0.15, 0.17))
	for offset in range(7):
		var brace_y := 6 + floori(float(offset) * 0.5)
		_set_pixel(image, 4 + offset, brace_y, Color(0.09, 0.28, 0.29))
		_set_pixel(image, 10 - offset, brace_y, Color(0.09, 0.28, 0.29))
	_fill_rect(image, 7, 7, 3, 3, Color(0.68, 0.76, 0.5))
	_set_pixel(image, 8, 7, Color(0.94, 1.0, 0.72))


func _draw_fallback_icon(image: Image) -> void:
	_fill_rect(image, 0, 0, ICON_SIZE, ICON_SIZE, Color(0.72, 0.0, 0.72))
	for index in range(ICON_SIZE):
		_set_pixel(image, index, index, Color.WHITE)
		_set_pixel(image, ICON_SIZE - 1 - index, index, Color.WHITE)


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
