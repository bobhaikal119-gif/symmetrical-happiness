extends Node
class_name WorldEventBridge

## Scene-bound adapter: pure grid signals are relayed into legacy global contracts.
var world_grid: WorldGrid
var signal_bus: SignalBus

func configure(grid: WorldGrid, bus: SignalBus) -> void:
	world_grid = grid
	signal_bus = bus
	world_grid.tile_damaged.connect(_on_damaged)
	world_grid.tile_broken.connect(_on_broken)
	world_grid.tile_placed.connect(_on_placed)
	world_grid.background_wall_changed.connect(_on_background)

func _on_damaged(cell: Vector2i, current: float, maximum: float) -> void:
	signal_bus.tile_damaged.emit(cell, current, maximum)

func _on_broken(cell: Vector2i, tile_id: int) -> void:
	signal_bus.tile_broken.emit(cell, tile_id)

func _on_placed(cell: Vector2i, tile_id: int) -> void:
	signal_bus.tile_placed.emit(cell, tile_id)

func _on_background(cell: Vector2i, tile_id: int) -> void:
	signal_bus.background_wall_changed.emit(cell, tile_id)
