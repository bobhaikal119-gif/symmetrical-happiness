extends Node2D
class_name MiningLaserComponent

## Shared cursor targeting, mining and bounded 20Hz aim telemetry (including idle).
@export var reach_distance: float = 64.0
@export var mining_damage: float = 5.0
@export var beam_width: float = 2.0
@export var beam_color: Color = Color(1.0, 0.78, 0.2)
@export var cursor_reticle: CursorReticle
@export var spread_recovery_rate: float = 1.8
@export var recoil_recovery_rate: float = 3.5
const TELEMETRY_INTERVAL: float = 0.05
const RECOIL_INTERVAL: float = 0.12

var laser_beam: Line2D
var world_grid: WorldGrid
var is_active: bool = false
var target_grid_pos: Vector2i = Vector2i.ZERO
var spread_ratio: float = 0.0
var recoil_ratio: float = 0.0
var _input_active: bool = false
var _battery: BatteryComponent
var _bus: SignalBus
var _telemetry_elapsed: float = 0.0
var _recoil_elapsed: float = 0.0

func _ready() -> void:
	laser_beam = get_node_or_null("LaserBeam") as Line2D
	if laser_beam == null:
		laser_beam = Line2D.new()
		laser_beam.name = "LaserBeam"
		add_child(laser_beam)
	laser_beam.width = beam_width
	laser_beam.default_color = beam_color
	laser_beam.visible = false
	if get_parent() != null:
		if cursor_reticle == null:
			cursor_reticle = get_parent().get_node_or_null("CursorReticle") as CursorReticle
		_battery = get_parent().get_node_or_null("BatteryComponent") as BatteryComponent
	if cursor_reticle != null:
		cursor_reticle.mining_reach = reach_distance
	_bus = SignalBus.get_instance()
	_bus.settings_menu_toggled.connect(_on_menu_toggled)
	_bus.crafting_menu_toggled.connect(_on_menu_toggled)
	_bus.shop_toggled.connect(func(open: bool, _npc: String) -> void: _on_menu_toggled(open))
	_publish_aim_telemetry()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and (event as InputEventKey).echo:
		return
	if event.is_action_released("mine_primary"):
		deactivate()
	elif not SettingsManager.is_gameplay_input_blocked() and event.is_action_pressed("mine_primary"):
		activate()
		_input_active = true
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if SettingsManager.is_gameplay_input_blocked() or (_input_active and not Input.is_action_pressed("mine_primary")):
		deactivate()
	spread_ratio = move_toward(spread_ratio, 0.0, spread_recovery_rate * delta)
	recoil_ratio = move_toward(recoil_ratio, 0.0, recoil_recovery_rate * delta)
	var mining: bool = false
	if is_active and world_grid != null:
		var endpoint: Vector2 = get_global_mouse_position()
		if cursor_reticle != null:
			cursor_reticle.world_grid = world_grid
			target_grid_pos = cursor_reticle.get_mining_target(reach_distance)
			endpoint = cursor_reticle.grid_to_world(target_grid_pos)
		else:
			target_grid_pos = Vector2i(floori(endpoint.x / WorldGrid.TILE_SIZE), floori(endpoint.y / WorldGrid.TILE_SIZE))
		if _is_target_valid(target_grid_pos):
			world_grid.damage_tile(target_grid_pos.x, target_grid_pos.y, mining_damage * delta)
			_update_laser_beam(endpoint)
			mining = true
	if not mining:
		_set_beam_active(false)
		_recoil_elapsed = 0.0
	else:
		spread_ratio = minf(0.7, spread_ratio + (spread_recovery_rate + 0.8) * delta)
		_recoil_elapsed -= delta
		if _recoil_elapsed <= 0.0:
			recoil_ratio = minf(0.3, recoil_ratio + 0.25)
			_recoil_elapsed = RECOIL_INTERVAL
	# Never return early while idle: an out-of-reach/Smart change and the last
	# recoil settling must reach the UI even when the laser is not held.
	_telemetry_elapsed += delta
	if _telemetry_elapsed >= TELEMETRY_INTERVAL:
		_telemetry_elapsed = fmod(_telemetry_elapsed, TELEMETRY_INTERVAL)
		_publish_aim_telemetry()

func _publish_aim_telemetry() -> void:
	if _bus == null:
		return
	var in_reach: bool = false
	var smart_locked: bool = false
	if not SettingsManager.is_gameplay_input_blocked() and world_grid != null:
		if cursor_reticle != null:
			cursor_reticle.world_grid = world_grid
			var building: bool = cursor_reticle.build_mode and not is_active and not Input.is_action_pressed("mine_primary")
			var reach: float = cursor_reticle.building_reach if building else reach_distance
			var target: Vector2i = cursor_reticle.get_build_target(reach) if building else cursor_reticle.get_mining_target(reach)
			in_reach = cursor_reticle.is_target_in_reach(target, reach)
			smart_locked = in_reach and cursor_reticle.is_smart_locked(building)
		else:
			in_reach = global_position.distance_to(get_global_mouse_position()) <= reach_distance
	_bus.aim_telemetry_updated.emit(clampf(spread_ratio + recoil_ratio, 0.0, 1.0), in_reach, smart_locked)

func _is_target_valid(grid_pos: Vector2i) -> bool:
	if world_grid == null or not world_grid.is_valid_position(grid_pos.x, grid_pos.y):
		return false
	if cursor_reticle != null:
		return cursor_reticle.is_mining_target_valid(grid_pos, reach_distance)
	var tile_world_pos: Vector2 = Vector2(grid_pos * WorldGrid.TILE_SIZE) + Vector2.ONE * (WorldGrid.TILE_SIZE * 0.5)
	if global_position.distance_to(tile_world_pos) > reach_distance:
		return false
	var tile_id: int = world_grid.get_tile(grid_pos.x, grid_pos.y)
	return world_grid.get_tile_max_hp(tile_id) > 0.0 and not world_grid.is_hazard(grid_pos.x, grid_pos.y)

func _update_laser_beam(world_pos: Vector2) -> void:
	_set_beam_active(true)
	laser_beam.points = PackedVector2Array([Vector2.ZERO, to_local(world_pos)])

func _set_beam_active(active: bool) -> void:
	if laser_beam != null:
		laser_beam.visible = active
	if _battery != null and _battery.is_laser_active != active:
		_battery.set_laser_active(active)

func activate() -> void:
	if not SettingsManager.is_gameplay_input_blocked():
		is_active = true

func deactivate() -> void:
	is_active = false
	_input_active = false
	_set_beam_active(false)

func toggle() -> void:
	if is_active:
		deactivate()
	else:
		activate()

func _on_menu_toggled(is_open: bool) -> void:
	if is_open:
		deactivate()
