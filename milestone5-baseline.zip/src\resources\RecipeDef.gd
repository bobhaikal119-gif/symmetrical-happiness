extends Resource
class_name RecipeDef

## Recipe metadata is the only source of category and station-tier gating.
@export var id: String = ""
@export var output_item_id: String = ""
@export var output_count: int = 1
@export var ingredients: Dictionary = {}
@export var station_required: String = "hand"
@export var category: String = "Survival"
