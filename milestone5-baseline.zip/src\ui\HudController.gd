extends CanvasLayer

class_name HudController

const TEMPERATURE_MINIMUM: float = -50.0

@onready var temperature_bar: ProgressBar = %TemperatureBar
@onready var temperature_value: Label = %TemperatureValue
@onready var battery_bar: ProgressBar = %BatteryBar
@onready var battery_value: Label = %BatteryValue
@onready var hp_bar: ProgressBar = %HPBar
@onready var hp_value: Label = %HPValue
@onready var oxygen_bar: ProgressBar = %OxygenBar
@onready var oxygen_value: Label = %OxygenValue
@onready var depth_label: Label = %DepthLabel
@onready var biome_label: Label = %BiomeLabel
@onready var storm_timer_label: Label = %StormTimerLabel
@onready var grid_power_label: Label = %GridPowerLabel
@onready var grid_efficiency_label: Label = %GridEfficiencyLabel
@onready var storm_wave_alert: PanelContainer = %StormWaveAlert
@onready var storm_wave_alert_label: Label = %StormWaveAlertLabel
@onready var controls_hint_label: Label = %ControlsHintLabel
@onready var _layout: Control = $Layout
@onready var _smart_badge: Button = %SmartCursorBadge
@onready var _performance_panel: PanelContainer = %PerformancePanel
@onready var _performance_label: Label = %PerformanceLabel
@onready var _popup_layer: Control = %FloatingPopups
@onready var _pioneer_label: Label = %PioneerLabel
@onready var _credits_label: Label = %CreditsLabel
@onready var _housing_label: Label = %HousingLabel
@onready var _underwater_panel: PanelContainer = %UnderwaterWarning
@onready var _underwater_label: Label = %UnderwaterLabel
@onready var _equipment_label: Label = %EquipmentLabel

var _signal_bus: SignalBus
var _wave_alert_tween: Tween
var _hint_tween: Tween
var _last_hp: float = -1.0
var _popups: Array[Label] = []
var _head_submerged: bool = false
var _submersion_ratio: float = 0.0
var _oxygen_current: float = 100.0
var _oxygen_maximum: float = 100.0
var _oxygen_pulse_phase: float = 0.0
var _underwater_o2_multiplier: float = 1.0
var _water_chill_multiplier: float = 1.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_signal_bus = SignalBus.get_instance()
	AntiSlopTheme.apply_to(_layout)
	_connect_bus_signals()
	_initialize_display()
	_smart_badge.pressed.connect(_toggle_smart_cursor)
	get_viewport().size_changed.connect(_apply_hud_scale)
	_apply_hud_scale()
	_update_smart_badge(bool(SettingsManager.get_setting("mouse", "smart_cursor", false)))
	_set_performance_visible(bool(SettingsManager.get_setting("optimization", "performance_overlay", false)))
	_pioneer_label.text = "PIONEER / %s" % str(SettingsManager.get_setting("profile", "pioneer_name", "Pioneer")).to_upper()
	_signal_bus.inventory_snapshot_requested.emit()
	_signal_bus.equipment_snapshot_requested.emit()


func _process(delta: float) -> void:
	if not _head_submerged or get_tree().paused:
		return
	# One bounded phase, not a looping Tween per telemetry event. Text stays fully opaque.
	_oxygen_pulse_phase = fposmod(_oxygen_pulse_phase + maxf(delta, 0.0) * TAU * 1.2, TAU)
	var pulse: float = 0.5 + sin(_oxygen_pulse_phase) * 0.5
	oxygen_bar.self_modulate = Color.WHITE.lerp(Color("38bdf8"), 0.12 + pulse * 0.28)


func _connect_bus_signals() -> void:
	if not _signal_bus.temperature_changed.is_connected(_on_temperature_changed):
		_signal_bus.temperature_changed.connect(_on_temperature_changed)
	if not _signal_bus.battery_changed.is_connected(_on_battery_changed):
		_signal_bus.battery_changed.connect(_on_battery_changed)
	if not _signal_bus.hp_changed.is_connected(_on_hp_changed):
		_signal_bus.hp_changed.connect(_on_hp_changed)
	if not _signal_bus.oxygen_changed.is_connected(_on_oxygen_changed):
		_signal_bus.oxygen_changed.connect(_on_oxygen_changed)
	if not _signal_bus.depth_changed.is_connected(_on_depth_changed):
		_signal_bus.depth_changed.connect(_on_depth_changed)
	if not _signal_bus.cryo_storm_timer_updated.is_connected(_on_cryo_storm_timer_updated):
		_signal_bus.cryo_storm_timer_updated.connect(_on_cryo_storm_timer_updated)
	if not _signal_bus.power_grid_updated.is_connected(_on_power_grid_updated):
		_signal_bus.power_grid_updated.connect(_on_power_grid_updated)
	if not _signal_bus.storm_wave_started.is_connected(_on_storm_wave_started):
		_signal_bus.storm_wave_started.connect(_on_storm_wave_started)
	if not _signal_bus.show_hud_hint.is_connected(show_controls_hint):
		_signal_bus.show_hud_hint.connect(show_controls_hint)
	if not _signal_bus.hide_hud_hint.is_connected(hide_controls_hint):
		_signal_bus.hide_hud_hint.connect(hide_controls_hint)
	_signal_bus.setting_changed.connect(_on_setting_changed)
	_signal_bus.smart_cursor_toggled.connect(_update_smart_badge)
	_signal_bus.keybinds_updated.connect(_refresh_smart_badge)
	_signal_bus.item_collected.connect(_on_item_collected)
	_signal_bus.credits_changed.connect(_on_credits_changed)
	_signal_bus.housing_status_changed.connect(_on_housing_status_changed)
	_signal_bus.performance_updated.connect(_on_performance_updated)
	_signal_bus.player_submerged_changed.connect(_on_player_submerged_changed)
	_signal_bus.equipment_changed.connect(_on_equipment_changed)


func _initialize_display() -> void:
	_update_bar(temperature_bar, 20.0, 100.0, TEMPERATURE_MINIMUM)
	temperature_value.text = "20.0 °C"
	_update_bar(battery_bar, 100.0, 100.0)
	battery_value.text = "100 / 100"
	_update_bar(hp_bar, 100.0, 100.0)
	hp_value.text = "100 / 100"
	_update_bar(oxygen_bar, 100.0, 100.0)
	oxygen_value.text = "100 / 100"
	_underwater_panel.hide()
	_on_equipment_changed(1.0, 1.0)
	depth_label.text = "Depth: 0 m"
	biome_label.text = "Permafrost Surface"
	_credits_label.text = "0 CR"
	_housing_label.text = "Housing: no registered room"
	storm_timer_label.text = "Cryo Storm: 03:00"
	grid_power_label.text = "Grid Power: 0.0 / 0.0 W"
	grid_efficiency_label.text = "Efficiency: 100%"
	storm_wave_alert.visible = false
	controls_hint_label.visible = false
	(controls_hint_label.get_parent() as Control).hide()


func _on_temperature_changed(current: float, max_value: float) -> void:
	_update_bar(temperature_bar, current, max_value, TEMPERATURE_MINIMUM)
	temperature_value.text = "%.1f °C" % current


func _on_battery_changed(current: float, max_value: float) -> void:
	_update_bar(battery_bar, current, max_value)
	battery_value.text = "%.0f / %.0f" % [current, max_value]


func _on_hp_changed(current: float, max_value: float) -> void:
	_update_bar(hp_bar, current, max_value)
	hp_value.text = "%.0f / %.0f" % [current, max_value]
	if _last_hp >= 0.0 and absf(current - _last_hp) >= 0.1:
		var change: float = current - _last_hp
		_spawn_popup("%+.0f INTEGRITY" % change, Color(1.0, 0.4, 0.3) if change < 0.0 else Color(0.4, 1.0, 0.65))
	_last_hp = current


func _on_oxygen_changed(current: float, max_value: float) -> void:
	_oxygen_maximum = maxf(0.001, max_value) if is_finite(max_value) else 100.0
	_oxygen_current = clampf(current, 0.0, _oxygen_maximum) if is_finite(current) else 0.0
	_update_bar(oxygen_bar, _oxygen_current, _oxygen_maximum)
	oxygen_value.text = "%.0f / %.0f" % [_oxygen_current, _oxygen_maximum]
	_refresh_underwater_warning()


func _on_player_submerged_changed(is_submerged: bool, depth_ratio: float) -> void:
	_head_submerged = is_submerged
	_submersion_ratio = clampf(depth_ratio, 0.0, 1.0) if is_finite(depth_ratio) else 0.0
	_underwater_panel.visible = _head_submerged
	if not _head_submerged:
		_oxygen_pulse_phase = 0.0
		oxygen_bar.self_modulate = Color.WHITE
	_refresh_underwater_warning()


func _on_equipment_changed(underwater_o2_multiplier: float, water_chill_multiplier: float) -> void:
	_underwater_o2_multiplier = clampf(underwater_o2_multiplier, 0.0, 1.0) if is_finite(underwater_o2_multiplier) else 1.0
	_water_chill_multiplier = clampf(water_chill_multiplier, 0.0, 1.0) if is_finite(water_chill_multiplier) else 1.0
	_equipment_label.text = "DIVE / O2 DRAIN %.0f%% / CHILL %.0f%%" % [_underwater_o2_multiplier * 100.0, _water_chill_multiplier * 100.0]
	_equipment_label.tooltip_text = "Passive carried equipment. Lower percentages reduce underwater oxygen drain and additional water cooling; ambient cold remains."
	_refresh_underwater_warning()


func _refresh_underwater_warning() -> void:
	var percent: int = roundi(_oxygen_current / _oxygen_maximum * 100.0)
	_underwater_label.text = "%s / O2 %d%%" % ["LOW OXYGEN" if percent <= 25 else "UNDERWATER", percent]
	_underwater_panel.tooltip_text = "Head submerged: find air. Body immersion %.0f%%. Underwater oxygen drain %.0f%% of base." % [_submersion_ratio * 100.0, _underwater_o2_multiplier * 100.0]


func _on_depth_changed(meters: int, biome_name: String) -> void:
	depth_label.text = "Depth: %d m" % meters
	biome_label.text = biome_name
	biome_label.tooltip_text = biome_name


func _on_cryo_storm_timer_updated(time_left: float) -> void:
	var total_seconds: int = maxi(0, ceili(time_left))
	var minutes: int = total_seconds / 60
	var seconds: int = total_seconds % 60
	storm_timer_label.text = "Cryo Storm: %02d:%02d" % [minutes, seconds]
	if total_seconds <= 15:
		storm_timer_label.add_theme_color_override("font_color", Color(1.0, 0.34, 0.24))
	else:
		storm_timer_label.add_theme_color_override("font_color", Color(0.55, 0.9, 1.0))


func _on_power_grid_updated(produced_watts: float, demand_watts: float, efficiency: float) -> void:
	grid_power_label.text = "Grid Power: %.1f / %.1f W" % [produced_watts, demand_watts]
	var normalized_efficiency: float = efficiency
	if normalized_efficiency <= 1.0:
		normalized_efficiency *= 100.0
	normalized_efficiency = clampf(normalized_efficiency, 0.0, 100.0)
	grid_efficiency_label.text = "Efficiency: %.0f%%" % normalized_efficiency
	var efficiency_color: Color = Color(0.45, 1.0, 0.62)
	if normalized_efficiency < 50.0:
		efficiency_color = Color(1.0, 0.34, 0.24)
	elif normalized_efficiency < 85.0:
		efficiency_color = Color(1.0, 0.76, 0.28)
	grid_efficiency_label.add_theme_color_override("font_color", efficiency_color)


func _on_storm_wave_started(wave_number: int, enemy_count: int) -> void:
	if _wave_alert_tween != null and _wave_alert_tween.is_valid():
		_wave_alert_tween.kill()
	storm_wave_alert_label.text = "STORM WAVE %d  •  %d CRAWLERS" % [wave_number, enemy_count]
	storm_wave_alert.visible = true
	storm_wave_alert.modulate = Color.WHITE
	storm_wave_alert.scale = Vector2(0.94, 0.94)
	_wave_alert_tween = create_tween()
	_wave_alert_tween.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
	_wave_alert_tween.tween_property(storm_wave_alert, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_wave_alert_tween.tween_interval(2.5)
	_wave_alert_tween.tween_property(storm_wave_alert, "modulate:a", 0.0, 1.0).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	_wave_alert_tween.tween_callback(_hide_wave_alert)


func show_controls_hint(text: String) -> void:
	if _hint_tween != null and _hint_tween.is_valid():
		_hint_tween.kill()
	controls_hint_label.text = text
	controls_hint_label.visible = not text.is_empty()
	(controls_hint_label.get_parent() as Control).visible = not text.is_empty()
	controls_hint_label.modulate = Color.WHITE
	if text.is_empty():
		return
	_hint_tween = create_tween()
	_hint_tween.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
	_hint_tween.tween_interval(3.0)
	_hint_tween.tween_property(controls_hint_label, "modulate:a", 0.0, 0.5)
	_hint_tween.tween_callback(hide_controls_hint)


func hide_controls_hint() -> void:
	controls_hint_label.visible = false
	(controls_hint_label.get_parent() as Control).hide()
	controls_hint_label.modulate = Color.WHITE


func _hide_wave_alert() -> void:
	storm_wave_alert.visible = false
	storm_wave_alert.modulate = Color.WHITE
	storm_wave_alert.scale = Vector2.ONE


func _update_bar(bar: ProgressBar, current: float, max_value: float, min_value: float = 0.0) -> void:
	bar.min_value = min_value
	bar.max_value = maxf(max_value, min_value + 0.001)
	bar.value = clampf(current, bar.min_value, bar.max_value)


func _apply_hud_scale() -> void:
	var requested: float = float(SettingsManager.get_setting("general", "hud_scale", 1.0))
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	# Transform the CanvasLayer, not individual Controls. Compensating the root
	# rectangle keeps right/bottom anchors inside the viewport at every scale.
	var applied: float = minf(requested, maxf(0.55, viewport_size.x / 820.0))
	scale = Vector2.ONE * applied
	_layout.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_layout.size = viewport_size / applied
	var status: PanelContainer = $Layout/StatusPanel
	var systems: PanelContainer = $Layout/SystemsPanel
	var perf: PanelContainer = $Layout/PerformancePanel
	var hint: PanelContainer = $Layout/HintPanel
	status.offset_right = 408.0
	systems.offset_left = -360.0
	perf.offset_left = -360.0
	# At maximum scale the lower hint stays below the Smart Cursor badge.
	hint.offset_top = -64.0
	hint.offset_bottom = -16.0
	storm_wave_alert.offset_top = 424.0 if _layout.size.x < 1248.0 else 24.0
	storm_wave_alert.offset_bottom = storm_wave_alert.offset_top + 56.0


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	match section + "/" + key:
		"general/hud_scale":
			_apply_hud_scale()
		"mouse/smart_cursor":
			_update_smart_badge(bool(value))
		"optimization/performance_overlay":
			_set_performance_visible(bool(value))
		"general/floating_popups":
			if not bool(value):
				_clear_popups()
		"optimization/max_particles":
			_trim_popups(int(value))
		"profile/pioneer_name":
			_pioneer_label.text = "PIONEER / %s" % str(value).to_upper()


func _toggle_smart_cursor() -> void:
	SettingsManager.set_setting("mouse", "smart_cursor", not bool(SettingsManager.get_setting("mouse", "smart_cursor", false)))


func _refresh_smart_badge() -> void:
	_update_smart_badge(bool(SettingsManager.get_setting("mouse", "smart_cursor", false)))


func _update_smart_badge(enabled: bool) -> void:
	_smart_badge.text = "SMART CURSOR / %s [%s]" % ["ON" if enabled else "OFF", SettingsManager.get_key_label(&"toggle_smart_cursor")]
	_smart_badge.add_theme_color_override("font_color", Color(0.4, 1.0, 0.76) if enabled else Color(0.95, 0.74, 0.36))
	_smart_badge.tooltip_text = "Directional target assistance: %s. Reach limits still apply. Click or press %s to toggle." % ["enabled" if enabled else "disabled", SettingsManager.get_key_label(&"toggle_smart_cursor")]


func _set_performance_visible(enabled: bool) -> void:
	_performance_panel.visible = enabled


func _on_performance_updated(fps: float, active_nodes: int, total_nodes: int) -> void:
	_performance_label.text = "%.0f FPS\nACTIVE NODES %d / %d" % [fps, active_nodes, total_nodes]


func _on_credits_changed(current_credits: int) -> void:
	_credits_label.text = "%d CR" % current_credits


func _on_housing_status_changed(message: String) -> void:
	_housing_label.text = "Housing: %s" % message
	_housing_label.tooltip_text = message


func _on_item_collected(item_id: String, count: int) -> void:
	if count > 0:
		_spawn_popup("+%d %s" % [count, item_id.replace("_", " ").capitalize()], Color(0.46, 0.94, 0.83))


func _spawn_popup(text: String, color: Color) -> void:
	if get_tree().paused or not bool(SettingsManager.get_setting("general", "floating_popups", true)):
		return
	var budget: int = int(SettingsManager.get_setting("optimization", "max_particles", 96))
	if budget <= 0:
		return
	# UI labels are effects too. A smaller practical cap avoids covering the play
	# area, while never exceeding the user's shared transient-effect budget.
	var popup_limit: int = mini(budget, 12)
	_trim_popups(popup_limit - 1)
	var popup := Label.new()
	popup.text = text
	popup.mouse_filter = Control.MOUSE_FILTER_IGNORE
	popup.add_theme_color_override("font_color", color)
	popup.add_theme_color_override("font_outline_color", Color(0.01, 0.02, 0.025, 0.95))
	popup.add_theme_constant_override("outline_size", 4)
	popup.add_theme_font_size_override("font_size", 16)
	_popup_layer.add_child(popup)
	popup.position = Vector2(_layout.size.x * 0.5 + 45.0, _layout.size.y * 0.55 + float(_popups.size() % 5) * 23.0)
	_popups.append(popup)
	var tween: Tween = popup.create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
	tween.set_parallel(true)
	tween.tween_property(popup, "position:y", popup.position.y - 50.0, 1.3)
	tween.tween_property(popup, "modulate:a", 0.0, 0.5).set_delay(0.8)
	tween.chain().tween_callback(_remove_popup.bind(popup))


func _remove_popup(popup: Label) -> void:
	_popups.erase(popup)
	if is_instance_valid(popup):
		popup.queue_free()


func _trim_popups(limit: int) -> void:
	while _popups.size() > maxi(0, mini(limit, 12)):
		var oldest: Label = _popups.pop_front()
		if is_instance_valid(oldest):
			if oldest.get_parent() == _popup_layer:
				_popup_layer.remove_child(oldest)
			oldest.queue_free()


func _clear_popups() -> void:
	_trim_popups(0)
