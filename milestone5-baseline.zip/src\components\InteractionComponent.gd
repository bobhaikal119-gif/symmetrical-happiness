extends Node
class_name InteractionComponent

## Typed interaction selection runs before placement; GUI still gets first refusal.
var actor: CharacterBody2D
var interaction_reach: float = 48.0
var _current_prompt: String = ""
var _elapsed: float = 0.0

func _ready() -> void:
	process_priority = -10

func configure(owner_actor: CharacterBody2D) -> void:
	actor = owner_actor
	set_process_unhandled_input(true)

func _unhandled_input(event: InputEvent) -> void:
	if actor == null or SettingsManager.is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	var by_mouse: bool = event.is_action_pressed("place_secondary")
	if not by_mouse and not event.is_action_pressed("interact"):
		return
	var target: InteractableEntity = find_target(by_mouse)
	if target == null:
		return
	target.interact(actor)
	get_viewport().set_input_as_handled()

func find_target(mouse_only: bool = false) -> InteractableEntity:
	var nearest: InteractableEntity
	var best: float = interaction_reach
	for candidate: Node in get_tree().get_nodes_in_group("interactables"):
		var entity: InteractableEntity = candidate as InteractableEntity
		if entity == null or not entity.can_interact(actor):
			continue
		if mouse_only and entity.global_position.distance_to(actor.get_global_mouse_position()) > 16.0:
			continue
		var distance: float = actor.global_position.distance_to(entity.global_position)
		if distance <= best:
			best = distance
			nearest = entity
	return nearest

func _process(delta: float) -> void:
	if actor == null or SettingsManager.is_gameplay_input_blocked():
		return
	_elapsed += delta
	if _elapsed < 0.5:
		return
	_elapsed = 0.0
	var target: InteractableEntity = find_target()
	var prompt: String = target.get_prompt_text() if target != null else ""
	if prompt != _current_prompt:
		_current_prompt = prompt
		if not prompt.is_empty():
			SignalBus.get_instance().show_hud_hint.emit("[%s] %s" % [SettingsManager.get_key_label(&"interact"), prompt])
		else:
			SignalBus.get_instance().hide_hud_hint.emit()
