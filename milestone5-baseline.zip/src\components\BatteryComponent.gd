extends Node

class_name BatteryComponent

"""Manages the player's portable battery and publishes typed telemetry."""

@export var max_battery: float = 100.0
@export var idle_recharge_rate: float = 0.1
@export var flashlight_drain_rate: float = 0.2
@export var laser_drain_rate: float = 0.4

var current_battery: float = 100.0
var is_flashlight_active: bool = false
var is_laser_active: bool = false
var signal_bus: SignalBus
var _last_emitted: float = -1.0

func _ready() -> void:
	signal_bus = SignalBus.get_instance()
	current_battery = max_battery
	_emit_battery_changed(true)

func _process(delta: float) -> void:
	var change: float = 0.0
	if is_flashlight_active:
		change -= flashlight_drain_rate * delta
	if is_laser_active:
		change -= laser_drain_rate * delta
	if not is_flashlight_active and not is_laser_active:
		change += idle_recharge_rate * delta
	current_battery = clampf(current_battery + change, 0.0, max_battery)
	_emit_battery_changed(false)

func _emit_battery_changed(force: bool) -> void:
	if signal_bus != null and (force or not is_equal_approx(current_battery, _last_emitted)):
		_last_emitted = current_battery
		signal_bus.battery_changed.emit(current_battery, max_battery)

func set_flashlight_active(active: bool) -> void:
	is_flashlight_active = active
	_emit_battery_changed(true)

func set_laser_active(active: bool) -> void:
	is_laser_active = active
	_emit_battery_changed(true)

func get_battery_percentage() -> float:
	if max_battery <= 0.0:
		return 0.0
	return current_battery / max_battery * 100.0
