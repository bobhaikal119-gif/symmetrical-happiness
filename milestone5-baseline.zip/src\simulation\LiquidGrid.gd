extends RefCounted

class_name LiquidGrid

## Sparse, deterministic, sealed-boundary liquid simulation. No scene dependencies.
## Flow never discards a small remainder. Terrain/door displacement is held in a
## serialized reserve until a cardinally adjacent cell can accept it.
## Reactions consume exactly the same water/lava volume (recorded below). One
## cumulative unit of cooled lava deposits basalt, only once that lava cell is empty.
signal cells_changed(cells: Array[Vector2i])
signal solidified(cell: Vector2i)

const NONE: int = 0
const WATER: int = 1
const LAVA: int = 2
const LIQUID_NONE: int = NONE
const LIQUID_WATER: int = WATER
const LIQUID_LAVA: int = LAVA
const SAVE_VERSION: int = 1
const MAX_ACTIVE_PER_STEP: int = 2048
const MAX_PRESSURE_CELLS: int = 128
const MAX_PRESSURE_WORK_PER_STEP: int = 8192
const FLOW_TOLERANCE: float = 0.000001
const DIRECTIONS: Array[Vector2i] = [Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP]

var world_grid: WorldGrid
var width: int = WorldGrid.GRID_SIZE
var height: int = WorldGrid.GRID_SIZE
var reacted_water_volume: float = 0.0
var reacted_lava_volume: float = 0.0
var last_step_work: int = 0
var last_pressure_work: int = 0
var _pressure_visited: Dictionary = {}
var _types: Dictionary = {}
var _volumes: Dictionary = {}
var _reserved: Dictionary = {}
var _reaction_progress: Dictionary = {}
var _blocked: Dictionary = {}
var _active: Dictionary = {}
var _queue: Array[Vector2i] = []
var _queue_head: int = 0
var _queue_tail: int = 0
var _queue_count: int = 0
var _tick: int = 0
var _changed: Dictionary = {}
var _stepping: bool = false


func _init(world: WorldGrid = null, p_width: int = 512, p_height: int = 512) -> void:
	world_grid = world
	width = clampi(p_width, 1, WorldGrid.GRID_SIZE)
	height = clampi(p_height, 1, WorldGrid.GRID_SIZE)
	_queue.resize(self.width * self.height)
	if world_grid != null:
		world_grid.tile_placed.connect(_on_world_tile_changed)


func set_cell(x: int, y: int, liquid_id: int, volume: float) -> void:
	var cell := Vector2i(x, y)
	if not _valid(cell) or not is_finite(volume) or liquid_id < NONE or liquid_id > LAVA:
		return
	var amount: float = clampf(volume, 0.0, 1.0)
	if liquid_id == NONE or amount <= 0.0:
		_store(cell, NONE, 0.0)
	elif _is_blocked(cell):
		# Explicit injection into terrain remains accountable, never embedded.
		_reserve(cell, liquid_id, amount)
	else:
		_store(cell, liquid_id, amount)
	if not _stepping:
		_emit_changes()


func get_liquid(x: int, y: int) -> int:
	return int(_types.get(Vector2i(x, y), NONE))


func get_volume(x: int, y: int) -> float:
	return float(_volumes.get(Vector2i(x, y), 0.0))


func sample_submersion(world_pos: Vector2) -> float:
	if not world_pos.is_finite():
		return 0.0
	var cell := Vector2i(floori(world_pos.x / WorldGrid.TILE_SIZE), floori(world_pos.y / WorldGrid.TILE_SIZE))
	var volume: float = get_volume(cell.x, cell.y)
	if volume <= 0.0:
		return 0.0
	var local_y: float = world_pos.y / WorldGrid.TILE_SIZE - float(cell.y)
	return clampf(local_y - (1.0 - volume), 0.0, 1.0)


func step(delta: float = 0.05) -> void:
	last_step_work = 0
	last_pressure_work = 0
	_pressure_visited.clear()
	if not is_finite(delta) or delta <= 0.0:
		return
	var rate: float = minf(delta / 0.05, 4.0)
	var work: int = mini(_queue_count, MAX_ACTIVE_PER_STEP)
	_stepping = true
	for _index: int in range(work):
		var cell: Vector2i = _queue[_queue_head]
		_queue_head = (_queue_head + 1) % _queue.size()
		_queue_count -= 1
		_active.erase(cell)
		last_step_work += 1
		_process_cell(cell, rate)
	_tick += 1
	_stepping = false
	_emit_changes()


func get_active_cells() -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for index: int in range(_queue_count):
		cells.append(_queue[(_queue_head + index) % _queue.size()])
	return cells


func get_total_volume(liquid_id: int = NONE) -> float:
	var total: float = 0.0
	for cell: Vector2i in _volumes:
		if liquid_id == NONE or int(_types[cell]) == liquid_id:
			total += float(_volumes[cell])
	return total + get_reserved_volume(liquid_id)


func get_reserved_volume(liquid_id: int = NONE) -> float:
	var total: float = 0.0
	for entry: Dictionary in _reserved.values():
		for stored_id: int in entry:
			if liquid_id == NONE or stored_id == liquid_id:
				total += float(entry[stored_id])
	return total


func get_reacted_volume(liquid_id: int = NONE) -> float:
	if liquid_id == WATER:
		return reacted_water_volume
	if liquid_id == LAVA:
		return reacted_lava_volume
	return reacted_water_volume + reacted_lava_volume


func set_blocked_cells(cells: Array[Vector2i]) -> void:
	var next: Dictionary = {}
	for cell: Vector2i in cells:
		if _valid(cell):
			next[cell] = true
	var affected: Dictionary = _blocked.duplicate()
	for cell: Vector2i in next:
		affected[cell] = true
	_blocked = next
	for cell: Vector2i in affected:
		_reconcile_blocked(cell)
		_wake_neighborhood(cell)
	if not _stepping:
		_emit_changes()


func clear() -> void:
	for cell: Vector2i in _volumes:
		_changed[cell] = true
	_types.clear()
	_volumes.clear()
	_reserved.clear()
	_reaction_progress.clear()
	_active.clear()
	_queue_head = 0
	_queue_tail = 0
	_queue_count = 0
	_tick = 0
	reacted_water_volume = 0.0
	reacted_lava_volume = 0.0
	_emit_changes()


func serialize() -> Dictionary:
	var cells: Array = []
	var reserves: Array = []
	var reactions: Array = []
	var active: Array = []
	for cell: Vector2i in _sorted_keys(_volumes):
		cells.append([cell.x, cell.y, int(_types[cell]), float(_volumes[cell])])
	for cell: Vector2i in _sorted_keys(_reserved):
		var entry: Dictionary = _reserved[cell]
		for liquid_id: int in [WATER, LAVA]:
			if entry.has(liquid_id):
				reserves.append([cell.x, cell.y, liquid_id, float(entry[liquid_id])])
	for cell: Vector2i in _sorted_keys(_reaction_progress):
		reactions.append([cell.x, cell.y, float(_reaction_progress[cell])])
	for cell: Vector2i in get_active_cells():
		active.append([cell.x, cell.y])
	return {
		"version": SAVE_VERSION, "width": width, "height": height,
		"cells": cells, "reserved": reserves, "reaction_progress": reactions,
		"reacted_water": reacted_water_volume, "reacted_lava": reacted_lava_volume,
		"tick": _tick, "active": active,
	}


func deserialize(data: Dictionary) -> bool:
	# Validate everything, including the work queue, before touching live state.
	for key: String in ["version", "width", "height", "tick"]:
		if not data.get(key) is int:
			return false
	if int(data["version"]) != SAVE_VERSION or int(data["width"]) != width or int(data["height"]) != height or int(data["tick"]) < 0:
		return false
	for key: String in ["cells", "reserved", "reaction_progress", "active"]:
		if not data.get(key) is Array or data[key].size() > width * height * (2 if key == "reserved" else 1):
			return false
	if not _valid_amount(data.get("reacted_water"), true) or not _valid_amount(data.get("reacted_lava"), true):
		return false
	if float(data["reacted_water"]) != float(data["reacted_lava"]):
		return false
	var next_types: Dictionary = {}
	var next_volumes: Dictionary = {}
	var next_reserved: Dictionary = {}
	var next_reactions: Dictionary = {}
	var next_active: Dictionary = {}
	var next_queue: Array[Vector2i] = []
	var validated_total: float = 0.0
	var validated_cooling: float = 0.0
	for row: Variant in data["cells"]:
		if not _valid_liquid_row(row):
			return false
		var cell := Vector2i(int(row[0]), int(row[1]))
		if _is_blocked(cell) or next_volumes.has(cell) or float(row[3]) > 1.0:
			return false
		next_types[cell] = int(row[2])
		next_volumes[cell] = float(row[3])
		validated_total += float(row[3])
	for row: Variant in data["reserved"]:
		if not _valid_liquid_row(row):
			return false
		var cell := Vector2i(int(row[0]), int(row[1]))
		var entry: Dictionary = next_reserved.get(cell, {})
		var liquid_id: int = int(row[2])
		if entry.has(liquid_id):
			return false
		entry[liquid_id] = float(row[3])
		next_reserved[cell] = entry
		validated_total += float(row[3])
		if not is_finite(validated_total):
			return false
	for row: Variant in data["reaction_progress"]:
		if not _valid_position_row(row, 3) or not _valid_amount(row[2], false):
			return false
		var cell := Vector2i(int(row[0]), int(row[1]))
		if next_reactions.has(cell):
			return false
		next_reactions[cell] = float(row[2])
		validated_cooling += float(row[2])
		if not is_finite(validated_cooling) or validated_cooling > float(data["reacted_lava"]) + FLOW_TOLERANCE:
			return false
	for row: Variant in data["active"]:
		if not _valid_position_row(row, 2):
			return false
		var cell := Vector2i(int(row[0]), int(row[1]))
		if next_active.has(cell):
			return false
		next_active[cell] = true
		next_queue.append(cell)
	var changed: Dictionary = _volumes.duplicate()
	for cell: Vector2i in next_volumes:
		changed[cell] = true
	_types = next_types
	_volumes = next_volumes
	_reserved = next_reserved
	_reaction_progress = next_reactions
	_active = next_active
	_queue_head = 0
	_queue_count = next_queue.size()
	_queue_tail = _queue_count % _queue.size()
	for index: int in range(next_queue.size()):
		_queue[index] = next_queue[index]
	_tick = int(data["tick"])
	reacted_water_volume = float(data["reacted_water"])
	reacted_lava_volume = float(data["reacted_lava"])
	_changed = changed
	_emit_changes()
	return true


func _process_cell(cell: Vector2i, rate: float) -> void:
	_reconcile_blocked(cell)
	_release_reserve(cell)
	_finish_solidification(cell)
	if not _volumes.has(cell) or _is_blocked(cell):
		return
	for direction: Vector2i in DIRECTIONS:
		_react(cell, cell + direction, rate)
		if not _volumes.has(cell) or _is_blocked(cell):
			return
	_flow(cell, cell + Vector2i.DOWN, rate)
	var first: Vector2i = Vector2i.LEFT if (_tick + cell.x + cell.y) % 2 == 0 else Vector2i.RIGHT
	for direction: Vector2i in [first, -first]:
		var neighbor: Vector2i = cell + direction
		_flow(cell, neighbor, rate * 0.25, true)
	_flow_pressure(cell, rate * 0.25)


func _flow(source: Vector2i, target: Vector2i, limit: float, horizontal: bool = false) -> void:
	if not _volumes.has(source) or _is_blocked(target):
		return
	var liquid_id: int = int(_types[source])
	var target_id: int = get_liquid(target.x, target.y)
	if target_id != NONE and target_id != liquid_id:
		return
	var source_volume: float = float(_volumes[source])
	var target_volume: float = get_volume(target.x, target.y)
	var amount: float = minf(source_volume, minf(1.0 - target_volume, limit))
	if horizontal:
		amount = minf(amount, (source_volume - target_volume) * 0.5)
		if amount <= FLOW_TOLERANCE:
			return
	if amount <= 0.0:
		return
	_store(source, liquid_id, source_volume - amount)
	_store(target, liquid_id, target_volume + amount)


func _flow_pressure(root: Vector2i, limit: float) -> void:
	# Hydraulic head communicates along a connected saturated path, including
	# bent/roofed conduits. Only the donor and receiver change volume; the full
	# intervening cells transmit displacement rather than creating extra water.
	if get_volume(root.x, root.y) < 1.0 - FLOW_TOLERANCE or _pressure_visited.has(root):
		return
	if last_pressure_work >= MAX_PRESSURE_WORK_PER_STEP:
		_wake(root)
		return
	var liquid_id: int = get_liquid(root.x, root.y)
	if liquid_id == NONE:
		return
	var frontier: Array[Vector2i] = [root]
	var visited: Dictionary = {root: true}
	_pressure_visited[root] = true
	var donor: Vector2i = root
	var donor_surface: float = float(root.y + 1) - get_volume(root.x, root.y)
	var receiver := Vector2i(-1, -1)
	var receiver_surface: float = -INF
	var cursor: int = 0
	var capacity: int = mini(MAX_PRESSURE_CELLS, MAX_PRESSURE_WORK_PER_STEP - last_pressure_work)
	while cursor < frontier.size():
		var cell: Vector2i = frontier[cursor]
		cursor += 1
		last_pressure_work += 1
		var surface: float = float(cell.y + 1) - get_volume(cell.x, cell.y)
		if surface < donor_surface:
			donor = cell
			donor_surface = surface
		for direction: Vector2i in DIRECTIONS:
			var neighbor: Vector2i = cell + direction
			if _is_blocked(neighbor):
				continue
			var neighbor_id: int = get_liquid(neighbor.x, neighbor.y)
			if neighbor_id != NONE and neighbor_id != liquid_id:
				continue
			var volume: float = get_volume(neighbor.x, neighbor.y)
			if volume >= 1.0 - FLOW_TOLERANCE:
				if not visited.has(neighbor) and frontier.size() < capacity:
					visited[neighbor] = true
					_pressure_visited[neighbor] = true
					frontier.append(neighbor)
				continue
			var boundary_surface: float = float(neighbor.y + 1) - volume
			if volume > 0.0 and boundary_surface < donor_surface:
				donor = neighbor
				donor_surface = boundary_surface
			if boundary_surface > receiver_surface:
				receiver = neighbor
				receiver_surface = boundary_surface
	if not _valid(receiver) or receiver_surface - donor_surface <= FLOW_TOLERANCE:
		return
	var donor_volume: float = get_volume(donor.x, donor.y)
	var receiver_volume: float = get_volume(receiver.x, receiver.y)
	var amount: float = minf(limit, minf(donor_volume, minf(1.0 - receiver_volume, (receiver_surface - donor_surface) * 0.5)))
	if amount <= FLOW_TOLERANCE:
		return
	_store(donor, liquid_id, donor_volume - amount)
	_store(receiver, liquid_id, receiver_volume + amount)
	# Keep a bounded connected path awake while head is unequal, even when the
	# changed free surfaces are several corners away from the conduit root.
	for cell: Vector2i in frontier:
		_wake(cell)


func _react(first: Vector2i, second: Vector2i, rate: float) -> void:
	var first_id: int = get_liquid(first.x, first.y)
	var second_id: int = get_liquid(second.x, second.y)
	if first_id == NONE or second_id == NONE or first_id == second_id:
		return
	var amount: float = minf(rate, minf(get_volume(first.x, first.y), get_volume(second.x, second.y)))
	if amount <= 0.0:
		return
	var lava_cell: Vector2i = first if first_id == LAVA else second
	_store(first, first_id, get_volume(first.x, first.y) - amount)
	_store(second, second_id, get_volume(second.x, second.y) - amount)
	reacted_water_volume += amount
	reacted_lava_volume += amount
	_reaction_progress[lava_cell] = float(_reaction_progress.get(lava_cell, 0.0)) + amount
	_finish_solidification(lava_cell)


func _finish_solidification(cell: Vector2i) -> void:
	var cooled: float = float(_reaction_progress.get(cell, 0.0))
	if cooled < 1.0 - FLOW_TOLERANCE or get_liquid(cell.x, cell.y) == LAVA:
		return
	if _is_blocked(cell):
		return
	if cooled > 1.0 + FLOW_TOLERANCE:
		_reaction_progress[cell] = cooled - 1.0
	else:
		_reaction_progress.erase(cell)
	if world_grid != null:
		# A later water inflow is displaced into reserve by the local world
		# callback rather than erased when this pending deposit solidifies.
		world_grid.set_tile(cell.x, cell.y, WorldGrid.TILE_BASALT)
	solidified.emit(cell)


func _reconcile_blocked(cell: Vector2i) -> void:
	if _volumes.has(cell) and _is_blocked(cell):
		var liquid_id: int = int(_types[cell])
		var volume: float = float(_volumes[cell])
		_store(cell, NONE, 0.0)
		_reserve(cell, liquid_id, volume)


func _reserve(cell: Vector2i, liquid_id: int, volume: float) -> void:
	var entry: Dictionary = _reserved.get(cell, {})
	entry[liquid_id] = float(entry.get(liquid_id, 0.0)) + volume
	_reserved[cell] = entry
	_wake(cell)
	_changed[cell] = true


func _release_reserve(cell: Vector2i) -> void:
	if not _reserved.has(cell):
		return
	var entry: Dictionary = _reserved[cell]
	# Try the original location first, then only its cardinal neighbors. No
	# teleportation through enclosing rock, no unbounded displacement search.
	for liquid_id: int in [WATER, LAVA]:
		var remaining: float = float(entry.get(liquid_id, 0.0))
		if remaining <= 0.0:
			continue
		for direction: Vector2i in [Vector2i.ZERO, Vector2i.UP, Vector2i.LEFT, Vector2i.RIGHT, Vector2i.DOWN]:
			var target: Vector2i = cell + direction
			if _is_blocked(target):
				continue
			var target_id: int = get_liquid(target.x, target.y)
			if target_id != NONE and target_id != liquid_id:
				continue
			var volume: float = get_volume(target.x, target.y)
			var amount: float = minf(remaining, 1.0 - volume)
			if amount <= 0.0:
				continue
			_store(target, liquid_id, volume + amount)
			remaining -= amount
			if remaining <= 0.0:
				break
		if remaining > 0.0:
			entry[liquid_id] = remaining
		else:
			entry.erase(liquid_id)
	if entry.is_empty():
		_reserved.erase(cell)
	else:
		_reserved[cell] = entry


func _store(cell: Vector2i, liquid_id: int, volume: float) -> void:
	if volume <= 0.0 or liquid_id == NONE:
		if not _volumes.has(cell):
			return
		_volumes.erase(cell)
		_types.erase(cell)
	else:
		if get_liquid(cell.x, cell.y) == liquid_id and get_volume(cell.x, cell.y) == volume:
			return
		_types[cell] = liquid_id
		_volumes[cell] = volume
	_changed[cell] = true
	_wake_neighborhood(cell)


func _wake(cell: Vector2i) -> void:
	if not _valid(cell) or _active.has(cell):
		return
	if not _volumes.has(cell) and not _reserved.has(cell) and float(_reaction_progress.get(cell, 0.0)) < 1.0 - FLOW_TOLERANCE:
		return
	_active[cell] = true
	_queue[_queue_tail] = cell
	_queue_tail = (_queue_tail + 1) % _queue.size()
	_queue_count += 1


func _wake_neighborhood(cell: Vector2i) -> void:
	_wake(cell)
	for direction: Vector2i in DIRECTIONS:
		_wake(cell + direction)


func _on_world_tile_changed(cell: Vector2i, _tile_id: int) -> void:
	if not _valid(cell):
		return
	_reconcile_blocked(cell)
	_wake_neighborhood(cell)
	if not _stepping:
		_emit_changes()


func _valid(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.x < width and cell.y >= 0 and cell.y < height


func _is_blocked(cell: Vector2i) -> bool:
	return not _valid(cell) or _blocked.has(cell) or (world_grid != null and world_grid.is_solid(cell.x, cell.y))


func _emit_changes() -> void:
	if _changed.is_empty():
		return
	var cells: Array[Vector2i] = []
	for cell: Vector2i in _changed:
		cells.append(cell)
	_changed.clear()
	cells_changed.emit(cells)


func _sorted_keys(source: Dictionary) -> Array[Vector2i]:
	var cells: Array[Vector2i] = []
	for cell: Vector2i in source:
		cells.append(cell)
	cells.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.y < b.y or (a.y == b.y and a.x < b.x))
	return cells


func _valid_amount(value: Variant, allow_zero: bool) -> bool:
	if not (value is int or value is float):
		return false
	var amount: float = float(value)
	return is_finite(amount) and (amount >= 0.0 if allow_zero else amount > 0.0)


func _valid_position_row(row: Variant, size: int) -> bool:
	if not row is Array or row.size() != size or not row[0] is int or not row[1] is int:
		return false
	return _valid(Vector2i(int(row[0]), int(row[1])))


func _valid_liquid_row(row: Variant) -> bool:
	return _valid_position_row(row, 4) and row[2] is int and (int(row[2]) == WATER or int(row[2]) == LAVA) and _valid_amount(row[3], false)
