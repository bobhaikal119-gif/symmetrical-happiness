extends Node2D
class_name Main

## Composition only: pure services own generation, liquids, housing and gameplay rules.
signal game_started()
signal game_paused()
signal game_resumed()
signal game_over()

const LIQUID_TICK: float = 0.05
const MAX_LIQUID_SUBSTEPS: int = 4
@export var world_seed: int = 12345

@onready var world_renderer: WorldRenderer = $WorldRenderer as WorldRenderer
@onready var liquid_renderer: LiquidRenderer = $LiquidRenderer as LiquidRenderer
@onready var player: Player = $Player as Player
@onready var camera: Camera2D = $Camera2D as Camera2D
@onready var machine_container: Node2D = $MachineContainer as Node2D
@onready var enemy_container: Node2D = $EnemyContainer as Node2D
@onready var item_container: Node2D = $ItemContainer as Node2D
@onready var npc_container: Node2D = $NpcContainer as Node2D
@onready var storm_wave_director: StormWaveDirector = $StormWaveDirector as StormWaveDirector
@onready var canvas_modulate: CanvasModulate = $CanvasModulate as CanvasModulate
@onready var world_session: WorldSession = $WorldSession as WorldSession
@onready var housing_coordinator: HousingCoordinator = $HousingCoordinator as HousingCoordinator

var world_generator: WorldGenerator = WorldGenerator.new()
var world_grid: WorldGrid
var liquid_grid: LiquidGrid
var power_grid: PowerGridSystem
var structural_integrity: StructuralIntegritySystem
var _liquid_accumulator: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	process_priority = 100
	SettingsManager.active_world_seed = world_seed
	world_grid = WorldGrid.new(world_seed, TileRegistry.get_instance().get_simulation_catalog())
	liquid_grid = LiquidGrid.new(world_grid)
	power_grid = PowerGridSystem.new()
	structural_integrity = StructuralIntegritySystem.new(world_grid)
	world_session.game_started.connect(_on_session_started)
	world_session.game_paused.connect(_on_session_paused)
	world_session.game_resumed.connect(_on_session_resumed)
	world_session.game_over.connect(_on_session_game_over)
	world_session.configure(self)
	world_session.start_session()
	liquid_renderer.configure(liquid_grid)
	(player.get_node("SwimmingComponent") as SwimmingComponent).configure(player, liquid_grid)
	SaveManager.configure(world_grid, liquid_grid)
	housing_coordinator.configure(world_grid, machine_container, npc_container, player)

func _physics_process(delta: float) -> void:
	if liquid_grid == null or get_tree().paused or not is_finite(delta) or delta <= 0.0:
		return
	_liquid_accumulator = minf(_liquid_accumulator + delta, LIQUID_TICK * MAX_LIQUID_SUBSTEPS)
	var substeps: int = 0
	while _liquid_accumulator >= LIQUID_TICK and substeps < MAX_LIQUID_SUBSTEPS:
		liquid_grid.step(LIQUID_TICK)
		_liquid_accumulator -= LIQUID_TICK
		substeps += 1

func toggle_pause() -> void:
	world_session.toggle_pause()

func set_darkness_intensity(intensity: float) -> void:
	world_session.set_darkness_intensity(intensity)

func _on_session_started() -> void:
	game_started.emit()

func _on_session_paused() -> void:
	_liquid_accumulator = 0.0
	game_paused.emit()

func _on_session_resumed() -> void:
	_liquid_accumulator = 0.0
	game_resumed.emit()

func _on_session_game_over() -> void:
	game_over.emit()
