extends Node

class_name HazardDetectorComponent

"""Pure tile exposure detector; its owner decides how emitted damage is used."""

signal hazard_damage(amount: float, world_pos: Vector2)
signal hazard_entered(world_pos: Vector2)
signal hazard_exited(world_pos: Vector2)

@export var damage_rate: float = 5.0
@export var hazard_radius: float = 8.0

var world_grid: WorldGrid
var player_position: Vector2 = Vector2.ZERO
var _is_in_hazard: bool = false

func _process(delta: float) -> void:
	if world_grid == null:
		return
	var in_hazard: bool = _is_player_in_hazard()
	if in_hazard and not _is_in_hazard:
		_is_in_hazard = true
		hazard_entered.emit(player_position)
	elif not in_hazard and _is_in_hazard:
		_is_in_hazard = false
		hazard_exited.emit(player_position)
	if in_hazard:
		hazard_damage.emit(damage_rate * delta, player_position)

func _is_player_in_hazard() -> bool:
	var center := Vector2i(floori(player_position.x / WorldGrid.TILE_SIZE), floori(player_position.y / WorldGrid.TILE_SIZE))
	var radius_cells: int = maxi(0, ceili(hazard_radius / WorldGrid.TILE_SIZE))
	for y in range(center.y - radius_cells, center.y + radius_cells + 1):
		for x in range(center.x - radius_cells, center.x + radius_cells + 1):
			var tile_id: int = world_grid.get_tile(x, y)
			if tile_id == WorldGrid.TILE_LAVA or tile_id == WorldGrid.TILE_ACID:
				return true
	return false

func get_is_in_hazard() -> bool:
	return _is_in_hazard
