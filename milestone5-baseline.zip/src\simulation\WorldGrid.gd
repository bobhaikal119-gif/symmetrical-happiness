extends RefCounted

class_name WorldGrid

## Authoritative, scene-independent foreground/background value grid.
## Scene adapters subscribe to these local signals; simulation never dispatches globally.
signal tile_damaged(cell: Vector2i, current: float, maximum: float)
signal tile_broken(cell: Vector2i, tile_id: int)
signal tile_placed(cell: Vector2i, tile_id: int)
signal background_wall_changed(cell: Vector2i, tile_id: int)

const GRID_SIZE: int = 512
const TILE_SIZE: int = 16
const TILE_AIR: int = 0
const TILE_SNOW: int = 1
const TILE_DIRT: int = 2
const TILE_STONE: int = 3
const TILE_IRON_ORE: int = 4
const TILE_COAL: int = 5
const TILE_COPPER: int = 6
const TILE_QUARTZ: int = 7
const TILE_TITANIUM: int = 8
const TILE_BIOLUME_STONE: int = 9
const TILE_BASALT: int = 10
const TILE_LAVA: int = 11
const TILE_ACID: int = 12
const TILE_SUPPORT_BEAM: int = 13
const TILE_POWER_CABLE: int = 14
const TILE_HULL_WALL: int = 15
const TILE_STEEL_PLATE: int = 16
const TILE_REINFORCED_GLASS: int = 17
const BIOME_SURFACE_MAX: int = 63
const BIOME_CRUST_MAX: int = 191
const BIOME_BIOLUME_MAX: int = 319

var grid: Array = []
var tile_hp: Array = []
var background_walls: Array = []
var seed: int = 0
var _tile_catalog: Dictionary = {}
var _power_cable_positions: Dictionary = {}


func _init(seed_val: int = 0, tile_catalog: Dictionary = {}) -> void:
	seed = seed_val
	configure_tile_catalog(tile_catalog)
	initialize_grid()
	generate_strata()


func configure_tile_catalog(catalog: Dictionary) -> void:
	# Complete fallback keeps standalone simulation tests independent of autoloads.
	const HEALTH: Array[float] = [0.0, 0.5, 2.0, 10.0, 3.0, 2.5, 2.5, 1.5, 8.0, 4.0, 15.0, 0.0, 0.0, 5.0, 3.0, 10.0, 20.0, 12.0]
	_tile_catalog.clear()
	for tile_id: int in range(HEALTH.size()):
		_tile_catalog[tile_id] = {
			"max_hp": HEALTH[tile_id],
			"solid": (tile_id >= TILE_SNOW and tile_id <= TILE_BASALT) or tile_id == TILE_STEEL_PLATE or tile_id == TILE_REINFORCED_GLASS,
			"hazard": tile_id == TILE_LAVA or tile_id == TILE_ACID,
		}
	for key: Variant in catalog:
		if not key is int or not catalog[key] is Dictionary:
			continue
		var definition: Dictionary = catalog[key]
		_tile_catalog[int(key)] = {
			"max_hp": maxf(0.0, float(definition.get("max_hp", 0.0))),
			"solid": bool(definition.get("solid", false)),
			"hazard": bool(definition.get("hazard", false)),
		}


func initialize_grid() -> void:
	grid.clear()
	tile_hp.clear()
	background_walls.clear()
	_power_cable_positions.clear()
	for _y: int in range(GRID_SIZE):
		var row: Array[int] = []
		var hp_row: Array[float] = []
		var background_row: Array[int] = []
		row.resize(GRID_SIZE)
		row.fill(TILE_AIR)
		hp_row.resize(GRID_SIZE)
		hp_row.fill(0.0)
		background_row.resize(GRID_SIZE)
		background_row.fill(TILE_AIR)
		grid.append(row)
		tile_hp.append(hp_row)
		background_walls.append(background_row)


func generate_strata() -> void:
	_power_cable_positions.clear()
	for y: int in range(GRID_SIZE):
		var tile_id: int = get_tile_id_at_depth(y)
		var maximum: float = get_tile_max_hp(tile_id)
		for x: int in range(GRID_SIZE):
			grid[y][x] = tile_id
			tile_hp[y][x] = maximum


func get_tile(x: int, y: int) -> int:
	return int(grid[y][x]) if is_valid_position(x, y) else TILE_AIR


func set_tile(x: int, y: int, tile_id: int) -> void:
	if not is_valid_position(x, y) or not _tile_catalog.has(tile_id):
		return
	var cell := Vector2i(x, y)
	var maximum: float = get_tile_max_hp(tile_id)
	if int(grid[y][x]) == tile_id and is_equal_approx(float(tile_hp[y][x]), maximum):
		return
	_power_cable_positions.erase(cell)
	if tile_id == TILE_POWER_CABLE:
		_power_cable_positions[cell] = true
	grid[y][x] = tile_id
	tile_hp[y][x] = maximum
	tile_placed.emit(cell, tile_id)


func get_background_wall(x: int, y: int) -> int:
	return int(background_walls[y][x]) if is_valid_position(x, y) else TILE_AIR


func set_background_wall(x: int, y: int, tile_id: int) -> void:
	if not is_valid_position(x, y) or not _tile_catalog.has(tile_id):
		return
	if int(background_walls[y][x]) == tile_id:
		return
	background_walls[y][x] = tile_id
	background_wall_changed.emit(Vector2i(x, y), tile_id)


func get_tile_max_hp(tile_id: int) -> float:
	var definition: Dictionary = _tile_catalog.get(tile_id, {})
	return float(definition.get("max_hp", 0.0))


func is_solid(x: int, y: int) -> bool:
	var definition: Dictionary = _tile_catalog.get(get_tile(x, y), {})
	return bool(definition.get("solid", false))


func is_hazard(x: int, y: int) -> bool:
	var definition: Dictionary = _tile_catalog.get(get_tile(x, y), {})
	return bool(definition.get("hazard", false))


func damage_tile(x: int, y: int, damage: float) -> bool:
	if not is_valid_position(x, y) or not is_finite(damage) or damage <= 0.0:
		return false
	var tile_id: int = get_tile(x, y)
	var maximum: float = get_tile_max_hp(tile_id)
	if tile_id == TILE_AIR or is_hazard(x, y) or maximum <= 0.0:
		return false
	tile_hp[y][x] = maxf(0.0, float(tile_hp[y][x]) - damage)
	if float(tile_hp[y][x]) <= 0.0:
		break_tile(x, y)
		tile_broken.emit(Vector2i(x, y), tile_id)
		return true
	tile_damaged.emit(Vector2i(x, y), float(tile_hp[y][x]), maximum)
	return false


func break_tile(x: int, y: int) -> void:
	if not is_valid_position(x, y):
		return
	var previous: int = get_tile(x, y)
	if previous == TILE_AIR:
		return
	# Settlement/automation removals update visuals, but do not mint mined rewards.
	# Only damage_tile emits tile_broken after a successful player-style break.
	set_tile(x, y, TILE_AIR)


func is_power_cable(position_or_x: Variant, y: int = -1) -> bool:
	var cell: Vector2i
	if position_or_x is Vector2i:
		cell = position_or_x
	elif position_or_x is int:
		cell = Vector2i(int(position_or_x), y)
	else:
		return false
	return _power_cable_positions.has(cell)


func get_power_cable_positions() -> Array[Vector2i]:
	var positions: Array[Vector2i] = []
	for cell: Vector2i in _power_cable_positions:
		positions.append(cell)
	return positions


func is_valid_position(x: int, y: int) -> bool:
	return x >= 0 and x < GRID_SIZE and y >= 0 and y < GRID_SIZE


func find_safe_spawn() -> Vector2:
	var center_x: int = GRID_SIZE / 2
	for offset: int in range(0, GRID_SIZE / 2, 4):
		for x: int in [center_x + offset, center_x - offset]:
			if x < 0 or x >= GRID_SIZE:
				continue
			for y: int in range(64):
				if is_solid(x, y):
					return Vector2(float(x * TILE_SIZE) + TILE_SIZE * 0.5, float(maxi(0, y - 1) * TILE_SIZE) + TILE_SIZE * 0.5)
	return Vector2(float(center_x * TILE_SIZE), 0.0)


func get_depth_at(_x: int, y: int) -> int:
	return y


func get_biome_at_depth(depth: int) -> String:
	if depth <= BIOME_SURFACE_MAX:
		return "Permafrost Surface"
	if depth <= BIOME_CRUST_MAX:
		return "Shattered Crust"
	if depth <= BIOME_BIOLUME_MAX:
		return "Fungal Biolume Depths"
	return "Magma Faultline"


func get_tile_id_at_depth(depth: int) -> int:
	if depth <= BIOME_SURFACE_MAX:
		return TILE_SNOW
	if depth < 96:
		return TILE_DIRT
	if depth <= BIOME_BIOLUME_MAX:
		return TILE_STONE
	return TILE_BASALT
