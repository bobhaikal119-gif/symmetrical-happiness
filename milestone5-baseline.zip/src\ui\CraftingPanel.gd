extends CanvasLayer
class_name CraftingPanel

## Signal/snapshot-only view: no actor, simulation or world-node references.
var is_open: bool = false
var signal_bus: SignalBus
var recipe_registry: RecipeRegistry
var _inventory: Dictionary = {}
var _stations: Array[String] = ["hand"]
var _category: String = "All"
var _rows: Dictionary = {}
var _category_buttons: Dictionary = {}
var _overlay: Control
var _window: PanelContainer
var recipe_list: VBoxContainer
var status_label: Label
var _station_label: Label
var _close_button: Button
var _layout_queued: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 45
	signal_bus = SignalBus.get_instance()
	recipe_registry = RecipeRegistry.get_instance()
	_build_view()
	signal_bus.crafting_menu_toggled.connect(_on_crafting_menu_toggled)
	signal_bus.inventory_updated.connect(_on_inventory_updated)
	signal_bus.nearby_stations_changed.connect(_on_stations_changed)
	signal_bus.craft_completed.connect(_on_craft_completed)
	signal_bus.trade_completed.connect(_on_item_use_result)
	get_viewport().size_changed.connect(_resize_window)
	_window.minimum_size_changed.connect(_queue_layout)
	_rebuild_recipes()
	_resize_window()
	visible = false

func _unhandled_input(event: InputEvent) -> void:
	if SettingsManager.settings_menu_open or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if event.is_action_pressed("toggle_crafting"):
		AntiSlopTheme._emit_click()
		set_open(not is_open)
		get_viewport().set_input_as_handled()

func set_open(open: bool) -> void:
	if is_open != open:
		signal_bus.crafting_menu_toggled.emit(open)

func _on_crafting_menu_toggled(open: bool) -> void:
	if is_open == open:
		return
	is_open = open
	visible = open
	if open:
		signal_bus.shop_toggled.emit(false, "")
		status_label.text = "Select a blueprint. Owned building outputs can be selected for placement."
		signal_bus.inventory_snapshot_requested.emit()
		_refresh_rows()
		_resize_window()
		_close_button.grab_focus()

func _build_view() -> void:
	_overlay = Control.new()
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_overlay)
	_window = PanelContainer.new()
	_overlay.add_child(_window)
	var content := VBoxContainer.new()
	_window.add_child(content)
	var header := PanelContainer.new()
	header.theme_type_variation = &"HeaderPanel"
	content.add_child(header)
	var title_row := HBoxContainer.new()
	header.add_child(title_row)
	var title := Label.new()
	title.text = "FIELD FABRICATOR"
	title.theme_type_variation = &"HeaderLabel"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(title)
	_close_button = _button("[X]", _close_panel)
	_close_button.theme_type_variation = &"HeaderButton"
	_close_button.tooltip_text = "Close fabricator"
	title_row.add_child(_close_button)
	_station_label = Label.new()
	_station_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(_station_label)
	var categories := HFlowContainer.new()
	content.add_child(categories)
	var names: Array[String] = ["All"]
	for recipe: RecipeDef in recipe_registry.get_all_recipes():
		if not names.has(recipe.category):
			names.append(recipe.category)
	for category: String in names:
		var button: Button = _button(category, _select_category.bind(category))
		button.theme_type_variation = &"CategoryButton"
		button.toggle_mode = true
		categories.add_child(button)
		_category_buttons[category] = button
	var scroll := ScrollContainer.new()
	scroll.follow_focus = false
	scroll.custom_minimum_size.y = 240.0
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.add_child(scroll)
	recipe_list = VBoxContainer.new()
	recipe_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(recipe_list)
	status_label = Label.new()
	status_label.custom_minimum_size.y = 48.0
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(status_label)
	AntiSlopTheme.apply_to(_overlay)

func _queue_layout() -> void:
	if not _layout_queued:
		_layout_queued = true
		call_deferred("_resize_window")

func _resize_window() -> void:
	_layout_queued = false
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	_window.size = Vector2(minf(960.0, viewport_size.x - 32.0), minf(656.0, viewport_size.y - 32.0))
	_window.position = ((viewport_size - _window.size) * 0.5).floor()

func _select_category(category: String) -> void:
	_category = category
	_rebuild_recipes()

func _rebuild_recipes() -> void:
	for child: Node in recipe_list.get_children():
		recipe_list.remove_child(child)
		child.queue_free()
	_rows.clear()
	for category: String in _category_buttons:
		(_category_buttons[category] as Button).set_pressed_no_signal(category == _category)
	for recipe: RecipeDef in recipe_registry.get_all_recipes():
		if _category != "All" and recipe.category != _category:
			continue
		var definition: ItemDef = ItemRegistry.get_instance().get_item_def(recipe.output_item_id)
		if definition == null:
			continue
		var frame := PanelContainer.new()
		frame.theme_type_variation = &"InsetPanel"
		recipe_list.add_child(frame)
		var column := VBoxContainer.new()
		frame.add_child(column)
		var row := HBoxContainer.new()
		column.add_child(row)
		var output: Button = _button("%s  x%d" % [definition.display_name, recipe.output_count], _activate_output.bind(definition.id))
		output.theme_type_variation = &"SlotButton"
		output.icon = ProceduralItemIcons.get_instance().get_item_icon_texture(definition.id)
		output.add_theme_constant_override("icon_max_width", 32)
		output.add_theme_constant_override("h_separation", 8)
		output.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		output.alignment = HORIZONTAL_ALIGNMENT_LEFT
		output.clip_text = true
		output.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		row.add_child(output)
		var owned := Label.new()
		owned.custom_minimum_size.x = 112.0
		owned.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(owned)
		var craft: Button = _button("CRAFT", _request_craft.bind(recipe.id))
		craft.custom_minimum_size.x = 112.0
		row.add_child(craft)
		var ingredients := Label.new()
		ingredients.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		column.add_child(ingredients)
		var availability := Label.new()
		availability.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		column.add_child(availability)
		_rows[recipe.id] = {"recipe": recipe, "definition": definition, "output": output, "owned": owned, "craft": craft, "ingredients": ingredients, "availability": availability}
	if _rows.is_empty():
		var empty := Label.new()
		empty.text = "No blueprints in this category. Select All to inspect the catalog."
		recipe_list.add_child(empty)
	_refresh_rows()
	call_deferred("_resize_window")

func _refresh_rows() -> void:
	var station_parts: PackedStringArray = []
	var station_names: Array[String] = ["hand"]
	for recipe: RecipeDef in recipe_registry.get_all_recipes():
		if not station_names.has(recipe.station_required):
			station_names.append(recipe.station_required)
	for station: String in station_names:
		station_parts.append("[%s %s]" % [station.to_upper(), "READY" if _stations.has(station) else "OUT OF RANGE"])
	_station_label.text = "STATIONS  " + "  ".join(station_parts)
	for entry: Dictionary in _rows.values():
		var recipe: RecipeDef = entry["recipe"] as RecipeDef
		var definition: ItemDef = entry["definition"] as ItemDef
		var enough: bool = true
		var parts: PackedStringArray = []
		for ingredient: String in recipe.ingredients:
			var required: int = int(recipe.ingredients[ingredient])
			var available: int = int(_inventory.get(ingredient, 0))
			enough = enough and available >= required
			parts.append("%s %d/%d" % [ItemRegistry.get_instance().get_item_name(ingredient), available, required])
		(entry["ingredients"] as Label).text = "MATERIALS  " + "   |   ".join(parts)
		var station_ready: bool = _stations.has(recipe.station_required)
		var reason: String = "Ready to craft" if enough else "Missing materials: collect or refine the listed ingredients"
		if not station_ready:
			reason = "Requires nearby %s (within station range)" % recipe.station_required.capitalize()
		(entry["availability"] as Label).text = "%s  /  %s" % [recipe.category.to_upper(), reason]
		var craft: Button = entry["craft"] as Button
		craft.disabled = not enough or not station_ready
		craft.tooltip_text = reason
		var count: int = int(_inventory.get(definition.id, 0))
		var equipped: bool = count > 0 and not definition.equipment_slot.is_empty()
		(entry["owned"] as Label).text = "EQUIPPED" if equipped else "%d OWNED" % count
		var output: Button = entry["output"] as Button
		var placeable: bool = definition.place_layer in ["foreground", "background_wall", "structure"]
		output.disabled = count <= 0 or (not placeable and not definition.is_consumable)
		var instruction: String = "Passive equipment: active while carried; duplicate copies do not stack." if equipped else ("Select owned item for placement" if placeable else ("Use one owned item / install upgrade" if definition.is_consumable else "Crafting material; not placeable"))
		output.tooltip_text = "%s\n%s" % [definition.description, instruction]

func _on_inventory_updated(inventory: Dictionary) -> void:
	_inventory = inventory.duplicate(true)
	_refresh_rows()

func _on_stations_changed(stations: Array[String]) -> void:
	_stations = stations.duplicate()
	if not _stations.has("hand"):
		_stations.append("hand")
	_refresh_rows()

func _request_craft(recipe_id: String) -> void:
	status_label.text = "Submitting blueprint..."
	signal_bus.craft_requested.emit(recipe_id)

func _activate_output(item_id: String) -> void:
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if definition == null or int(_inventory.get(item_id, 0)) < 1:
		return
	if definition.place_layer in ["foreground", "background_wall", "structure"]:
		signal_bus.building_item_selected.emit(item_id)
		signal_bus.show_hud_hint.emit("Selected %s for placement." % definition.display_name)
		set_open(false)
	elif definition.is_consumable:
		signal_bus.item_use_requested.emit(item_id)

func _on_craft_completed(recipe_id: String, success: bool) -> void:
	var recipe: RecipeDef = recipe_registry.get_recipe(recipe_id)
	var item_name: String = ItemRegistry.get_instance().get_item_name(recipe.output_item_id) if recipe != null else recipe_id
	status_label.text = "Crafted %s. Select its owned output to place or use it." % item_name if success else "Craft rejected: missing materials or required station is unavailable."
	_refresh_rows()

func _on_item_use_result(_success: bool, message: String) -> void:
	if is_open:
		status_label.text = message

func _close_panel() -> void:
	set_open(false)

func _button(text: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 40.0
	AntiSlopTheme.wire_button(button)
	button.pressed.connect(callback)
	return button
