extends CanvasLayer
class_name AimCrosshair

## Screen-space presentation only: input + value telemetry, never actor/world references.
const INK: Color = Color("0e1018")
const CYAN: Color = Color("38bdf8")
const AMBER: Color = Color("f59e0b")
const CRIMSON: Color = Color("ef4444")
const STATE_COLORS: Array[Color] = [CYAN, AMBER, CRIMSON]
const TICK_DIRECTIONS: Array[Vector2] = [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]

@onready var _pointer: Node2D = $Pointer
var _ticks: Array[Sprite2D] = []
var _center: Sprite2D
var _reach_arc: Sprite2D
var _horizontal_textures: Array[ImageTexture] = []
var _vertical_textures: Array[ImageTexture] = []
var _center_textures: Array[ImageTexture] = []
var _arc_textures: Array[ImageTexture] = []
var _smoothing: float = 0.0
var _pointer_position: Vector2 = Vector2.ZERO
var _spread_target: float = 0.0
var _spread: float = 0.0
var _in_reach: bool = true
var _smart_locked: bool = false
var _active: bool = false
var _initialized: bool = false
var _window_focused: bool = false
var _mouse_inside: bool = true
var _state: int = -1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_pointer.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_pointer.hide()
	_build_sprites()
	_smoothing = clampf(float(SettingsManager.get_setting("mouse", "aim_smoothing", 0.0)), 0.0, 1.0)
	var bus: SignalBus = SignalBus.get_instance()
	bus.aim_telemetry_updated.connect(_on_aim_telemetry_updated)
	bus.setting_changed.connect(_on_setting_changed)
	bus.settings_menu_toggled.connect(_on_modal_toggled)
	bus.crafting_menu_toggled.connect(_on_modal_toggled)
	bus.shop_toggled.connect(_on_shop_toggled)
	get_window().focus_entered.connect(_on_focus_entered)
	get_window().focus_exited.connect(_on_focus_exited)
	_window_focused = get_window().has_focus()
	_sync_activity()


func _process(delta: float) -> void:
	_sync_activity()
	if not _active:
		return
	var desired: Vector2 = get_viewport().get_mouse_position()
	if not _initialized or _smoothing <= 0.0:
		_pointer_position = desired
		_initialized = true
	else:
		var response: float = lerpf(32.0, 5.0, _smoothing)
		_pointer_position = _pointer_position.lerp(desired, 1.0 - exp(-response * maxf(delta, 0.0)))
	_pointer.position = _pointer_position.floor()
	_spread = lerpf(_spread, _spread_target, 1.0 - exp(-24.0 * maxf(delta, 0.0)))
	var gap: float = roundf(6.0 + _spread * 9.0)
	for index: int in range(_ticks.size()):
		_ticks[index].position = TICK_DIRECTIONS[index] * gap
	_update_state()


func is_active() -> bool:
	return _active


func get_spread() -> float:
	return _spread


func get_pointer_position() -> Vector2:
	return _pointer.position


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_window_focused = false
		_set_active(false)
	elif what == NOTIFICATION_WM_MOUSE_EXIT:
		_mouse_inside = false
		_set_active(false)
	elif what == NOTIFICATION_WM_MOUSE_ENTER:
		_mouse_inside = true


func _exit_tree() -> void:
	# Never strand a hidden native pointer when changing/reloading scenes.
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _sync_activity() -> void:
	# Deferred modal-close callbacks may arrive after a scene was detached during
	# Reset Session; never query its former viewport/window in that interval.
	if not is_inside_tree() or is_queued_for_deletion() or get_viewport() == null:
		_set_active(false)
		return
	var pointer_inside: bool = _mouse_inside and get_viewport().get_visible_rect().has_point(get_viewport().get_mouse_position())
	_set_active(_window_focused and get_window().has_focus() and pointer_inside and not get_tree().paused and not SettingsManager.is_gameplay_input_blocked())


func _set_active(enabled: bool) -> void:
	if is_instance_valid(_pointer):
		_pointer.visible = enabled
	if _active != enabled:
		_initialized = false
		if enabled and is_instance_valid(_pointer):
			_pointer_position = get_viewport().get_mouse_position()
			_pointer.position = _pointer_position.floor()
	_active = enabled
	var required_mode: Input.MouseMode = Input.MOUSE_MODE_HIDDEN if enabled else Input.MOUSE_MODE_VISIBLE
	if Input.mouse_mode != required_mode:
		Input.mouse_mode = required_mode


func _on_focus_entered() -> void:
	_window_focused = true
	_mouse_inside = true
	_sync_activity()


func _on_focus_exited() -> void:
	_window_focused = false
	_set_active(false)


func _on_modal_toggled(open: bool) -> void:
	if open:
		_set_active(false)
	else:
		call_deferred("_sync_activity")


func _on_shop_toggled(open: bool, _npc_name: String) -> void:
	_on_modal_toggled(open)


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section == "mouse" and key == "aim_smoothing":
		var requested: float = float(value)
		_smoothing = clampf(requested, 0.0, 1.0) if is_finite(requested) else 0.0


func _on_aim_telemetry_updated(spread_ratio: float, in_reach: bool, smart_locked: bool) -> void:
	_spread_target = clampf(spread_ratio, 0.0, 1.0) if is_finite(spread_ratio) else 0.0
	_in_reach = in_reach
	_smart_locked = smart_locked
	_update_state()


func _build_sprites() -> void:
	for index: int in range(STATE_COLORS.size()):
		var color: Color = STATE_COLORS[index]
		_horizontal_textures.append(_tick_texture(false, color))
		_vertical_textures.append(_tick_texture(true, color))
		var image: Image = Image.create(3, 3, false, Image.FORMAT_RGBA8)
		image.fill(INK)
		image.set_pixel(1, 1, color)
		_center_textures.append(ImageTexture.create_from_image(image))
		_arc_textures.append(_arc_texture(color, index != 2))
	_reach_arc = Sprite2D.new()
	_reach_arc.name = "ReachArc"
	_pointer.add_child(_reach_arc)
	_center = Sprite2D.new()
	_center.name = "CenterPixel"
	_pointer.add_child(_center)
	for index: int in range(TICK_DIRECTIONS.size()):
		var tick := Sprite2D.new()
		tick.name = "Tick%d" % index
		tick.position = TICK_DIRECTIONS[index] * 6.0
		_pointer.add_child(tick)
		_ticks.append(tick)
	_update_state()


func _update_state() -> void:
	var next_state: int = 2 if not _in_reach else (1 if _smart_locked else 0)
	if next_state == _state or _ticks.size() != 4:
		return
	_state = next_state
	_center.texture = _center_textures[_state]
	_reach_arc.texture = _arc_textures[_state]
	for index: int in range(_ticks.size()):
		_ticks[index].texture = _horizontal_textures[_state] if index < 2 else _vertical_textures[_state]


func _tick_texture(vertical: bool, color: Color) -> ImageTexture:
	var image: Image = Image.create(5 if vertical else 7, 7 if vertical else 5, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	image.fill_rect(Rect2i(1, 0, 3, 7) if vertical else Rect2i(0, 1, 7, 3), INK)
	image.fill_rect(Rect2i(2, 1, 1, 5) if vertical else Rect2i(1, 2, 5, 1), color)
	return ImageTexture.create_from_image(image)


func _arc_texture(color: Color, reachable: bool) -> ImageTexture:
	var image: Image = Image.create(49, 49, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var points: Array[Vector2i] = []
	# A continuous 270-degree reach arc becomes a short broken warning arc out of reach.
	for degree: int in range(-135, 136):
		if not reachable and (absi(degree) > 45 or posmod(degree, 24) >= 14):
			continue
		var angle: float = deg_to_rad(float(degree))
		var point := Vector2i(roundi(cos(angle) * 22.0) + 24, roundi(sin(angle) * 22.0) + 24)
		points.append(point)
		image.fill_rect(Rect2i(point - Vector2i.ONE, Vector2i(3, 3)), INK)
	for point: Vector2i in points:
		image.set_pixelv(point, color)
	return ImageTexture.create_from_image(image)
