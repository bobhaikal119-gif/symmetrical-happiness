extends Node
class_name SwimmingComponent

## Liquid movement strategy. Player only chooses this strategy or its unchanged land one.
@export var swim_acceleration: float = 620.0
@export var swim_speed: float = 135.0
@export var liquid_gravity: float = 980.0
@export var buoyancy_multiplier: float = 1.15
@export var water_drag: float = 4.0
@export var head_offset: Vector2 = Vector2(0.0, -6.0)
@export var feet_offset: Vector2 = Vector2(0.0, 9.0)

var liquid_grid: LiquidGrid
var actor: CharacterBody2D
var head_submerged: bool = false
var submersion_ratio: float = 0.0
var in_liquid: bool = false
var liquid_id: int = 0
var _oxygen: OxygenComponent
var _thermal: ThermalComponent
var _bus: SignalBus
var _immersion: float = 0.0
var _body_liquid_id: int = 0
var _lava_immersion: float = 0.0
var _last_head: bool = false
var _last_depth: float = -1.0
var _last_liquid_id: int = 0

func _ready() -> void:
	_bus = SignalBus.get_instance()
	if actor == null:
		_bind_actor(get_parent() as CharacterBody2D)
	refresh_submersion()

func configure(owner_actor: CharacterBody2D, grid: LiquidGrid) -> void:
	_bind_actor(owner_actor)
	liquid_grid = grid
	_bus = SignalBus.get_instance()
	refresh_submersion()

func _bind_actor(owner_actor: CharacterBody2D) -> void:
	actor = owner_actor
	if actor == null:
		_oxygen = null
		_thermal = null
		return
	_oxygen = actor.get_node_or_null("OxygenComponent") as OxygenComponent
	_thermal = actor.get_node_or_null("ThermalComponent") as ThermalComponent

func refresh_submersion() -> void:
	var was_in_liquid: bool = in_liquid
	var previous_liquid: int = _last_liquid_id
	var torso_depth: float = 0.0
	var head_depth: float = 0.0
	var feet_depth: float = 0.0
	var torso_liquid: int = 0
	var head_liquid: int = 0
	var feet_liquid: int = 0
	_immersion = 0.0
	_body_liquid_id = LiquidGrid.NONE
	_lava_immersion = 0.0
	if actor != null and liquid_grid != null:
		var position: Vector2 = actor.global_position
		torso_depth = liquid_grid.sample_submersion(position)
		head_depth = liquid_grid.sample_submersion(position + head_offset)
		feet_depth = liquid_grid.sample_submersion(position + feet_offset)
		torso_liquid = _wet_liquid(position, torso_depth)
		head_liquid = _wet_liquid(position + head_offset, head_depth)
		feet_liquid = _wet_liquid(position + feet_offset, feet_depth)
		_immersion = _body_submersion(position)
	head_submerged = head_liquid != 0
	# Normalized head-to-feet body coverage: a fully immersed body is always1,
	# independent of the local tile penetration returned by point sampling.
	submersion_ratio = _immersion
	in_liquid = submersion_ratio > 0.00001 or torso_liquid != 0 or head_liquid != 0 or feet_liquid != 0
	liquid_id = torso_liquid if torso_liquid != 0 else (feet_liquid if feet_liquid != 0 else (head_liquid if head_liquid != 0 else _body_liquid_id))
	if _oxygen != null:
		_oxygen.set_submersion(head_submerged, submersion_ratio)
	if _thermal != null:
		# Water chills only with a wet torso, scaled by normalized body coverage.
		# Even a boot in lava is dangerous; cold-water insulation is not armor.
		var exposure_type: int = torso_liquid
		var exposure: float = submersion_ratio if torso_liquid != LiquidGrid.NONE else 0.0
		if _lava_immersion > 0.0 or head_liquid == LiquidGrid.LAVA or feet_liquid == LiquidGrid.LAVA or torso_liquid == LiquidGrid.LAVA:
			exposure_type = LiquidGrid.LAVA
			exposure = maxf(0.15, _lava_immersion)
		_thermal.set_liquid_exposure(exposure_type, exposure)
	if _bus != null:
		if head_submerged != _last_head or absf(submersion_ratio - _last_depth) >= 0.025 or (submersion_ratio == 0.0 and _last_depth != 0.0):
			_bus.player_submerged_changed.emit(head_submerged, submersion_ratio)
			_last_head = head_submerged
			_last_depth = submersion_ratio
		if actor != null and in_liquid != was_in_liquid:
			var splash_type: int = liquid_id if in_liquid else previous_liquid
			var intensity: float = clampf(actor.velocity.length() / 220.0, 0.15, 1.0)
			_bus.liquid_splashed.emit(actor.global_position, splash_type, intensity)
	_last_liquid_id = liquid_id

func _body_submersion(position: Vector2) -> float:
	# Integrate actual bottom-filled liquid overlap along the body column. At
	# default height this touches at most three cells; no quantized probe jitter.
	var top: float = position.y + head_offset.y
	var bottom: float = position.y + feet_offset.y
	var body_height: float = maxf(0.001, bottom - top)
	var x: int = floori(position.x / WorldGrid.TILE_SIZE)
	var immersed_height: float = 0.0
	for y: int in range(floori(top / WorldGrid.TILE_SIZE), floori(bottom / WorldGrid.TILE_SIZE) + 1):
		var cell_liquid: int = liquid_grid.get_liquid(x, y)
		if cell_liquid == LiquidGrid.NONE:
			continue
		var cell_bottom: float = float((y + 1) * WorldGrid.TILE_SIZE)
		var liquid_top: float = cell_bottom - liquid_grid.get_volume(x, y) * WorldGrid.TILE_SIZE
		var overlap: float = maxf(0.0, minf(bottom, cell_bottom) - maxf(top, liquid_top))
		immersed_height += overlap
		if overlap > 0.0:
			_body_liquid_id = cell_liquid
			if cell_liquid == LiquidGrid.LAVA:
				_lava_immersion += overlap / body_height
	return clampf(immersed_height / body_height, 0.0, 1.0)

func _wet_liquid(position: Vector2, depth: float) -> int:
	if depth <= 0.00001:
		return LiquidGrid.NONE
	return liquid_grid.get_liquid(floori(position.x / WorldGrid.TILE_SIZE), floori(position.y / WorldGrid.TILE_SIZE))

func apply_swimming(delta: float, current_velocity: Vector2, input_vector: Vector2) -> Vector2:
	if not in_liquid or delta <= 0.0:
		return current_velocity
	var direction: Vector2 = input_vector.limit_length(1.0)
	# Jump remains a remappable upward stroke; W/S and A/D support every heading.
	if Input.is_action_pressed("jump"):
		direction.y = -1.0
		direction = direction.limit_length(1.0)
	var coverage: float = clampf(_immersion, 0.125, 1.0)
	var viscosity: float = 1.65 if liquid_id == 2 else 1.0
	var result: Vector2 = current_velocity
	result.y += liquid_gravity * (1.0 - buoyancy_multiplier * coverage) * delta
	# A deliberate upward stroke can break the surface even when only the boots
	# remain wet; otherwise partial immersion would trap Jump under full gravity.
	result.y -= liquid_gravity * (1.0 - coverage) * maxf(0.0, -direction.y) * delta
	result += direction * swim_acceleration * delta / viscosity
	result *= exp(-water_drag * viscosity * coverage * delta)
	return result.limit_length(swim_speed)
