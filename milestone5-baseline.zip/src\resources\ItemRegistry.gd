extends Node
class_name ItemRegistry

## Authoritative item definitions. Compatibility dictionary access is read-only.
static var _instance: ItemRegistry
var items: Dictionary = {}
var definitions: Dictionary = {}

static func get_instance() -> ItemRegistry:
	if not is_instance_valid(_instance):
		_instance = ItemRegistry.new()
		_instance._initialize_items()
	return _instance

func _initialize_items() -> void:
	items.clear()
	definitions.clear()
	# name, stack, palette, description, value, layer, metadata
	_register("stone", "Stone", 999, "78808a", "Common structural stone.", 1, "foreground", {"tile_id": 3, "sellable": true})
	_register("coal", "Coal", 999, "39414d", "Smelter and generator fuel.", 3, "consumable", {"sellable": true})
	_register("copper_ore", "Copper Ore", 999, "d58b52", "Unrefined conductive ore.", 5, "consumable", {"sellable": true})
	_register("iron_ore", "Iron Ore", 999, "b78e6b", "Unrefined structural ore.", 6, "consumable", {"sellable": true})
	_register("quartz", "Quartz", 999, "c4ebf0", "Optical and electronic crystal.", 9, "consumable", {"sellable": true})
	_register("titanium", "Titanium Ore", 999, "a1b4d4", "Deep-earth high-strength ore.", 14, "consumable", {"sellable": true})
	_register("biolume_stone", "Biolume Stone", 999, "70dba5", "Living mineral from the fungal depths.", 11, "consumable", {"sellable": true})
	_register("support_beam", "Support Beam", 99, "91a4b9", "Brace underground ceilings.", 8, "foreground", {"tile_id": 13, "quick_slot": 0})
	_register("power_cable", "Power Cable", 999, "e2a34c", "Non-blocking power conduit.", 4, "foreground", {"tile_id": 14, "quick_slot": 1})
	_register("coal_generator", "Coal Generator", 10, "667384", "Burns coal to power nearby machinery.", 80, "structure", {"scene_path": "res://src/entities/machines/CoalGenerator.tscn"})
	_register("auto_drill", "Auto Drill", 10, "e3b65b", "Extracts adjacent ore with power.", 120, "structure", {"scene_path": "res://src/entities/machines/AutoDrill.tscn", "placement_rules": ["adjacent_ore"]})
	_register("auto_turret", "Auto Turret", 10, "c16b66", "Powered perimeter defense.", 150, "structure", {"scene_path": "res://src/entities/machines/AutoTurret.tscn"})
	_register("storage_crate", "Storage Crate", 20, "73b9b0", "Receives automation output.", 40, "structure", {"scene_path": "res://src/entities/machines/StorageCrate.tscn"})
	_register("camp_heater", "Camp Heater", 20, "eaa365", "Housing warmth and portable heat.", 24, "structure", {"scene_path": "res://src/entities/structures/CampHeater.tscn", "housing_tags": ["heater"], "quick_slot": 7})
	_register("wall_flare", "Wall Flare", 99, "ffd47c", "Housing light and cave illumination.", 10, "structure", {"scene_path": "res://src/entities/structures/WallFlare.tscn", "housing_tags": ["light"], "quick_slot": 8})
	_register("oxygen_canister", "Oxygen Canister", 99, "6cbde0", "Restores 50 oxygen on use.", 18, "consumable", {"effects": {"oxygen_restore": 50.0}})
	_register("iron_ingot", "Iron Ingot", 999, "a4b7c2", "Smelted iron for hull construction.", 18, "consumable", {"sellable": true})
	_register("copper_ingot", "Copper Ingot", 999, "e8a472", "Refined conductor for field electronics.", 16, "consumable", {"sellable": true})
	_register("titanium_ingot", "Titanium Ingot", 999, "b6b1e3", "Advanced alloy for fabrication.", 42, "consumable", {"sellable": true})
	_register("hull_wall", "Hull Wall", 999, "66828d", "Background pressure plating. Place behind yourself.", 3, "background_wall", {"tile_id": 15, "quick_slot": 2})
	_register("steel_plate", "Steel Plate", 999, "a4b4c1", "Solid load-bearing construction block.", 6, "foreground", {"tile_id": 16, "quick_slot": 3})
	_register("reinforced_glass", "Reinforced Glass", 999, "86d6df", "Transparent structural observation block.", 8, "foreground", {"tile_id": 17, "quick_slot": 4})
	_register("blast_door", "Blast Door", 99, "b7b7ad", "One-cell sealed hatch. Interact or approach to cycle.", 32, "structure", {"scene_path": "res://src/entities/structures/BlastDoor.tscn", "housing_tags": ["door"], "quick_slot": 5})
	_register("ore_smelter", "Ore Smelter", 20, "d8905a", "Refines ores into ingots within 80 pixels.", 70, "structure", {"scene_path": "res://src/entities/structures/CraftingStation.tscn", "station_kind": "smelter", "quick_slot": 6})
	_register("tech_fabricator", "Tech Fabricator", 20, "67d7c5", "Fabricates advanced equipment within 80 pixels.", 120, "structure", {"scene_path": "res://src/entities/structures/CraftingStation.tscn", "station_kind": "fabricator"})
	_register("fuel_cell", "Fuel Cell", 99, "a5e572", "Restores 40 portable battery charge on use.", 12, "consumable", {"effects": {"battery_restore": 40.0}})
	_register("nano_medkit", "Nano-Medkit", 99, "f2cbb6", "Restores 45 integrity on use.", 20, "consumable", {"effects": {"health_restore": 45.0}})
	_register("drill_overclock_module", "Drill Overclock Module", 1, "ecc769", "Permanent +25% manual mining speed. Installs once.", 180, "consumable", {"effects": {"mining_multiplier": 1.25}, "unique_upgrade": true})
	_register("extended_o2_tank", "Extended O2 Tank", 1, "8fc9f0", "Permanent +50 maximum oxygen. Installs once.", 150, "consumable", {"effects": {"oxygen_capacity": 50.0}, "unique_upgrade": true})
	_register("precursor_schematic", "Precursor Schematic", 99, "d9c6f2", "Recovered research document used in precursor crafting.", 90, "consumable", {})
	_register("diving_rebreather", "Diving Rebreather", 1, "7ed5e5", "Carry to equip: halves underwater oxygen drain. No stacking.", 160, "consumable", {"underwater_o2_multiplier": 0.5, "equipment_slot": "breathing"})
	_register("thermal_wetsuit", "Thermal Wetsuit", 1, "62bca6", "Carry to equip: negates cold-water chill. Ambient cold remains.", 180, "consumable", {"water_chill_multiplier": 0.0, "equipment_slot": "suit"})

func _register(item_id: String, title: String, maximum: int, palette: String, detail: String, value: int, layer: String, metadata: Dictionary) -> void:
	var definition := ItemDef.new()
	definition.id = item_id
	definition.display_name = title
	definition.stack_size = maximum
	definition.color = Color(palette)
	definition.description = detail
	definition.base_value = value
	definition.place_layer = layer
	definition.is_consumable = not Dictionary(metadata.get("effects", {})).is_empty()
	for property: String in metadata:
		if property in ["housing_tags", "placement_rules"]:
			var strings: Array[String] = []
			strings.assign(metadata[property])
			definition.set(property, strings)
		else:
			definition.set(property, metadata[property])
	definitions[item_id] = definition
	items[item_id] = {"name": title, "max_stack": maximum, "color": definition.color, "description": detail, "base_value": value, "place_layer": layer}

func get_item_def(item_id: String) -> ItemDef:
	return definitions.get(item_id) as ItemDef

func get_all_items() -> Array[ItemDef]:
	var result: Array[ItemDef] = []
	for definition: ItemDef in definitions.values():
		result.append(definition)
	return result

func get_item(item_id: String) -> Dictionary:
	return Dictionary(items.get(item_id, {})).duplicate()

func get_item_name(item_id: String) -> String:
	var definition: ItemDef = get_item_def(item_id)
	return definition.display_name if definition != null else "Unknown"

func get_item_color(item_id: String) -> Color:
	var definition: ItemDef = get_item_def(item_id)
	return definition.color if definition != null else Color.WHITE

func get_item_max_stack(item_id: String) -> int:
	var definition: ItemDef = get_item_def(item_id)
	return definition.stack_size if definition != null else 0

func validate_item_id(item_id: String) -> bool:
	return definitions.has(item_id)

func get_drop_item(tile_id: int) -> String:
	# Terrain aliases are catalog data, not item-specific gameplay branches.
	const TERRAIN_DROPS: Dictionary = {3: "stone", 4: "iron_ore", 5: "coal", 6: "copper_ore", 7: "quartz", 8: "titanium", 9: "biolume_stone"}
	if TERRAIN_DROPS.has(tile_id):
		return String(TERRAIN_DROPS[tile_id])
	for definition: ItemDef in definitions.values():
		if definition.tile_id == tile_id and definition.place_layer == "foreground":
			return definition.id
	return ""

func _ready() -> void:
	if items.is_empty():
		_initialize_items()
	if not is_instance_valid(_instance):
		_instance = self

func _exit_tree() -> void:
	if _instance == self:
		_instance = null
