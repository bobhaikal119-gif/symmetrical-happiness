extends Node
class_name PerformanceReporter

## Diagnostics adapter publishes value snapshots, keeping UI isolated from entities.
var _elapsed: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed < 0.5 or not bool(SettingsManager.get_setting("optimization", "performance_overlay", false)):
		return
	_elapsed = 0.0
	var pending: Array[Node] = [get_tree().root]
	var active: int = 0
	var total: int = 0
	while not pending.is_empty():
		var node: Node = pending.pop_back()
		total += 1
		if node.can_process() and (node.is_processing() or node.is_physics_processing()):
			active += 1
		for child: Node in node.get_children():
			pending.append(child)
	SignalBus.get_instance().performance_updated.emit(float(Engine.get_frames_per_second()), active, total)
