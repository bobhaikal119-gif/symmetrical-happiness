extends Node
class_name MachineNetworkCoordinator

## Typed legacy machine integration, isolated from new narrow interactables.
var world_grid: WorldGrid
var power_grid: PowerGridSystem
var container: Node2D
var _bus: SignalBus
var _elapsed: float = 0.0

func configure(grid: WorldGrid, network: PowerGridSystem, machines: Node2D) -> void:
	world_grid = grid
	power_grid = network
	container = machines
	_bus = SignalBus.get_instance()
	power_grid.set_world_grid(grid)
	power_grid.network_totals_updated.connect(_on_totals)
	container.child_entered_tree.connect(_on_machine_added)
	_bus.tile_placed.connect(_on_tile_changed)
	for machine: Node in container.get_children():
		configure_machine(machine)

func configure_machine(machine: Node) -> void:
	var position: Vector2 = (machine as Node2D).global_position if machine is Node2D else Vector2.ZERO
	var cell := Vector2i(floori(position.x / 16.0), floori(position.y / 16.0))
	if machine is CoalGenerator:
		(machine as CoalGenerator).setup(world_grid, power_grid, cell, _bus)
	elif machine is AutoDrill:
		(machine as AutoDrill).setup(world_grid, power_grid, cell, _bus)
	elif machine is AutoTurret:
		(machine as AutoTurret).setup(world_grid, power_grid, cell, _bus)
	elif machine is StorageCrate:
		(machine as StorageCrate).setup(world_grid, power_grid, cell, _bus)
	elif machine is CampHeater:
		(machine as CampHeater).setup(cell, world_grid, power_grid)

func _on_machine_added(machine: Node) -> void:
	call_deferred("configure_machine", machine)

func _process(delta: float) -> void:
	_elapsed += delta
	if _elapsed < 0.5:
		return
	_elapsed = 0.0
	var nodes: Dictionary = power_grid.get_registered_nodes()
	for machine: Node in container.get_children():
		var cell: Vector2i
		var watts: float = 0.0
		if machine is CoalGenerator:
			cell = (machine as CoalGenerator).grid_pos
			watts = (machine as CoalGenerator).get_power_output()
		elif machine is AutoDrill:
			cell = (machine as AutoDrill).grid_pos
			watts = -(machine as AutoDrill).get_power_draw()
		elif machine is AutoTurret:
			cell = (machine as AutoTurret).grid_pos
			watts = -(machine as AutoTurret).get_power_draw()
		elif machine is CampHeater:
			cell = (machine as CampHeater).grid_pos
			watts = -(machine as CampHeater).get_power_draw()
		else:
			continue
		if not nodes.has(cell) or not is_equal_approx(float(nodes[cell]), watts):
			power_grid.register_node(cell, watts)

func _on_tile_changed(_cell: Vector2i, _tile_id: int) -> void:
	# Cable topology mutation is relatively rare; no whole-world scene scanning.
	power_grid.recalculate_networks()

func _on_totals(totals: Dictionary) -> void:
	_bus.power_grid_updated.emit(float(totals.get("produced_watts", 0.0)), float(totals.get("demand_watts", 0.0)), float(totals.get("efficiency", 1.0)))
