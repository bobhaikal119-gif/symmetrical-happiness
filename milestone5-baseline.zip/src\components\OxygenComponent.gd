extends Node
class_name OxygenComponent

## Head immersion overrides every refill; dry-land depth/heater behavior is retained.
@export var max_oxygen: float = 100.0
@export var surface_replenish_rate: float = 10.0
@export var heater_replenish_rate: float = 6.0
@export var deep_drain_rate: float = 5.0
@export var underwater_drain_rate: float = 8.0
@export var oxygen_depth_threshold: int = 150
@export var surface_depth_max: int = 40
@export var suffocation_damage: float = 5.0
@export var suffocation_interval: float = 1.0

var current_oxygen: float = 100.0
var player_depth: int = 0
var is_near_heater: bool = false
var head_submerged: bool = false
var submersion_ratio: float = 0.0
var underwater_o2_multiplier: float = 1.0
var signal_bus: SignalBus
var _damage_elapsed: float = 0.0
var _last_emitted: float = -1.0

func _ready() -> void:
	signal_bus = SignalBus.get_instance()
	signal_bus.equipment_changed.connect(_on_equipment_changed)
	current_oxygen = max_oxygen
	_emit_oxygen_changed(true)
	signal_bus.equipment_snapshot_requested.emit()

func _process(delta: float) -> void:
	if delta <= 0.0:
		return
	var rate: float = 0.0
	if head_submerged:
		# One rate, not deep drain plus underwater drain; heaters cannot create air.
		rate = -underwater_drain_rate * underwater_o2_multiplier
	else:
		if player_depth <= surface_depth_max:
			rate += surface_replenish_rate
		if is_near_heater:
			rate += heater_replenish_rate
		if rate <= 0.0 and player_depth > oxygen_depth_threshold:
			rate = -deep_drain_rate
	current_oxygen = clampf(current_oxygen + rate * delta, 0.0, max_oxygen)
	_emit_oxygen_changed(false)
	if current_oxygen <= 0.0:
		_damage_elapsed += delta
		var interval: float = maxf(0.05, suffocation_interval)
		if _damage_elapsed >= interval:
			var pulses: int = floori(_damage_elapsed / interval)
			_damage_elapsed -= float(pulses) * interval
			GlobalGameState.set_hp(GlobalGameState.get_hp() - suffocation_damage * pulses)
	else:
		_damage_elapsed = 0.0

func set_submersion(is_submerged: bool, depth_ratio: float) -> void:
	head_submerged = is_submerged
	submersion_ratio = clampf(depth_ratio, 0.0, 1.0) if is_finite(depth_ratio) else 0.0

func _on_equipment_changed(o2_multiplier: float, _chill_multiplier: float) -> void:
	underwater_o2_multiplier = clampf(o2_multiplier, 0.0, 10.0) if is_finite(o2_multiplier) else 1.0

func set_depth(depth: int) -> void:
	player_depth = maxi(0, depth)

func set_near_heater(status: bool) -> void:
	is_near_heater = status

func consume_oxygen(amount: float) -> void:
	current_oxygen = clampf(current_oxygen - maxf(0.0, amount), 0.0, max_oxygen)
	_emit_oxygen_changed(true)

func restore_oxygen(amount: float) -> void:
	current_oxygen = clampf(current_oxygen + maxf(0.0, amount), 0.0, max_oxygen)
	_emit_oxygen_changed(true)

func _emit_oxygen_changed(force: bool) -> void:
	if signal_bus != null and (force or absf(current_oxygen - _last_emitted) >= 0.05):
		_last_emitted = current_oxygen
		signal_bus.oxygen_changed.emit(current_oxygen, max_oxygen)
