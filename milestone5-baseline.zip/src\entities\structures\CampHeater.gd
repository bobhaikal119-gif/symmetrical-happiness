extends Node2D

class_name CampHeater

"""
CampHeater: Placeable thermal refuge and 20W grid consumer. Dependencies are
injected by PlacementComponent/Main; it has no knowledge of either owner.
"""

const POWER_DEMAND_WATTS: float = 20.0

@export var heater_radius: float = 64.0
@export var heat_output: float = 0.5
@export var max_health: float = 80.0

@onready var heater_sprite: Sprite2D = $Sprite2D
@onready var heater_light: PointLight2D = $PointLight2D

var power_grid: PowerGridSystem
var grid_pos: Vector2i = Vector2i.ZERO
var is_active: bool = false
var health: float = 80.0
var _registered: bool = false

func _ready() -> void:
	add_to_group("machines")
	add_to_group("powered_consumers")
	add_to_group("base_targets")
	add_to_group("heaters")
	health = max_health
	_create_procedural_sprite()
	heater_light.texture = ProceduralLightTexture.create_radial_texture(128)
	heater_light.color = Color(1.0, 0.48, 0.18)
	heater_light.energy = 0.0
	heater_light.texture_scale = 1.2
	_evaluate_power()

func setup(p_grid_pos: Vector2i, world_or_power: Variant, optional_power_grid: PowerGridSystem = null) -> void:
	grid_pos = p_grid_pos
	if world_or_power is PowerGridSystem:
		power_grid = world_or_power as PowerGridSystem
	else:
		power_grid = optional_power_grid
	_register_power_node()
	_evaluate_power()

func configure(p_grid_pos: Vector2i, world_or_power: Variant, optional_power_grid: PowerGridSystem = null) -> void:
	setup(p_grid_pos, world_or_power, optional_power_grid)

func _process(_delta: float) -> void:
	_evaluate_power()

func _exit_tree() -> void:
	if power_grid != null and _registered:
		power_grid.unregister_node(grid_pos)
		power_grid.recalculate_networks()
		_registered = false

func _register_power_node() -> void:
	if power_grid == null or _registered:
		return
	power_grid.register_node(grid_pos, -POWER_DEMAND_WATTS)
	power_grid.recalculate_networks()
	_registered = true

func _evaluate_power() -> void:
	var efficiency: float = power_grid.get_efficiency_at(grid_pos) if power_grid != null else 0.0
	var should_activate: bool = efficiency > 0.01
	if should_activate != is_active:
		is_active = should_activate
		if is_active:
			SignalBus.get_instance().heater_deployed.emit(global_position, heater_radius)
	if heater_light != null:
		heater_light.energy = efficiency * 1.4
	modulate = Color.WHITE if is_active else Color(0.46, 0.5, 0.56)

func _create_procedural_sprite() -> void:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	var outline := Color("241a1a")
	var metal := Color("73513a")
	var hot := Color("ff9c28")
	var bright := Color("ffe083")
	for y in range(4, 14):
		for x in range(3, 13):
			image.set_pixel(x, y, outline if x == 3 or x == 12 or y == 4 or y == 13 else metal)
	for y in range(7, 12):
		for x in range(6, 10):
			image.set_pixel(x, y, bright if y < 9 else hot)
	for x in range(5, 11):
		image.set_pixel(x, 2, outline)
		image.set_pixel(x, 3, metal)
	image.set_pixel(4, 15, outline)
	image.set_pixel(11, 15, outline)
	heater_sprite.texture = ImageTexture.create_from_image(image)

func take_damage(amount: float) -> void:
	health = maxf(0.0, health - maxf(0.0, amount))
	if health <= 0.0:
		queue_free()

func is_powered() -> bool:
	return is_active

func get_power_draw() -> float:
	return POWER_DEMAND_WATTS
