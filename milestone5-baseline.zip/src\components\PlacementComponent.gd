extends Node

class_name PlacementComponent

## Layer and capability dispatch comes entirely from ItemDef metadata. Concrete
## scene types below are narrow adapters for the pre-contract machine interfaces.
const TILE_SIZE: int = WorldGrid.TILE_SIZE
const TILE_AIR: int = WorldGrid.TILE_AIR
const TILE_SUPPORT_BEAM: int = WorldGrid.TILE_SUPPORT_BEAM
const TILE_POWER_CABLE: int = WorldGrid.TILE_POWER_CABLE

@export var signal_bus: SignalBus
@export var player_reach: float = 64.0
@export var oxygen: OxygenComponent
@export var crafting: CraftingComponent
@export var structure_parent: Node
@export var cursor_reticle: CursorReticle
@export var hotbar_items: Array[String] = []

var world_grid: WorldGrid
var power_grid: PowerGridSystem
var economy: EconomyComponent
var active_item: String = ""
var ghost: PlacementGhost
var _connected_bus: SignalBus


func _ready() -> void:
	if get_parent() != null:
		if cursor_reticle == null:
			cursor_reticle = get_parent().get_node_or_null("CursorReticle") as CursorReticle
		if economy == null:
			economy = get_parent().get_node_or_null("EconomyComponent") as EconomyComponent
	_build_metadata_hotbar()
	_connect_selection_signal()
	ghost = PlacementGhost.new()
	ghost.name = "PlacementGhost"
	ghost.configure(self, cursor_reticle)
	add_child(ghost)
	_sync_cursor_mode()


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_signal_bus: SignalBus = null,
		p_crafting: CraftingComponent = null,
		p_oxygen: OxygenComponent = null,
		p_structure_parent: Node = null,
		p_economy: EconomyComponent = null
) -> void:
	world_grid = p_world_grid
	power_grid = p_power_grid
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	if p_crafting != null:
		crafting = p_crafting
	if p_oxygen != null:
		oxygen = p_oxygen
	if p_structure_parent != null:
		structure_parent = p_structure_parent
	if p_economy != null:
		economy = p_economy
	if is_inside_tree():
		_connect_selection_signal()
	_sync_cursor_mode()


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_signal_bus: SignalBus = null,
		p_crafting: CraftingComponent = null,
		p_oxygen: OxygenComponent = null,
		p_structure_parent: Node = null,
		p_economy: EconomyComponent = null
) -> void:
	setup(p_world_grid, p_power_grid, p_signal_bus, p_crafting, p_oxygen, p_structure_parent, p_economy)


func _connect_selection_signal() -> void:
	var bus: SignalBus = _get_signal_bus()
	if _connected_bus == bus:
		return
	if is_instance_valid(_connected_bus) and _connected_bus.building_item_selected.is_connected(select_item):
		_connected_bus.building_item_selected.disconnect(select_item)
	_connected_bus = bus
	if bus != null and not bus.building_item_selected.is_connected(select_item):
		bus.building_item_selected.connect(select_item)


func _build_metadata_hotbar() -> void:
	if not hotbar_items.is_empty():
		return
	for definition: ItemDef in ItemRegistry.get_instance().get_all_items():
		if definition.quick_slot < 0 or definition.quick_slot >= 9:
			continue
		while hotbar_items.size() <= definition.quick_slot:
			hotbar_items.append("")
		hotbar_items[definition.quick_slot] = definition.id


func select_item(item_id: String) -> void:
	if not item_id.is_empty() and ItemRegistry.get_instance().get_item_def(item_id) == null:
		_show_hint("Unknown building item")
		return
	active_item = item_id
	_sync_cursor_mode()


func select_hotbar_slot(slot: int) -> bool:
	if hotbar_items.is_empty():
		_build_metadata_hotbar()
	if slot < 0 or slot >= hotbar_items.size() or hotbar_items[slot].is_empty():
		return false
	select_item(hotbar_items[slot])
	return true


func _unhandled_input(event: InputEvent) -> void:
	if SettingsManager.is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if _handle_hotbar_input(event):
		get_viewport().set_input_as_handled()
		return
	if active_item.is_empty() or not (event.is_action_pressed("place_secondary") or event.is_action_pressed("place_heater")):
		return
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(active_item)
	if definition == null:
		return
	var target: Vector2i = get_target_cell()
	if definition.place_layer != "consumable":
		var failure: String = get_placement_error(active_item, target)
		if not failure.is_empty():
			_show_hint(failure)
			get_viewport().set_input_as_handled()
			return
	if not deploy_item(active_item, _grid_to_world(target)):
		_show_hint("Item cannot be used here" if definition.place_layer == "consumable" else "Placement rejected")
	get_viewport().set_input_as_handled()


func get_target_cell() -> Vector2i:
	if cursor_reticle != null:
		cursor_reticle.world_grid = world_grid
		return cursor_reticle.get_build_target(player_reach)
	var player: Node2D = get_parent() as Node2D
	return _world_to_grid(player.get_global_mouse_position()) if player != null else Vector2i.ZERO


func deploy_item(item_id: String, world_pos: Vector2) -> bool:
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if definition == null or not _has_inventory_item(item_id):
		return false
	if definition.place_layer == "consumable":
		# Economy owns semantic effects and atomic consumption, including upgrades.
		if economy == null and get_parent() != null:
			economy = get_parent().get_node_or_null("EconomyComponent") as EconomyComponent
		return economy != null and economy.use_item(item_id)
	var target: Vector2i = _world_to_grid(world_pos)
	var failure: String = get_placement_error(item_id, target)
	if not failure.is_empty():
		_show_hint(failure)
		return false
	match definition.place_layer:
		"foreground", "background_wall":
			return _place_tile(definition, target)
		"structure":
			return _place_structure(definition, target)
	return false


func can_place_item(item_id: String, cell: Vector2i) -> bool:
	return get_placement_error(item_id, cell).is_empty()


func get_placement_error(item_id: String, cell: Vector2i) -> String:
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(item_id)
	if definition == null:
		return "Unknown building item"
	if not _has_inventory_item(item_id):
		return "No %s in inventory" % definition.display_name
	if world_grid == null or not world_grid.is_valid_position(cell.x, cell.y):
		return "Outside the world"
	if not _is_within_reach(cell):
		return "Out of reach"
	match definition.place_layer:
		"background_wall":
			# Background never collides: actors, doors and machines may overlap it.
			if definition.tile_id < 0:
				return "No wall definition"
			if world_grid.get_background_wall(cell.x, cell.y) != TILE_AIR:
				return "Background wall already present"
		"foreground", "structure":
			if world_grid.get_tile(cell.x, cell.y) != TILE_AIR:
				return "Choose an empty foreground tile"
			if _overlaps_actor(cell):
				return "Cannot build over an actor"
			if _structure_occupies(cell):
				return "A structure already occupies this tile"
			if definition.place_layer == "foreground" and definition.tile_id < 0:
				return "No tile definition"
			if definition.place_layer == "structure" and definition.scene_path.is_empty():
				return "No structure scene"
		_:
			return "Select a placeable item"
	for rule: String in definition.placement_rules:
		match rule:
			"adjacent_ore":
				if not _has_adjacent_ore(cell):
					return "Must be adjacent to an ore vein"
			_:
				return "Unsupported placement rule: %s" % rule
	return ""


func _place_tile(definition: ItemDef, cell: Vector2i) -> bool:
	if not _consume_inventory_item(definition.id):
		return false
	if definition.place_layer == "background_wall":
		world_grid.set_background_wall(cell.x, cell.y, definition.tile_id)
		if world_grid.get_background_wall(cell.x, cell.y) != definition.tile_id:
			_refund_inventory_item(definition.id)
			return false
	else:
		world_grid.set_tile(cell.x, cell.y, definition.tile_id)
		if world_grid.get_tile(cell.x, cell.y) != definition.tile_id:
			_refund_inventory_item(definition.id)
			return false
	# Grid local events are relayed by WorldEventBridge, never double-emitted here.
	_emit_structure_placed(cell, definition.id)
	return true


func _place_structure(definition: ItemDef, cell: Vector2i) -> bool:
	var host: Node = _get_structure_parent()
	var scene: PackedScene = load(definition.scene_path) as PackedScene
	if host == null or scene == null or not scene.can_instantiate():
		return false
	var instance: Node = scene.instantiate()
	var structure: Node2D = instance as Node2D
	if structure == null:
		instance.free()
		return false
	if not _consume_inventory_item(definition.id):
		structure.free()
		return false
	# Legacy setup may publish a powered-heater event before entering the tree.
	# Give it the authoritative world center before invoking that typed adapter.
	structure.position = _grid_to_world(cell)
	if not _configure_structure(structure, definition, cell):
		_refund_inventory_item(definition.id)
		structure.free()
		return false
	structure.set_meta(&"item_id", definition.id)
	structure.set_meta(&"grid_pos", cell)
	structure.set_meta(&"housing_tags", definition.housing_tags.duplicate())
	structure.add_to_group(&"placed_structures")
	structure.position = (host as Node2D).to_local(_grid_to_world(cell)) if host is Node2D else _grid_to_world(cell)
	host.add_child(structure)
	structure.global_position = _grid_to_world(cell)
	_emit_structure_placed(cell, definition.id)
	return true


func _configure_structure(structure: Node2D, definition: ItemDef, cell: Vector2i) -> bool:
	# No item-ID routing or reflection: legacy scene classes have explicit adapters.
	if structure is BlastDoor:
		(structure as BlastDoor).configure_item(definition, cell, world_grid)
	elif structure is CraftingStation:
		(structure as CraftingStation).configure_item(definition, cell, world_grid)
	elif structure is CoalGenerator:
		(structure as CoalGenerator).setup(world_grid, power_grid, cell, _get_signal_bus())
	elif structure is AutoDrill:
		(structure as AutoDrill).setup(world_grid, power_grid, cell, _get_signal_bus())
	elif structure is AutoTurret:
		(structure as AutoTurret).setup(world_grid, power_grid, cell, _get_signal_bus())
	elif structure is StorageCrate:
		(structure as StorageCrate).setup(world_grid, power_grid, cell, _get_signal_bus())
	elif structure is CampHeater:
		(structure as CampHeater).setup(cell, world_grid, power_grid)
	elif not structure is WallFlare:
		_show_hint("Structure scene has no typed placement adapter")
		return false
	return true


func _structure_occupies(cell: Vector2i) -> bool:
	if not is_inside_tree():
		return false
	for group: StringName in [&"machines", &"placed_structures"]:
		for candidate: Node in get_tree().get_nodes_in_group(group):
			if candidate.is_queued_for_deletion():
				continue
			var candidate_cell: Variant = candidate.get_meta(&"grid_pos", null)
			if candidate_cell == null:
				if candidate is InteractableEntity:
					candidate_cell = (candidate as InteractableEntity).grid_pos
				elif candidate is Node2D:
					candidate_cell = _world_to_grid((candidate as Node2D).global_position)
			if candidate_cell is Vector2i and candidate_cell == cell:
				return true
	return false


func _overlaps_actor(cell: Vector2i) -> bool:
	if _overlaps_player(cell):
		return true
	if not is_inside_tree():
		return false
	var tile_bounds := Rect2(Vector2(cell * TILE_SIZE), Vector2.ONE * TILE_SIZE)
	for group: StringName in [&"player", &"enemies", &"colonists"]:
		for candidate: Node in get_tree().get_nodes_in_group(group):
			var actor: Node2D = candidate as Node2D
			if actor == null or actor.is_queued_for_deletion():
				continue
			var bounds := Rect2(actor.global_position - Vector2(6.0, 8.0), Vector2(12.0, 16.0))
			var collision: CollisionShape2D = actor.get_node_or_null("CollisionShape2D") as CollisionShape2D
			if collision != null and collision.shape != null:
				bounds = collision.global_transform * collision.shape.get_rect()
			if bounds.intersects(tile_bounds):
				return true
	return false


func _has_adjacent_ore(cell: Vector2i) -> bool:
	for y_offset: int in range(-1, 2):
		for x_offset: int in range(-1, 2):
			if x_offset == 0 and y_offset == 0:
				continue
			var check: Vector2i = cell + Vector2i(x_offset, y_offset)
			var tile_id: int = world_grid.get_tile(check.x, check.y)
			if tile_id >= WorldGrid.TILE_IRON_ORE and tile_id <= WorldGrid.TILE_BIOLUME_STONE:
				return true
	return false


func _can_place_structure_at(cell: Vector2i) -> bool:
	return world_grid != null and world_grid.is_valid_position(cell.x, cell.y) and _is_within_reach(cell) and world_grid.get_tile(cell.x, cell.y) == TILE_AIR and not _overlaps_actor(cell) and not _structure_occupies(cell)


func _has_inventory_item(item_id: String) -> bool:
	return crafting == null or crafting.get_inventory_count(item_id) > 0


func _consume_inventory_item(item_id: String) -> bool:
	return crafting == null or crafting.remove_item(item_id, 1)


func _refund_inventory_item(item_id: String) -> void:
	if crafting != null:
		crafting.add_item(item_id, 1)


func _emit_structure_placed(cell: Vector2i, item_id: String) -> void:
	var bus: SignalBus = _get_signal_bus()
	if bus != null:
		bus.structure_placed.emit(cell, item_id)


func _get_signal_bus() -> SignalBus:
	return signal_bus if signal_bus != null else SignalBus.get_instance()


func _show_hint(message: String) -> void:
	var bus: SignalBus = _get_signal_bus()
	if bus != null:
		bus.show_hud_hint.emit(message)


func _handle_hotbar_input(event: InputEvent) -> bool:
	for slot: int in range(9):
		if event.is_action_pressed(StringName("hotbar_%d" % (slot + 1))):
			return select_hotbar_slot(slot)
	return false


func _sync_cursor_mode() -> void:
	if cursor_reticle == null:
		return
	var definition: ItemDef = ItemRegistry.get_instance().get_item_def(active_item)
	cursor_reticle.build_mode = definition != null and definition.place_layer != "consumable"
	cursor_reticle.building_reach = player_reach
	cursor_reticle.world_grid = world_grid


func _is_within_reach(cell: Vector2i) -> bool:
	var player: Node2D = get_parent() as Node2D
	return player == null or player.global_position.distance_to(_grid_to_world(cell)) <= player_reach


func _overlaps_player(cell: Vector2i) -> bool:
	if cursor_reticle != null:
		return cursor_reticle.overlaps_player(cell)
	var player: Node2D = get_parent() as Node2D
	if player == null:
		return false
	var bounds := Rect2(player.global_position - Vector2(6.0, 8.0), Vector2(12.0, 16.0))
	var collision: CollisionShape2D = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision != null and collision.shape != null:
		bounds = collision.global_transform * collision.shape.get_rect()
	return bounds.intersects(Rect2(Vector2(cell * TILE_SIZE), Vector2.ONE * TILE_SIZE))


func _get_structure_parent() -> Node:
	if is_instance_valid(structure_parent):
		return structure_parent
	var player: Node = get_parent()
	if player != null and player.get_parent() != null:
		return player.get_parent()
	if get_tree() != null and get_tree().current_scene != null:
		return get_tree().current_scene
	return get_tree().root if get_tree() != null else null


func _world_to_grid(world_pos: Vector2) -> Vector2i:
	return Vector2i(floori(world_pos.x / TILE_SIZE), floori(world_pos.y / TILE_SIZE))


func _grid_to_world(cell: Vector2i) -> Vector2:
	return Vector2(cell * TILE_SIZE) + Vector2.ONE * (TILE_SIZE * 0.5)
