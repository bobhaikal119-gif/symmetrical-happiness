extends Resource

class_name RecipeDef

"""
RecipeDef: Data definition for a crafting recipe.
Maps a set of ingredient items to a crafted output item.
"""

# Recipe identification

@export var id: String = ""
"""Unique identifier for the recipe.
"""

# Craft output

@export var output_item_id: String = ""
"""Item id produced when the recipe is crafted.
"""

@export var output_count: int = 1
"""Number of output items produced per craft.
"""

# Ingredients required

@export var ingredients: Dictionary = {}
"""Dictionary mapping ingredient item_id to required count.
"""
