extends Node

class_name ThermalComponent

"""Applies ambient cooling and heat supplied by active nearby heaters."""

@export var ambient_cooldown_rate: float = -0.1
@export var heater_restore_rate: float = 0.5
@export var max_temperature: float = 100.0
@export var min_temperature: float = -50.0

var current_temperature: float = 20.0
var is_near_heater: bool = false
var signal_bus: SignalBus
var _last_emitted: float = INF

func _ready() -> void:
	signal_bus = SignalBus.get_instance()
	_emit_temperature_changed(true)

func _process(delta: float) -> void:
	var change: float = ambient_cooldown_rate * delta
	if is_near_heater:
		change += heater_restore_rate * delta
	current_temperature = clampf(current_temperature + change, min_temperature, max_temperature)
	_emit_temperature_changed(false)

func _emit_temperature_changed(force: bool) -> void:
	if signal_bus != null and (force or absf(current_temperature - _last_emitted) >= 0.05):
		_last_emitted = current_temperature
		signal_bus.temperature_changed.emit(current_temperature, max_temperature)

func set_near_heater_near_status(status: bool) -> void:
	is_near_heater = status
	_emit_temperature_changed(true)

func get_temperature() -> float:
	return current_temperature
