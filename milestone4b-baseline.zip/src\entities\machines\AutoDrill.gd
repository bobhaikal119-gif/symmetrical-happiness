extends StaticBody2D

class_name AutoDrill

const TILE_SIZE: int = 16
const POWER_DRAW: float = 40.0
const POWER_DEMAND_WATTS: float = POWER_DRAW
const ITEM_PICKUP_SCENE_PATH: String = "res://src/entities/items/ItemPickup.tscn"
const ORE_ITEM_IDS: Dictionary = {
	4: "iron_ore",
	5: "coal",
	6: "copper_ore",
	7: "quartz",
	8: "titanium",
	9: "biolume_stone",
}

@export var world_grid: WorldGrid
@export var signal_bus: SignalBus
@export var grid_pos: Vector2i = Vector2i.ZERO
@export var mining_rate: float = 0.5
@export var mining_radius_tiles: int = 3
@export var max_health: float = 100.0

var power_consumption: float = POWER_DRAW
var power_draw: float = POWER_DRAW
var power_grid: PowerGridSystem
var health: float = 100.0
var active: bool = true

var _mining_progress: float = 0.0
var _registered_with_power_grid: bool = false
var _sprite: Sprite2D


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	if _registered_with_power_grid and power_grid != null:
		power_grid.unregister_node(grid_pos)
		_registered_with_power_grid = false
	world_grid = p_world_grid
	power_grid = p_power_grid
	grid_pos = p_grid_pos
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	if is_inside_tree():
		_register_power_node()


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	setup(p_world_grid, p_power_grid, p_grid_pos, p_signal_bus)


func _ready() -> void:
	add_to_group("machines")
	add_to_group("base_targets")
	add_to_group("powered_consumers")
	health = max_health
	_ensure_scene_nodes()
	_create_procedural_sprite()
	_register_power_node()


func _exit_tree() -> void:
	if _registered_with_power_grid and is_instance_valid(power_grid):
		power_grid.unregister_node(grid_pos)
	_registered_with_power_grid = false


func _process(delta: float) -> void:
	if not active or world_grid == null:
		return
	var efficiency: float = get_power_efficiency()
	if efficiency <= 0.0:
		return
	_mining_progress += delta * maxf(0.0, mining_rate) * efficiency
	while _mining_progress >= 1.0:
		_mining_progress -= 1.0
		if not extract_once():
			_mining_progress = 0.0
			break


func extract_once() -> bool:
	if not active or world_grid == null:
		return false
	var ore_grid: Vector2i = _find_nearest_ore()
	if ore_grid.x < 0:
		return false
	var tile_id: int = world_grid.get_tile(ore_grid.x, ore_grid.y)
	if not ORE_ITEM_IDS.has(tile_id):
		return false
	var item_id: String = String(ORE_ITEM_IDS[tile_id])
	world_grid.break_tile(ore_grid.x, ore_grid.y)
	_deposit_or_drop(item_id)
	_emit_extracted(item_id)
	return true


func get_power_draw() -> float:
	return power_draw if active else 0.0


func get_power_consumption() -> float:
	return get_power_draw()


func get_power_efficiency() -> float:
	if not active or power_grid == null:
		return 0.0
	return clampf(power_grid.get_efficiency_at(grid_pos), 0.0, 1.0)


func is_active() -> bool:
	return active and health > 0.0


func take_damage(amount: float) -> void:
	if not active or amount <= 0.0:
		return
	health = maxf(0.0, health - amount)
	if health <= 0.0:
		active = false
		if power_grid != null:
			power_grid.recalculate_networks()
		queue_free()


func apply_damage(amount: float) -> void:
	take_damage(amount)


func _register_power_node() -> void:
	if power_grid != null:
		power_grid.register_node(grid_pos, -POWER_DRAW)
		power_grid.recalculate_networks()
		_registered_with_power_grid = true


func _find_nearest_ore() -> Vector2i:
	var best: Vector2i = Vector2i(-1, -1)
	var best_distance_squared: int = 2147483647
	var radius: int = maxi(1, mining_radius_tiles)
	for y_offset in range(-radius, radius + 1):
		for x_offset in range(-radius, radius + 1):
			var distance_squared: int = x_offset * x_offset + y_offset * y_offset
			if distance_squared > radius * radius or distance_squared >= best_distance_squared:
				continue
			var candidate := grid_pos + Vector2i(x_offset, y_offset)
			if not world_grid.is_valid_position(candidate.x, candidate.y):
				continue
			if ORE_ITEM_IDS.has(world_grid.get_tile(candidate.x, candidate.y)):
				best = candidate
				best_distance_squared = distance_squared
	return best


func _deposit_or_drop(item_id: String) -> void:
	for candidate: Node in get_tree().get_nodes_in_group("storage_crates"):
		if not candidate.has_method("add_item"):
			continue
		var candidate_grid_value: Variant = candidate.get("grid_pos")
		if not candidate_grid_value is Vector2i:
			continue
		var candidate_grid: Vector2i = Vector2i(candidate_grid_value)
		if absi(candidate_grid.x - grid_pos.x) + absi(candidate_grid.y - grid_pos.y) != 1:
			continue
		if bool(candidate.call("add_item", item_id, 1)):
			return
	_spawn_pickup(item_id, 1)


func _spawn_pickup(item_id: String, amount: int) -> void:
	var pickup_scene: PackedScene = load(ITEM_PICKUP_SCENE_PATH) as PackedScene
	if pickup_scene == null:
		return
	var pickup: Node2D = pickup_scene.instantiate() as Node2D
	if pickup == null:
		return
	if pickup.has_method("setup"):
		pickup.call("setup", item_id, amount)
	var drop_parent: Node = get_parent()
	if drop_parent == null:
		drop_parent = get_tree().current_scene
	if drop_parent == null:
		drop_parent = get_tree().root
	drop_parent.add_child(pickup)
	pickup.global_position = global_position + Vector2(0.0, -10.0)


func _emit_extracted(item_id: String) -> void:
	var bus: SignalBus = signal_bus
	if bus == null:
		bus = SignalBus.get_instance()
	if bus != null:
		bus.auto_drill_extracted.emit(grid_pos, item_id)


func _ensure_scene_nodes() -> void:
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)
	var collision: CollisionShape2D = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision == null:
		collision = CollisionShape2D.new()
		collision.name = "CollisionShape2D"
		add_child(collision)
	if collision.shape == null:
		var shape := RectangleShape2D.new()
		shape.size = Vector2(14.0, 14.0)
		collision.shape = shape


func _create_procedural_sprite() -> void:
	if _sprite == null:
		return
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var outline := Color("1d252c")
	var steel := Color("566773")
	var highlight := Color("8ea2ad")
	var warning := Color("e7a52b")
	var bit := Color("b8d5dc")

	for y in range(3, 12):
		for x in range(2, 14):
			image.set_pixel(x, y, outline)
	for y in range(4, 11):
		for x in range(3, 13):
			image.set_pixel(x, y, steel)
	for x in range(4, 12):
		image.set_pixel(x, 4, highlight)
	for x in range(4, 12):
		if x % 2 == 0:
			image.set_pixel(x, 8, warning)
			image.set_pixel(x + 1, 8, outline)
	image.set_pixel(7, 12, bit)
	image.set_pixel(8, 12, bit)
	image.set_pixel(6, 13, bit)
	image.set_pixel(9, 13, bit)
	image.set_pixel(5, 14, bit)
	image.set_pixel(10, 14, bit)
	for x in range(2, 5):
		image.set_pixel(x, 12, outline)
	for x in range(11, 14):
		image.set_pixel(x, 12, outline)
	_sprite.texture = ImageTexture.create_from_image(image)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
