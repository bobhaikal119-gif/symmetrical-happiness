# DEEPWELL — Milestone 4A Verification

## Result

**Implemented and validated with Godot 4.7.2.stable.official.ed1daf0bf on Windows.**

The main scene imports and runs without observed parser, missing-resource, or runtime errors in the validation runs described below. All Milestone 4 SignalBus declarations remain unchanged. No unfinished code markers or empty `pass` bodies were found in project source.

## Delivered

| Area | Implementation |
| --- | --- |
| Persistence | [SettingsManager](<src/autoload/SettingsManager.gd>) autoload; six ConfigFile sections; sanitization, default restoration and live events |
| Pause/settings | [SettingsMenu](<src/ui/SettingsMenu.gd>) with General, Profile, Graphics, Optimization and Controls tabs; Escape capture/cancel/resume; confirmed session reset |
| Profile/general | Pioneer name, live suit modulation, seed readout, scaled shake, finite pickup/HP notices, crafting auto-pause, anchored HUD scaling |
| Graphics | Actual DisplayServer window modes and VSync; viewport pixel snap; ambient-darkness modulation |
| World optimization | [WorldRenderer](<src/presentation/WorldRenderer.gd>) uses actual 16×16 TileMapLayer chunks with a shared generated atlas and 24–128-tile active radius; collision and simulation are independent of visual radius |
| Lighting | Full PointLight2D or Fast additive unshaded glow proxies; real light textures/shadows restored when switching back; dynamic placed lights supported |
| Effect budgets | [Main](<src/main/Main.gd>) caps particle emitters and pickup entities; excess rewards merge or safely credit inventory instead of disappearing |
| Controls | All 20 gameplay keyboard actions listed; canonical/legacy aliases synchronized; only keyboard events erased on rebind; conflicts require explicit confirmation; mouse bindings retained |
| Mouse assist | [CursorReticle](<src/presentation/CursorReticle.gd>) shares smoothed mining/building target selection, reach checks, occupancy/player exclusion and crisp 16×16 targeting colors |
| HUD | [HudController](<src/ui/HudController.gd>) uses signals for telemetry/profile/Smart Cursor, with FPS and active-processing/total node counts sampled every 0.5 seconds |

## Executed validation

1. **Headless editor import:** completed without parser or resource errors.
2. **[Warning-strict compilation](<tests/compiler_warnings.gd>):** all 11 changed/added gameplay scripts compiled with standard GDScript warnings promoted to errors; zero failures.
3. **[Integration smoke](<tests/milestone4a_smoke.gd>):** passed all assertions covering all settings sections, ConfigFile round trips, safe labels, rebind persistence, aliases, duplicate detection, mouse preservation/swap, profile tint, directional Smart Cursor, build-neighbor targeting, reach, smoothing, pause reasons, viewport snapping/darkness, actual chunks and radius unloading, dynamic Fast lights, flashlight user intent, Full restoration, reward-safe zero drop budget, bounded particle restoration and paused Escape handling.
4. **[Real input and resilience](<tests/milestone4a_input.gd>):** passed all 17 assertions covering Ctrl, HUD badge, Escape, keyboard capture/cancel, conflict confirmation, nonpaused-menu movement blocking, zero shake, popup enable/disable and malformed-value recovery.
5. **[Session reset](<tests/milestone4a_reset.gd>):** passed scene replacement, pause/menu-flag cleanup and retained preferences.
6. **[Graphical validation](<tests/milestone4a_visual.gd>):** rendered and visually inspected all five tabs and 1.5× HUD using OpenGL Compatibility. Actual fullscreen/windowed and VSync off/on round trips passed.
7. **Normal main-scene launch:** 120-frame Vulkan Forward+ run on Radeon RX550/550 Series completed without observed errors.
8. **[Resource/contract audit](<tests/audit_resources.py>):** 54 project files, 43 literal resource references and 37 global classes checked; no missing dependencies, class collisions, autoload shadowing, changed legacy signal contracts or unfinished bodies.

## Review artifacts

- [General tab](<tests/artifacts/visual_0.png>)
- [Profile tab](<tests/artifacts/visual_1.png>)
- [Graphics tab](<tests/artifacts/visual_2.png>)
- [Optimization tab](<tests/artifacts/visual_3.png>)
- [Controls tab](<tests/artifacts/visual_4.png>)
- [1.5× HUD](<tests/artifacts/visual_hud.png>)
- [Milestone 4 → 4A source diff](<tests/artifacts/milestone4a_review.diff>)
- [Original source snapshot](<milestone4a-baseline.zip>)

The workspace is not a Git repository, so a baseline archive and generated unified diff were used for review instead of Git. Validation fixtures restore their original preferences after normal completion. The temporary interrupted-test preferences were cleared to factory defaults; the game is left with Pioneer/default tint, normal mouse buttons, Smart Cursor off, 64-tile render radius and 60 FPS.

## Notes

- `user://settings.cfg` is the only persistent user-preference file; session reset rebuilds the current world and inventory, not preferences.
- The performance overlay explicitly distinguishes active processing nodes from total scene nodes. It is not a GPU profiler or a hardware-independent FPS guarantee.
- Fast lighting is deliberately a cheaper glow presentation, not a visually identical replacement for real dynamic illumination.
- A full manual long-session playtest remains distinct from these automated checks; the report makes no claim about balance or long-duration performance.
