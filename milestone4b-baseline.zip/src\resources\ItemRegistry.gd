extends Node

class_name ItemRegistry

## Registry shared by mining, inventory, crafting, placement, and item pickups.

static var _instance: ItemRegistry = null

## Maps item IDs to dictionaries containing name, stack limit, color, and description.
var items: Dictionary = {}


static func get_instance() -> ItemRegistry:
	## Return a fully initialized registry, even before it enters the SceneTree.
	if not is_instance_valid(_instance):
		_instance = ItemRegistry.new()
		_instance._initialize_items()
	return _instance


func _initialize_items() -> void:
	items.clear()
	_register_item("stone", "Stone", 999, Color(0.4, 0.4, 0.4), "Common building stone")
	_register_item("coal", "Coal", 999, Color(0.15, 0.15, 0.15), "Combustible fuel")
	_register_item("copper_ore", "Copper Ore", 999, Color(0.86, 0.5, 0.2), "Raw copper ore")
	_register_item("iron_ore", "Iron Ore", 999, Color(0.8, 0.6, 0.4), "Raw iron ore")
	_register_item("quartz", "Quartz", 999, Color(0.85, 0.9, 1.0), "Crystalline mineral")
	_register_item("titanium", "Titanium", 999, Color(0.7, 0.75, 0.8), "Strong deep-earth metal ore")
	_register_item("biolume_stone", "Biolume Stone", 999, Color(0.4, 0.9, 0.6), "Living mineral from the fungal depths")
	_register_item("support_beam", "Support Beam", 50, Color(0.5, 0.5, 0.6), "Structural ceiling brace")
	_register_item("oxygen_canister", "Oxygen Canister", 10, Color(0.2, 0.6, 1.0), "Restores oxygen reserves")
	_register_item("camp_heater", "Camp Heater", 5, Color(0.8, 0.4, 0.2), "Deployable heat source")
	_register_item("wall_flare", "Wall Flare", 20, Color(1.0, 0.8, 0.2), "Deployable cave light")

	# Milestone 4 power and automation items.
	_register_item("power_cable", "Power Cable", 100, Color(0.88, 0.54, 0.16), "Non-blocking cable that links powered machines")
	_register_item("coal_generator", "Coal Generator", 5, Color(0.32, 0.34, 0.38), "Burns coal to supply a local power grid")
	_register_item("auto_drill", "Auto Drill", 5, Color(0.82, 0.62, 0.18), "Powered machine that extracts nearby mineral deposits")
	_register_item("auto_turret", "Auto Turret", 5, Color(0.68, 0.24, 0.22), "Powered defensive turret for hostile storm waves")
	_register_item("storage_crate", "Storage Crate", 10, Color(0.25, 0.48, 0.5), "Container that receives and stores extracted items")


func _register_item(
	item_id: String,
	display_name: String,
	max_stack: int,
	color: Color,
	description: String
) -> void:
	items[item_id] = {
		"name": display_name,
		"max_stack": max_stack,
		"color": color,
		"description": description,
	}


func get_item(item_id: String) -> Dictionary:
	var item: Dictionary = items.get(item_id, {}) as Dictionary
	return item


func get_item_name(item_id: String) -> String:
	var item := get_item(item_id)
	return str(item.get("name", "Unknown"))


func get_item_color(item_id: String) -> Color:
	var item := get_item(item_id)
	var color_value: Variant = item.get("color", Color.WHITE)
	return color_value as Color


func get_item_max_stack(item_id: String) -> int:
	var item := get_item(item_id)
	return int(item.get("max_stack", 0))


func validate_item_id(item_id: String) -> bool:
	return items.has(item_id)


func _ready() -> void:
	if items.is_empty():
		_initialize_items()
	if not is_instance_valid(_instance):
		_instance = self


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
