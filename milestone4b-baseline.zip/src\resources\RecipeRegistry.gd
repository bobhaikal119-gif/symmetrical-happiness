extends Node

class_name RecipeRegistry

## Registry of crafting recipes keyed by recipe ID.

static var _instance: RecipeRegistry = null

var recipes: Dictionary = {}


static func get_instance() -> RecipeRegistry:
	## Return an initialized recipe registry before SceneTree _ready() runs.
	if not is_instance_valid(_instance):
		_instance = RecipeRegistry.new()
		_instance._initialize_recipes()
	return _instance


func _initialize_recipes() -> void:
	recipes.clear()

	# Survival recipes retained from earlier milestones, now using mined resources.
	_register_recipe("camp_heater", "camp_heater", 1, {"stone": 6, "coal": 4, "copper_ore": 2})
	_register_recipe("support_beam", "support_beam", 1, {"stone": 2, "iron_ore": 3})
	_register_recipe("wall_flare", "wall_flare", 1, {"coal": 1, "copper_ore": 1, "quartz": 1})
	_register_recipe("oxygen_canister", "oxygen_canister", 1, {"iron_ore": 3, "copper_ore": 2, "quartz": 1})

	# Milestone 4 power, automation, defense, and logistics recipes.
	_register_recipe("power_cable", "power_cable", 4, {"copper_ore": 3, "quartz": 1})
	_register_recipe("coal_generator", "coal_generator", 1, {"stone": 8, "iron_ore": 8, "copper_ore": 4, "coal": 10})
	_register_recipe("auto_drill", "auto_drill", 1, {"iron_ore": 10, "copper_ore": 6, "quartz": 3, "titanium": 2})
	_register_recipe("auto_turret", "auto_turret", 1, {"iron_ore": 8, "copper_ore": 5, "quartz": 4, "titanium": 2})
	_register_recipe("storage_crate", "storage_crate", 1, {"stone": 4, "iron_ore": 6, "copper_ore": 2})


func _register_recipe(
	recipe_id: String,
	output_item_id: String,
	output_count: int,
	ingredients: Dictionary
) -> void:
	var recipe := RecipeDef.new()
	recipe.id = recipe_id
	recipe.output_item_id = output_item_id
	recipe.output_count = output_count
	var copied_ingredients: Dictionary = ingredients.duplicate()
	recipe.ingredients = copied_ingredients
	recipes[recipe_id] = recipe


func get_recipe(recipe_id: String) -> RecipeDef:
	return recipes.get(recipe_id) as RecipeDef


func has_recipe(recipe_id: String) -> bool:
	return recipes.has(recipe_id)


func get_all_recipes() -> Array[RecipeDef]:
	var all_recipes: Array[RecipeDef] = []
	for recipe_value: Variant in recipes.values():
		var recipe := recipe_value as RecipeDef
		if recipe != null:
			all_recipes.append(recipe)
	return all_recipes


func _ready() -> void:
	if recipes.is_empty():
		_initialize_recipes()
	if not is_instance_valid(_instance):
		_instance = self


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
