extends CharacterBody2D

class_name Player

## Main player character composed from survival and tool components.
@export var move_speed: float = 150.0
@export var jump_velocity: float = -330.0

@onready var sprite: Sprite2D = $Sprite2D
@onready var flashlight: PointLight2D = $Flashlight
@onready var battery: BatteryComponent = $BatteryComponent
@onready var thermal: ThermalComponent = $ThermalComponent
@onready var cursor_reticle: CursorReticle = $CursorReticle
@onready var mining_laser: MiningLaserComponent = $MiningLaserComponent
@onready var hazard_detector: HazardDetectorComponent = $HazardDetectorComponent
@onready var oxygen: OxygenComponent = $OxygenComponent
@onready var crafting: CraftingComponent = $CraftingComponent
@onready var placement: PlacementComponent = $PlacementComponent

var signal_bus: SignalBus
var _gravity: float = 980.0
var _flashlight_requested: bool = true


func _ready() -> void:
	add_to_group("player")
	signal_bus = SignalBus.get_instance()
	_gravity = float(ProjectSettings.get_setting("physics/2d/default_gravity", 980.0))
	_create_procedural_sprite()
	sprite.modulate = SettingsManager.get_setting("profile", "suit_color", Color.WHITE)
	signal_bus.setting_changed.connect(_on_setting_changed)
	signal_bus.settings_menu_toggled.connect(_on_menu_toggled)
	signal_bus.crafting_menu_toggled.connect(_on_menu_toggled)
	mining_laser.cursor_reticle = cursor_reticle
	placement.cursor_reticle = cursor_reticle
	cursor_reticle.mining_reach = mining_laser.reach_distance
	cursor_reticle.building_reach = placement.player_reach
	flashlight.texture = ProceduralLightTexture.create_radial_texture(128)
	flashlight.texture_scale = 1.2
	flashlight.energy = 1.1
	flashlight.color = Color(0.78, 0.9, 1.0)
	if not battery.is_node_ready():
		await battery.ready
	if not signal_bus.battery_changed.is_connected(_on_battery_changed):
		signal_bus.battery_changed.connect(_on_battery_changed)
	battery.set_flashlight_active(_flashlight_requested)
	if not hazard_detector.hazard_damage.is_connected(_on_hazard_damage):
		hazard_detector.hazard_damage.connect(_on_hazard_damage)


func _physics_process(delta: float) -> void:
	var input_blocked: bool = SettingsManager.is_gameplay_input_blocked()
	var input_axis: float = 0.0 if input_blocked else Input.get_axis("move_left", "move_right")
	if input_blocked:
		velocity = Vector2.ZERO
		mining_laser.deactivate()
	else:
		velocity.x = move_toward(velocity.x, input_axis * move_speed, move_speed * 8.0 * delta)
		if not is_on_floor():
			velocity.y += _gravity * delta
		elif Input.is_action_just_pressed("jump"):
			velocity.y = jump_velocity
		move_and_slide()
	hazard_detector.player_position = global_position
	oxygen.set_depth(maxi(0, floori(global_position.y / WorldGrid.TILE_SIZE)))
	GlobalGameState.set_player_position(global_position)
	if not is_zero_approx(input_axis):
		flashlight.rotation = 0.0 if input_axis > 0.0 else PI


func _unhandled_input(event: InputEvent) -> void:
	if SettingsManager.is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if event.is_action_pressed("flashlight_toggle"):
		_flashlight_requested = not _flashlight_requested
		battery.set_flashlight_active(_flashlight_requested)
		get_viewport().set_input_as_handled()


func _create_procedural_sprite() -> void:
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	var dark := Color("182231")
	var steel := Color("8aa3b8")
	var frost := Color("d9f4ff")
	var amber := Color("f0a22e")
	for y in range(4, 13):
		for x in range(4, 12):
			image.set_pixel(x, y, steel if x < 9 else dark)
	for y in range(1, 6):
		for x in range(5, 11):
			image.set_pixel(x, y, frost if y < 3 else steel)
	image.set_pixel(6, 3, amber)
	image.set_pixel(9, 3, amber)
	for x in range(3, 6):
		image.set_pixel(x, 8, dark)
	for x in range(11, 14):
		image.set_pixel(x, 8, dark)
	for y in range(13, 16):
		image.set_pixel(5, y, dark)
		image.set_pixel(10, y, dark)
	sprite.texture = ImageTexture.create_from_image(image)


func _on_battery_changed(current: float, max_value: float) -> void:
	var ratio: float = current / maxf(max_value, 0.001)
	flashlight.energy = 0.3 + ratio
	# Visibility expresses user/battery intent only; renderer owns quality modes.
	flashlight.visible = _flashlight_requested and current > 0.0


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section == "profile" and key == "suit_color":
		sprite.modulate = value as Color


func _on_menu_toggled(is_open: bool) -> void:
	if is_open:
		velocity = Vector2.ZERO
		mining_laser.deactivate()


func _on_hazard_damage(amount: float, _world_pos: Vector2) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() - amount)


func take_damage(amount: float) -> void:
	GlobalGameState.set_hp(GlobalGameState.get_hp() - maxf(0.0, amount))


func get_battery() -> BatteryComponent:
	return battery


func get_thermal() -> ThermalComponent:
	return thermal


func get_mining_laser() -> MiningLaserComponent:
	return mining_laser
