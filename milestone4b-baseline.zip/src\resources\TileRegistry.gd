extends Node

class_name TileRegistry

## Registry of every tile definition used by world generation and placement.

const AIR_ID: int = 0
const SNOW_ID: int = 1
const DIRT_ID: int = 2
const STONE_ID: int = 3
const IRON_ORE_ID: int = 4
const COAL_ORE_ID: int = 5
const COPPER_ORE_ID: int = 6
const QUARTZ_ID: int = 7
const TITANIUM_ID: int = 8
const BIOLUME_STONE_ID: int = 9
const BASALT_ID: int = 10
const LAVA_ID: int = 11
const ACID_ID: int = 12
const SUPPORT_BEAM_ID: int = 13
const POWER_CABLE_ID: int = 14

static var _instance: TileRegistry = null

## Maps integer tile IDs to TileDef resources.
var tiles: Dictionary = {}


static func get_instance() -> TileRegistry:
	## Return a fully initialized registry, even before it enters the SceneTree.
	if not is_instance_valid(_instance):
		_instance = TileRegistry.new()
		_instance._initialize_tiles()
	return _instance


func _initialize_tiles() -> void:
	tiles.clear()
	_register_tile(AIR_ID, "Air", 0.0, Color(0.95, 0.95, 0.95, 0.3), false, -1)
	_register_tile(SNOW_ID, "Snow", 0.5, Color(0.95, 0.95, 0.98), true, 0)
	_register_tile(DIRT_ID, "Dirt", 2.0, Color(0.6, 0.4, 0.2), true, 1)
	_register_tile(STONE_ID, "Stone", 10.0, Color(0.4, 0.4, 0.4), true, 2)
	_register_tile(IRON_ORE_ID, "Iron Ore", 3.0, Color(0.8, 0.6, 0.4), true, 3)
	_register_tile(COAL_ORE_ID, "Coal Ore", 2.5, Color(0.15, 0.15, 0.15), true, 64)
	_register_tile(COPPER_ORE_ID, "Copper Ore", 2.5, Color(0.86, 0.5, 0.2), true, 96)
	_register_tile(QUARTZ_ID, "Quartz", 1.5, Color(0.85, 0.9, 1.0), true, 128)
	_register_tile(TITANIUM_ID, "Titanium", 8.0, Color(0.7, 0.75, 0.8), true, 160)
	_register_tile(BIOLUME_STONE_ID, "Biolume Stone", 4.0, Color(0.4, 0.9, 0.6), true, 192)
	_register_tile(BASALT_ID, "Basalt", 15.0, Color(0.25, 0.25, 0.3), true, 320)
	_register_tile(LAVA_ID, "Lava", 0.0, Color(1.0, 0.3, 0.0), false, 320, true, 5.0, "thermal")
	_register_tile(ACID_ID, "Acid", 0.0, Color(0.2, 1.0, 0.3), false, 192, true, 3.0, "contact")
	_register_tile(SUPPORT_BEAM_ID, "SupportBeam", 5.0, Color(0.5, 0.5, 0.6), false, 0)
	_register_tile(POWER_CABLE_ID, "PowerCable", 3.0, Color(0.88, 0.54, 0.16), false, 0)


func _register_tile(
	tile_id: int,
	tile_name: String,
	max_hp: float,
	color: Color,
	is_solid: bool,
	min_depth: int,
	is_hazard: bool = false,
	hazard_damage: float = 0.0,
	hazard_type: String = "contact"
) -> void:
	var tile_def := TileDef.new()
	tile_def.id = tile_id
	tile_def.tile_name = tile_name
	tile_def.max_hp = max_hp
	tile_def.color = color
	tile_def.is_solid = is_solid
	tile_def.min_depth = min_depth
	tile_def.is_hazard = is_hazard
	tile_def.hazard_damage = hazard_damage
	tile_def.hazard_type = hazard_type
	tiles[tile_id] = tile_def


func get_tile_def(tile_id: int) -> TileDef:
	return tiles.get(tile_id) as TileDef


func get_tile_def_by_name(tile_name: String) -> TileDef:
	for tile_value: Variant in tiles.values():
		var tile_def := tile_value as TileDef
		if tile_def != null and tile_def.tile_name == tile_name:
			return tile_def
	return null


func get_tile_name(tile_id: int) -> String:
	var tile_def := get_tile_def(tile_id)
	return tile_def.tile_name if tile_def != null else "Unknown"


func get_tile_color(tile_id: int) -> Color:
	var tile_def := get_tile_def(tile_id)
	return tile_def.color if tile_def != null else Color.WHITE


func get_tile_max_hp(tile_id: int) -> float:
	var tile_def := get_tile_def(tile_id)
	return tile_def.max_hp if tile_def != null else 0.0


func get_is_solid(tile_id: int) -> bool:
	var tile_def := get_tile_def(tile_id)
	return tile_def.is_solid if tile_def != null else false


func get_min_depth(tile_id: int) -> int:
	var tile_def := get_tile_def(tile_id)
	return tile_def.min_depth if tile_def != null else 0


func get_is_hazard(tile_id: int) -> bool:
	var tile_def := get_tile_def(tile_id)
	return tile_def.is_hazard if tile_def != null else false


func get_hazard_damage(tile_id: int) -> float:
	var tile_def := get_tile_def(tile_id)
	return tile_def.hazard_damage if tile_def != null else 0.0


func get_hazard_type(tile_id: int) -> String:
	var tile_def := get_tile_def(tile_id)
	return tile_def.hazard_type if tile_def != null else ""


func get_support_beam_id() -> int:
	return SUPPORT_BEAM_ID


func get_power_cable_id() -> int:
	return POWER_CABLE_ID


func get_tile_ids_at_depth(depth: int) -> Array[int]:
	var valid_ids: Array[int] = []
	for tile_key: Variant in tiles.keys():
		var tile_id := int(tile_key)
		var tile_def := tiles[tile_key] as TileDef
		if tile_def != null and tile_def.min_depth <= depth:
			valid_ids.append(tile_id)
	return valid_ids


func validate_tile_id(tile_id: int) -> bool:
	return tiles.has(tile_id)


func _ready() -> void:
	if tiles.is_empty():
		_initialize_tiles()
	if not is_instance_valid(_instance):
		_instance = self


func _enter_tree() -> void:
	if not is_instance_valid(_instance):
		_instance = self


func _exit_tree() -> void:
	if _instance == self:
		_instance = null
