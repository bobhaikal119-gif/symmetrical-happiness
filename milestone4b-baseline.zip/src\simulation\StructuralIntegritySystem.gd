extends RefCounted

class_name StructuralIntegritySystem

"""
StructuralIntegritySystem: Pure-logic simulation of cave-ins and falling rubble.
Extends RefCounted and holds no Node, TileMapLayer, or Sprite2D references.
Detects unsupported ceilings wider than MAX_UNSUPPORTED_SPAN below 150m,
collapses loose overhead blocks down to the floor, and triggers
SignalBus.cave_in_triggered.
"""

const CAVE_IN_DEPTH_THRESHOLD: int = 150
const MAX_UNSUPPORTED_SPAN: int = 6

var world_grid: WorldGrid
var signal_bus: SignalBus

func _init(p_world_grid: WorldGrid = null, p_signal_bus: SignalBus = null) -> void:
	world_grid = p_world_grid
	signal_bus = p_signal_bus

func check_tile_break(x: int, y: int, _broken_tile_id: int = 0) -> Array[Vector2i]:
	var collapsed_tiles: Array[Vector2i] = []

	if world_grid == null:
		return collapsed_tiles

	if y < CAVE_IN_DEPTH_THRESHOLD:
		return collapsed_tiles

	var row: int = y - 1
	while row >= 0:
		var tile_id: int = world_grid.get_tile(x, row)
		if tile_id == WorldGrid.TILE_AIR or tile_id == WorldGrid.TILE_SUPPORT_BEAM:
			break
		var span: int = _get_unsupported_span(x, row)
		if span > MAX_UNSUPPORTED_SPAN:
			_trigger_cave_in(x, row, collapsed_tiles)
			break
		row -= 1

	return collapsed_tiles

func _get_unsupported_span(start_x: int, y: int) -> int:
	var count: int = 0

	var lx: int = start_x
	while world_grid.is_valid_position(lx, y):
		var tile_id: int = world_grid.get_tile(lx, y)
		if tile_id == WorldGrid.TILE_AIR or tile_id == WorldGrid.TILE_SUPPORT_BEAM:
			break
		if _is_support_below(lx, y):
			break
		count += 1
		lx -= 1

	var rx: int = start_x + 1
	while world_grid.is_valid_position(rx, y):
		var tile_id: int = world_grid.get_tile(rx, y)
		if tile_id == WorldGrid.TILE_AIR or tile_id == WorldGrid.TILE_SUPPORT_BEAM:
			break
		if _is_support_below(rx, y):
			break
		count += 1
		rx += 1

	return count

func _is_support_below(x: int, y: int) -> bool:
	if not world_grid.is_valid_position(x, y + 1):
		return true
	var below_id: int = world_grid.get_tile(x, y + 1)
	if below_id == WorldGrid.TILE_SUPPORT_BEAM:
		return true
	if below_id == WorldGrid.TILE_AIR or below_id == WorldGrid.TILE_LAVA or below_id == WorldGrid.TILE_ACID or below_id == WorldGrid.TILE_POWER_CABLE:
		return false
	return true

func _trigger_cave_in(origin_x: int, origin_y: int, collapsed_tiles: Array[Vector2i]) -> void:
	var detached: Array[Vector2i] = []
	var detached_types: Array[int] = []
	var visited: Dictionary = {}

	var stack: Array[Vector2i] = [Vector2i(origin_x, origin_y)]
	while stack.size() > 0:
		var pos: Vector2i = stack.pop_back()
		if visited.has(pos):
			continue
		if not world_grid.is_valid_position(pos.x, pos.y):
			continue
		var tid: int = world_grid.get_tile(pos.x, pos.y)
		if tid == WorldGrid.TILE_AIR or tid == WorldGrid.TILE_SUPPORT_BEAM or tid == WorldGrid.TILE_POWER_CABLE:
			continue

		var below_pos := Vector2i(pos.x, pos.y + 1)
		if not _is_support_below(pos.x, pos.y) or visited.has(below_pos):
			visited[pos] = true
			detached.append(pos)
			detached_types.append(tid)
			if detached.size() >= 64:
				break
			stack.push_back(Vector2i(pos.x, pos.y - 1))
			stack.push_back(Vector2i(pos.x - 1, pos.y))
			stack.push_back(Vector2i(pos.x + 1, pos.y))

	for pos in detached:
		var old_id: int = world_grid.get_tile(pos.x, pos.y)
		world_grid.set_tile(pos.x, pos.y, WorldGrid.TILE_AIR)
		if signal_bus != null:
			signal_bus.tile_broken.emit(pos, old_id)

	# Settle detached blocks downward onto the floor (bottom-most first)
	for i in range(detached.size()):
		var pos: Vector2i = detached[i]
		var tid: int = detached_types[i]
		var settle_pos: Vector2i = _simulate_falling(pos.x, pos.y, tid)
		collapsed_tiles.append(settle_pos)

	if signal_bus != null:
		signal_bus.cave_in_triggered.emit(Vector2i(origin_x, origin_y), collapsed_tiles)

func _simulate_falling(settle_x: int, settle_y: int, tile_id: int) -> Vector2i:
	var y: int = settle_y
	while world_grid.is_valid_position(settle_x, y + 1):
		var below_id: int = world_grid.get_tile(settle_x, y + 1)
		if below_id != WorldGrid.TILE_AIR and below_id != WorldGrid.TILE_LAVA and below_id != WorldGrid.TILE_ACID and below_id != WorldGrid.TILE_POWER_CABLE:
			break
		y += 1
	world_grid.set_tile(settle_x, y, tile_id)
	if signal_bus != null:
		signal_bus.tile_placed.emit(Vector2i(settle_x, y), tile_id)
	return Vector2i(settle_x, y)
