extends Resource

class_name WorldGrid

"""
WorldGrid: Pure logic world grid for DEEPWELL.
Stores a 512x512 tile grid with per-tile HP tracking, damage/break resolution,
and safe spawn calculation. Zero Node dependencies — pure data and logic.
Communicates via SignalBus for tile events.
"""

const GRID_SIZE := 512
const TILE_SIZE := 16

# Tile type IDs (matches TileRegistry registration order)
const TILE_AIR := 0
const TILE_SNOW := 1
const TILE_DIRT := 2
const TILE_STONE := 3
const TILE_IRON_ORE := 4
const TILE_COAL := 5
const TILE_COPPER := 6
const TILE_QUARTZ := 7
const TILE_TITANIUM := 8
const TILE_BIOLUME_STONE := 9
const TILE_BASALT := 10
const TILE_LAVA := 11
const TILE_ACID := 12
const TILE_SUPPORT_BEAM := 13
const TILE_POWER_CABLE := 14

# Biome depth boundaries
const BIOME_SURFACE_MAX := 63
const BIOME_CRUST_MAX := 191
const BIOME_BIOLUME_MAX := 319

# Grid storage: tile IDs
var grid: Array = []

# Per-tile HP tracking
var tile_hp: Array = []

# Set-like dictionary of Vector2i cable cells. This avoids scanning the full
# 512x512 grid whenever the power simulation rebuilds its circuits.
var _power_cable_positions: Dictionary = {}

# Seed for procedural generation
var seed: int = 0

func _init(seed_val: int = 0) -> void:
    """Initialize WorldGrid with seed and generate base strata.
    
    @param seed_val: Seed for deterministic generation.
    """
    seed = seed_val
    _ensure_power_cable_registered()
    initialize_grid()
    generate_strata()

func initialize_grid() -> void:
    """Initialize all grid cells to Air with full HP."""
    grid = []
    tile_hp = []
    _power_cable_positions.clear()
    for y in range(GRID_SIZE):
        var row: Array[int] = []
        var hp_row: Array[float] = []
        for x in range(GRID_SIZE):
            row.append(TILE_AIR)
            hp_row.append(0.0)
        grid.append(row)
        tile_hp.append(hp_row)

func generate_strata() -> void:
    """Generate base strata layers: Snow surface, Dirt, Stone below."""
    _power_cable_positions.clear()
    for y in range(GRID_SIZE):
        var depth: int = y
        for x in range(GRID_SIZE):
            if depth <= BIOME_SURFACE_MAX:
                # Surface: Snow
                grid[y][x] = TILE_SNOW
                tile_hp[y][x] = TileRegistry.get_instance().get_tile_max_hp(TILE_SNOW)
            elif depth <= BIOME_CRUST_MAX:
                # Crust: Dirt above, Stone below
                if depth < 96:
                    grid[y][x] = TILE_DIRT
                    tile_hp[y][x] = TileRegistry.get_instance().get_tile_max_hp(TILE_DIRT)
                else:
                    grid[y][x] = TILE_STONE
                    tile_hp[y][x] = TileRegistry.get_instance().get_tile_max_hp(TILE_STONE)
            elif depth <= BIOME_BIOLUME_MAX:
                # Biolume depths: Stone base
                grid[y][x] = TILE_STONE
                tile_hp[y][x] = TileRegistry.get_instance().get_tile_max_hp(TILE_STONE)
            else:
                # Magma faultline: Basalt
                grid[y][x] = TILE_BASALT
                tile_hp[y][x] = TileRegistry.get_instance().get_tile_max_hp(TILE_BASALT)

# Tile access

func get_tile(x: int, y: int) -> int:
    """Get tile ID at grid position.
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate (depth).
    @return Tile ID, or TILE_AIR if out of bounds.
    """
    if is_valid_position(x, y):
        return grid[y][x]
    return TILE_AIR

func set_tile(x: int, y: int, tile_id: int) -> void:
    """Set tile ID at grid position with full HP reset.
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate.
    @param tile_id: Tile ID to set.
    """
    if not is_valid_position(x, y):
        return
    var grid_pos: Vector2i = Vector2i(x, y)
    if grid[y][x] == TILE_POWER_CABLE:
        _power_cable_positions.erase(grid_pos)
    if tile_id == TILE_POWER_CABLE:
        _ensure_power_cable_registered()
        _power_cable_positions[grid_pos] = true
    grid[y][x] = tile_id
    var registry: TileRegistry = TileRegistry.get_instance()
    tile_hp[y][x] = registry.get_tile_max_hp(tile_id)

# Damage / break resolution

func damage_tile(x: int, y: int, damage: float) -> bool:
    """Apply damage to a tile. Returns true if tile broke.
    Emits SignalBus.tile_damaged or SignalBus.tile_broken.
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate.
    @param damage: Damage amount to apply.
    @return True if tile was broken.
    """
    if not is_valid_position(x, y):
        return false
    
    var tile_id: int = int(grid[y][x])
    
    # Air and hazards are indestructible
    if tile_id == TILE_AIR or tile_id == TILE_LAVA or tile_id == TILE_ACID:
        return false
    
    tile_hp[y][x] -= damage
    var registry: TileRegistry = TileRegistry.get_instance()
    var max_hp: float = registry.get_tile_max_hp(tile_id)
    
    if tile_hp[y][x] <= 0:
        break_tile(x, y)
        SignalBus.get_instance().tile_broken.emit(Vector2i(x, y), tile_id)
        return true
    else:
        SignalBus.get_instance().tile_damaged.emit(Vector2i(x, y), tile_hp[y][x], max_hp)
        return false

func break_tile(x: int, y: int) -> void:
    """Break a tile, replacing it with Air.
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate.
    """
    if not is_valid_position(x, y):
        return
    
    if grid[y][x] == TILE_POWER_CABLE:
        _power_cable_positions.erase(Vector2i(x, y))
    grid[y][x] = TILE_AIR
    tile_hp[y][x] = 0.0
    SignalBus.get_instance().tile_placed.emit(Vector2i(x, y), TILE_AIR)

func is_power_cable(position_or_x: Variant, y: int = -1) -> bool:
    """Check a cable cell by Vector2i or by separate x/y coordinates."""
    var grid_pos: Vector2i
    if typeof(position_or_x) == TYPE_VECTOR2I:
        grid_pos = position_or_x
    elif typeof(position_or_x) == TYPE_INT:
        grid_pos = Vector2i(int(position_or_x), y)
    else:
        return false
    return _power_cable_positions.has(grid_pos)

func get_power_cable_positions() -> Array[Vector2i]:
    """Return a typed snapshot of all cable cells."""
    var positions: Array[Vector2i] = []
    for position: Variant in _power_cable_positions.keys():
        positions.append(position)
    return positions

func _ensure_power_cable_registered() -> void:
    """Install cable metadata when the shared registry has not done so yet."""
    var registry: TileRegistry = TileRegistry.get_instance()
    var cable_def: TileDef = registry.get_tile_def(TILE_POWER_CABLE)
    if cable_def == null:
        cable_def = TileDef.new()
        cable_def.id = TILE_POWER_CABLE
        cable_def.tile_name = "PowerCable"
        cable_def.max_hp = 3.0
        cable_def.color = Color(0.95, 0.55, 0.12, 1.0)
        cable_def.min_depth = 0
        registry.tiles[TILE_POWER_CABLE] = cable_def
    # The cable is a conduit laid through open space, never collision terrain.
    cable_def.is_solid = false

# Position validation

func is_valid_position(x: int, y: int) -> bool:
    """Check if grid position is within bounds.
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate.
    @return True if position is valid.
    """
    return x >= 0 and x < GRID_SIZE and y >= 0 and y < GRID_SIZE

# Safe spawn calculation

func find_safe_spawn() -> Vector2:
    """Find a safe spawn position on the surface.
    Searches from top (y=0) downward for the first solid tile,
    then spawns directly above it (never inside terrain).
    
    @return World position of a safe spawn point.
    """
    var center_x: int = GRID_SIZE / 2
    for offset in range(0, GRID_SIZE / 2, 4):
        var candidates: Array[int] = [center_x + offset, center_x - offset]
        for x: int in candidates:
            if x < 0 or x >= GRID_SIZE:
                continue
            for y in range(0, 64):
                var tile_id: int = int(grid[y][x])
                if TileRegistry.get_instance().get_is_solid(tile_id):
                    var spawn_y: int = maxi(0, y - 1)
                    return Vector2(
                        float(x * TILE_SIZE) + float(TILE_SIZE) * 0.5,
                        float(spawn_y * TILE_SIZE) + float(TILE_SIZE) * 0.5
                    )
    return Vector2(float(center_x * TILE_SIZE), 0.0)

# Depth and biome queries

func get_depth_at(x: int, y: int) -> int:
    """Get depth in tiles at grid position (y-coordinate).
    
    @param x: Grid X coordinate.
    @param y: Grid Y coordinate.
    @return Depth value (y).
    """
    return y

func get_biome_at_depth(depth: int) -> String:
    """Get biome name for a given depth level.
    
    @param depth: Depth in tiles.
    @return Biome name string.
    """
    if depth <= BIOME_SURFACE_MAX:
        return "Permafrost Surface"
    elif depth <= BIOME_CRUST_MAX:
        return "Shattered Crust"
    elif depth <= BIOME_BIOLUME_MAX:
        return "Fungal Biolume Depths"
    else:
        return "Magma Faultline"

func get_tile_id_at_depth(depth: int) -> int:
    """Get the default tile ID for a given depth.
    
    @param depth: Depth in tiles.
    @return Default tile ID for this depth.
    """
    if depth <= BIOME_SURFACE_MAX:
        return TILE_SNOW
    elif depth < 96:
        return TILE_DIRT
    elif depth <= BIOME_CRUST_MAX:
        return TILE_STONE
    elif depth <= BIOME_BIOLUME_MAX:
        return TILE_STONE
    else:
        return TILE_BASALT
