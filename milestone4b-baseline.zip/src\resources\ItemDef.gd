extends Resource

class_name ItemDef

"""
ItemDef: Data definition for an inventory item.
Describes an item type used by crafting and placement systems.
"""

# Item identification

@export var id: String = ""
"""Unique identifier for the item.
"""

@export var display_name: String = "Item"
"""Human-readable name shown in UI.
"""

@export var stack_size: int = 99
"""Maximum stack size for this item.
"""

@export var is_consumable: bool = false
"""True if the item is consumed on use (e.g. oxygen canister).
"""
