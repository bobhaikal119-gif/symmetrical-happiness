# DEEPWELL — Milestone 4A Settings Suite

Procedural 16×16-pixel survival/mining game targeting **Godot 4.7.2**. Open [project.godot](<project.godot>) in Godot and run the main scene. No external art assets or packages are required.

## Pause and settings

Press **Esc** to open/close the settings suite. Settings changes apply immediately and persist to `user://settings.cfg` through `ConfigFile`. The default Windows location is `%APPDATA%\Godot\app_userdata\DEEPWELL\settings.cfg`.

- **General:** screen shake (0–150%), floating damage/pickup notices, automatic pause in crafting menus, HUD scale (0.75–1.5×).
- **Profile:** Pioneer name, suit/visor tint, active world seed, confirmed session reset. Session reset rebuilds the current world and inventory, but retains preferences.
- **Graphics:** windowed/borderless fullscreen, VSync, ambient darkness and pixel snapping.
- **Optimization:** active render radius (24–128 tiles), full dynamic lighting or fast glow rendering, effect/drop budget, 30/60/120/unlimited FPS and the performance overlay.
- **Controls:** keyboard remapping, duplicate-key conflict feedback, keyboard-only reset, Smart Cursor, aim smoothing and swapped mining/placement mouse buttons.

The settings suite always pauses gameplay. Crafting pauses only when Auto-Pause is enabled; gameplay controls remain blocked while a menu is open even when the simulation continues. Escape cancels a pending keyboard capture before closing the settings suite.

## Default controls

| Action | Default |
| --- | --- |
| Move | A/D or Left/Right |
| Jump | Space |
| Mine | Left mouse or Q |
| Place/use selected item | Right mouse or E |
| Crafting | C or Tab |
| Smart Cursor | Ctrl or HUD badge |
| Select hotbar | 1–9 |
| Flashlight | L |
| Settings / pause | Esc |

Smart Cursor chooses the next logical block along the aim direction within tool reach. The grid reticle is **yellow** for an assisted lock, **cyan** for direct aim and **red** beyond reach. Keyboard remapping replaces only keyboard events, never mouse bindings. Keyboard-only reset preserves the profile and mouse preferences.

## Architecture

- [SettingsManager](<src/autoload/SettingsManager.gd>) is the sole persistent settings/InputMap service. It owns the six sections and broadcasts settings events; it has no `class_name` to avoid colliding with its autoload name.
- [SignalBus](<src/autoload/SignalBus.gd>) retains every existing gameplay signal contract. Settings add `setting_changed`, `keybinds_updated`, `smart_cursor_toggled`, plus menu/reset lifecycle requests.
- [WorldRenderer](<src/presentation/WorldRenderer.gd>) manages procedural TileMapLayer chunks independently of world simulation and collision safety. Render distance does not erase world data.
- [CursorReticle](<src/presentation/CursorReticle.gd>) shares smoothed aim/target resolution between the tools, so the highlighted cell and actual target agree.
- [Main](<src/main/Main.gd>) composes simulation dependencies, pause reasons, session reset, scaled shake and effect budgets.
- [SettingsMenu](<src/ui/SettingsMenu.gd>) edits the settings service; [HudController](<src/ui/HudController.gd>) uses signals rather than Player/WorldGrid references.

Fast lighting substitutes lightweight additive procedural glows for PointLight2D lighting while preserving each source's gameplay enable/visibility state. Drop budgeting merges stacks or safely credits collected items instead of silently discarding earned resources.

## Validation

Run from the project root (use the installed Godot executable name on Windows):

```powershell
Godot_v4.7.2-stable_win64_console.exe --headless --path . --editor --quit
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/compiler_warnings.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_smoke.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_input.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_reset.gd
Godot_v4.7.2-stable_win64_console.exe --path . --rendering-method gl_compatibility --script res://tests/milestone4a_visual.gd
python tests/audit_resources.py
```

The smoke test restores the original settings-file bytes after exercising persistence and gameplay integration. The Python audit checks literal resource paths, duplicate global classes, autoload shadowing and unfinished code markers. The baseline archive retained at the project root supports checking that all pre-existing SignalBus contracts remain unchanged.
