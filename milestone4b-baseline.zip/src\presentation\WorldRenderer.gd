extends Node2D

class_name WorldRenderer

## The grid remains authoritative. Chunk layers contain visual tiles only;
## the separate viewport collision body never depends on render distance.

const GRID_SIZE: int = 512
const TILE_SIZE: int = 16
const ATLAS_COLUMNS: int = 4
const TILE_COUNT: int = 15
const CHUNK_SIZE: int = 16
const REDRAW_ANIMATION_INTERVAL: float = 0.14

const TILE_AIR := 0
const TILE_SNOW := 1
const TILE_DIRT := 2
const TILE_STONE := 3
const TILE_IRON_ORE := 4
const TILE_COAL := 5
const TILE_COPPER := 6
const TILE_QUARTZ := 7
const TILE_TITANIUM := 8
const TILE_BIOLUME_STONE := 9
const TILE_BASALT := 10
const TILE_LAVA := 11
const TILE_ACID := 12
const TILE_SUPPORT_BEAM := 13
const TILE_POWER_CABLE := 14

@export var world_grid: WorldGrid

var _atlas_texture: ImageTexture = null
var _tile_set: TileSet
var _tile_atlas_coords: Dictionary = {}
var _chunks: Dictionary = {}
var _chunk_bounds: Dictionary = {}
var _chunk_animated_cells: Dictionary = {}
var _render_distance: int = 64
var _last_visible_bounds := Rect2i()
var _last_viewport_bounds := Rect2i()
var _animation_time: float = 0.0
var _animation_redraw_elapsed: float = 0.0
var _collision_body: StaticBody2D
var _collision_bounds := Rect2i()
var _collision_viewport_bounds := Rect2i()
var _collision_rebuild_queued: bool = false
var _lighting_quality: int = 0
var _managed_lights: Dictionary = {}


func _ready() -> void:
	_build_tile_data()
	_create_procedural_atlas()
	_create_tile_set()
	_render_distance = clampi(int(SettingsManager.get_setting("optimization", "render_distance", 64)), 24, 128)
	_collision_body = StaticBody2D.new()
	_collision_body.name = "GameplayWorldCollision"
	_collision_body.collision_layer = 1
	_collision_body.collision_mask = 1
	add_child(_collision_body)
	_connect_signals()
	_lighting_quality = int(SettingsManager.get_setting("optimization", "lighting_quality", 0))
	# Run after light producers have initialized their procedural textures.
	process_priority = 90
	get_tree().node_added.connect(_on_light_node_added)
	call_deferred(&"_discover_scene_lights")
	sync_all_tiles()


func _build_tile_data() -> void:
	_tile_atlas_coords.clear()
	for tile_id: int in range(TILE_COUNT):
		_tile_atlas_coords[tile_id] = Vector2i(tile_id % ATLAS_COLUMNS, int(tile_id / ATLAS_COLUMNS))


func _create_procedural_atlas() -> void:
	var atlas_rows: int = ceili(float(TILE_COUNT) / float(ATLAS_COLUMNS))
	var atlas := Image.create(ATLAS_COLUMNS * TILE_SIZE, atlas_rows * TILE_SIZE, false, Image.FORMAT_RGBA8)
	for tile_id: int in range(TILE_COUNT):
		var atlas_coords: Vector2i = _tile_atlas_coords[tile_id]
		var origin := atlas_coords * TILE_SIZE
		for pixel_y: int in range(TILE_SIZE):
			for pixel_x: int in range(TILE_SIZE):
				atlas.set_pixel(origin.x + pixel_x, origin.y + pixel_y, _procedural_pixel(tile_id, pixel_x, pixel_y))
	_atlas_texture = ImageTexture.create_from_image(atlas)


func _create_tile_set() -> void:
	_tile_set = TileSet.new()
	_tile_set.tile_size = Vector2i(TILE_SIZE, TILE_SIZE)
	var source := TileSetAtlasSource.new()
	source.texture = _atlas_texture
	source.texture_region_size = Vector2i(TILE_SIZE, TILE_SIZE)
	for tile_id: int in range(1, TILE_COUNT):
		source.create_tile(_tile_atlas_coords[tile_id])
	_tile_set.add_source(source, 0)


func _procedural_pixel(tile_id: int, x: int, y: int) -> Color:
	if tile_id == TILE_AIR:
		return Color(0.0, 0.0, 0.0, 0.0)
	if tile_id == TILE_SUPPORT_BEAM:
		return _support_beam_pixel(x, y)
	if tile_id == TILE_POWER_CABLE:
		return _power_cable_pixel(x, y)
	var base: Color = _get_tile_color(tile_id)
	var noise_value: float = float(_pixel_hash(tile_id, x, y) % 100) / 100.0
	var shade: float = 0.82 + noise_value * 0.18
	if x == 0 or y == 0:
		shade += 0.10
	if x == TILE_SIZE - 1 or y == TILE_SIZE - 1:
		shade -= 0.16
	var result: Color = _shade_color(base, shade)
	match tile_id:
		TILE_SNOW:
			if y <= 2:
				result = Color(0.98, 0.99, 1.0, 1.0)
			elif y >= 12:
				result = result.lerp(Color(0.55, 0.68, 0.78, 1.0), 0.22)
		TILE_DIRT:
			if _pixel_hash(tile_id + 19, x, y) % 17 == 0:
				result = Color(0.30, 0.18, 0.09, 1.0)
		TILE_STONE:
			if (x + y * 3 + tile_id) % 19 == 0:
				result = Color(0.23, 0.25, 0.29, 1.0)
		TILE_IRON_ORE:
			result = _ore_fleck(result, x, y, Color(0.83, 0.49, 0.25, 1.0), 9)
		TILE_COAL:
			result = _ore_fleck(result, x, y, Color(0.04, 0.05, 0.07, 1.0), 7)
		TILE_COPPER:
			result = _ore_fleck(result, x, y, Color(1.0, 0.53, 0.13, 1.0), 8)
		TILE_QUARTZ:
			result = _ore_fleck(result, x, y, Color(0.80, 1.0, 1.0, 1.0), 7)
		TILE_TITANIUM:
			result = _ore_fleck(result, x, y, Color(0.72, 0.84, 1.0, 1.0), 10)
		TILE_BIOLUME_STONE:
			if _pixel_hash(tile_id + 31, x, y) % 13 <= 1:
				result = Color(0.27, 1.0, 0.67, 1.0)
		TILE_BASALT:
			if (x * 2 + y * 5) % 23 <= 1:
				result = Color(0.10, 0.11, 0.15, 1.0)
		TILE_LAVA:
			if (y + int(sin(float(x) * 0.8) * 2.0)) % 6 <= 1:
				result = Color(1.0, 0.72, 0.08, 1.0)
		TILE_ACID:
			var bubble_distance := Vector2(float(x - 5), float(y - 6)).length()
			if bubble_distance > 1.4 and bubble_distance < 2.4:
				result = Color(0.72, 1.0, 0.18, 1.0)
	return result


func _ore_fleck(background: Color, x: int, y: int, ore_color: Color, spacing: int) -> Color:
	var pattern: int = _pixel_hash(spacing, x, y) % spacing
	if pattern <= 1 and x > 1 and y > 1 and x < 14 and y < 14:
		return ore_color if pattern == 0 else ore_color.darkened(0.25)
	return background


func _support_beam_pixel(x: int, y: int) -> Color:
	var frame: bool = x == 2 or x == 3 or x == 12 or x == 13
	frame = frame or y == 2 or y == 3 or y == 12 or y == 13
	var diagonal: bool = abs(x - y) <= 1 or abs((TILE_SIZE - 1 - x) - y) <= 1
	if not frame and not diagonal:
		return Color(0.04, 0.06, 0.09, 0.20)
	var highlight: bool = x == 2 or y == 2 or ((x + y) % 5 == 0)
	return Color(0.66, 0.73, 0.82, 1.0) if highlight else Color(0.29, 0.34, 0.43, 1.0)


func _power_cable_pixel(x: int, y: int) -> Color:
	var center := Vector2(7.5, 7.5)
	var distance: float = Vector2(float(x), float(y)).distance_to(center)
	if distance <= 2.0:
		return Color(1.0, 0.76, 0.18, 1.0)
	if distance <= 3.3:
		return Color(0.70, 0.31, 0.08, 1.0)
	if distance <= 4.2 and (x + y) % 2 == 0:
		return Color(1.0, 0.62, 0.10, 0.42)
	return Color(0.03, 0.04, 0.06, 0.12)


func _pixel_hash(tile_id: int, x: int, y: int) -> int:
	return absi(tile_id * 92821 + x * 68917 + y * 28387 + x * y * 101)


func _shade_color(color: Color, shade: float) -> Color:
	return Color(clampf(color.r * shade, 0.0, 1.0), clampf(color.g * shade, 0.0, 1.0), clampf(color.b * shade, 0.0, 1.0), color.a)


func _get_tile_color(tile_id: int) -> Color:
	var tile_def := TileRegistry.get_instance().get_tile_def(tile_id)
	if tile_def != null:
		return tile_def.color
	match tile_id:
		TILE_AIR: return Color.TRANSPARENT
		TILE_SNOW: return Color(0.91, 0.95, 1.0, 1.0)
		TILE_DIRT: return Color(0.57, 0.36, 0.17, 1.0)
		TILE_STONE: return Color(0.42, 0.44, 0.48, 1.0)
		TILE_IRON_ORE: return Color(0.43, 0.40, 0.39, 1.0)
		TILE_COAL: return Color(0.25, 0.26, 0.28, 1.0)
		TILE_COPPER: return Color(0.47, 0.40, 0.34, 1.0)
		TILE_QUARTZ: return Color(0.47, 0.51, 0.57, 1.0)
		TILE_TITANIUM: return Color(0.42, 0.48, 0.57, 1.0)
		TILE_BIOLUME_STONE: return Color(0.20, 0.42, 0.34, 1.0)
		TILE_BASALT: return Color(0.18, 0.19, 0.23, 1.0)
		TILE_LAVA: return Color(0.91, 0.20, 0.03, 1.0)
		TILE_ACID: return Color(0.20, 0.77, 0.13, 1.0)
		TILE_SUPPORT_BEAM: return Color(0.55, 0.62, 0.72, 1.0)
		TILE_POWER_CABLE: return Color(0.95, 0.55, 0.12, 1.0)
		_: return Color.MAGENTA


func get_active_chunk_count() -> int:
	return _chunks.size()


func get_rendered_tile_bounds() -> Rect2i:
	return _last_visible_bounds


func sync_all_tiles() -> void:
	for value: Variant in _chunks.values():
		var layer: TileMapLayer = value as TileMapLayer
		layer.hide()
		layer.queue_free()
	_chunks.clear()
	_chunk_bounds.clear()
	_chunk_animated_cells.clear()
	_last_visible_bounds = Rect2i()
	if world_grid != null and _tile_set != null:
		_update_chunks(_get_visible_tile_bounds())
	queue_redraw()
	_schedule_collision_rebuild()


func sync_tile(x: int, y: int) -> void:
	if world_grid == null or x < 0 or x >= GRID_SIZE or y < 0 or y >= GRID_SIZE:
		return
	var grid_pos := Vector2i(x, y)
	var chunk_pos := Vector2i(floori(float(x) / CHUNK_SIZE), floori(float(y) / CHUNK_SIZE))
	if _chunks.has(chunk_pos):
		# Patch one resident cell; unseen chunks rebuild from the grid on entry.
		var bounds: Rect2i = _chunk_bounds[chunk_pos]
		if bounds.has_point(grid_pos):
			var layer: TileMapLayer = _chunks[chunk_pos] as TileMapLayer
			var tile_id: int = world_grid.get_tile(x, y)
			var local_cell: Vector2i = grid_pos - chunk_pos * CHUNK_SIZE
			if tile_id == TILE_AIR or not _tile_atlas_coords.has(tile_id):
				layer.erase_cell(local_cell)
			else:
				layer.set_cell(local_cell, 0, _tile_atlas_coords[tile_id])
			var animated: Array = _chunk_animated_cells[chunk_pos]
			animated.erase(grid_pos)
			if tile_id == TILE_POWER_CABLE or tile_id == TILE_LAVA or tile_id == TILE_ACID:
				animated.append(grid_pos)
	queue_redraw()
	if _collision_bounds.has_point(grid_pos):
		_schedule_collision_rebuild()


func _update_chunks(bounds: Rect2i) -> void:
	if world_grid == null or _tile_set == null or not bounds.has_area():
		return
	var required: Dictionary = {}
	var first := Vector2i(floori(float(bounds.position.x) / CHUNK_SIZE), floori(float(bounds.position.y) / CHUNK_SIZE))
	var last := Vector2i(floori(float(bounds.end.x - 1) / CHUNK_SIZE), floori(float(bounds.end.y - 1) / CHUNK_SIZE))
	for cy: int in range(first.y, last.y + 1):
		for cx: int in range(first.x, last.x + 1):
			var chunk_pos := Vector2i(cx, cy)
			required[chunk_pos] = true
			var clipped: Rect2i = Rect2i(chunk_pos * CHUNK_SIZE, Vector2i.ONE * CHUNK_SIZE).intersection(bounds)
			if not _chunks.has(chunk_pos):
				var layer := TileMapLayer.new()
				layer.name = "TileChunk_%d_%d" % [cx, cy]
				layer.tile_set = _tile_set
				# Align the atlas cell center with the grid's top-left-based
				# world coordinates without assuming TileMap's local origin.
				layer.position = Vector2(chunk_pos * CHUNK_SIZE * TILE_SIZE) + Vector2.ONE * (TILE_SIZE * 0.5) - layer.map_to_local(Vector2i.ZERO)
				layer.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
				layer.rendering_quadrant_size = CHUNK_SIZE
				layer.collision_enabled = false
				layer.navigation_enabled = false
				layer.z_index = -1
				add_child(layer)
				_chunks[chunk_pos] = layer
			if not _chunk_bounds.has(chunk_pos) or _chunk_bounds[chunk_pos] != clipped:
				_populate_chunk(chunk_pos, clipped)
	for value: Variant in _chunks.keys():
		var chunk_pos: Vector2i = value
		if required.has(chunk_pos):
			continue
		var layer: TileMapLayer = _chunks[chunk_pos] as TileMapLayer
		layer.hide()
		layer.queue_free()
		_chunks.erase(chunk_pos)
		_chunk_bounds.erase(chunk_pos)
		_chunk_animated_cells.erase(chunk_pos)
	_last_visible_bounds = bounds
	queue_redraw()


func _populate_chunk(chunk_pos: Vector2i, bounds: Rect2i) -> void:
	var layer: TileMapLayer = _chunks[chunk_pos] as TileMapLayer
	layer.clear()
	var animated: Array[Vector2i] = []
	for y: int in range(bounds.position.y, bounds.end.y):
		for x: int in range(bounds.position.x, bounds.end.x):
			var tile_id: int = world_grid.get_tile(x, y)
			if tile_id == TILE_AIR or not _tile_atlas_coords.has(tile_id):
				continue
			var grid_pos := Vector2i(x, y)
			layer.set_cell(grid_pos - chunk_pos * CHUNK_SIZE, 0, _tile_atlas_coords[tile_id])
			if tile_id == TILE_POWER_CABLE or tile_id == TILE_LAVA or tile_id == TILE_ACID:
				animated.append(grid_pos)
	_chunk_bounds[chunk_pos] = bounds
	_chunk_animated_cells[chunk_pos] = animated


func _schedule_collision_rebuild() -> void:
	if _collision_rebuild_queued or not is_inside_tree():
		return
	_collision_rebuild_queued = true
	call_deferred(&"_rebuild_visible_collisions")


func _rebuild_visible_collisions() -> void:
	_collision_rebuild_queued = false
	if world_grid == null or _collision_body == null:
		return
	for child: Node in _collision_body.get_children():
		child.free()
	# Deliberately not _get_visible_tile_bounds(): shrinking visual radius cannot
	# remove floors/walls in the viewport or around active offscreen bodies.
	var gameplay_bounds: Rect2i = _get_gameplay_tile_bounds()
	_collision_viewport_bounds = gameplay_bounds
	var start_x: int = maxi(0, gameplay_bounds.position.x - 4)
	var start_y: int = maxi(0, gameplay_bounds.position.y - 4)
	var end_x: int = mini(GRID_SIZE, gameplay_bounds.end.x + 4)
	var end_y: int = mini(GRID_SIZE, gameplay_bounds.end.y + 4)
	_collision_bounds = Rect2i(start_x, start_y, end_x - start_x, end_y - start_y)
	var registry: TileRegistry = TileRegistry.get_instance()
	for y: int in range(start_y, end_y):
		var run_start: int = -1
		for x: int in range(start_x, end_x + 1):
			var is_solid: bool = x < end_x and registry.get_is_solid(world_grid.get_tile(x, y))
			if is_solid and run_start < 0:
				run_start = x
			elif not is_solid and run_start >= 0:
				_add_collision_run(run_start, x, y)
				run_start = -1


func _add_collision_run(start_x: int, end_x: int, y: int) -> void:
	var width_tiles: int = end_x - start_x
	if width_tiles <= 0:
		return
	var shape := RectangleShape2D.new()
	shape.size = Vector2(float(width_tiles * TILE_SIZE), float(TILE_SIZE))
	var collision := CollisionShape2D.new()
	collision.shape = shape
	collision.position = Vector2(float(start_x * TILE_SIZE) + shape.size.x * 0.5, float(y * TILE_SIZE) + float(TILE_SIZE) * 0.5)
	_collision_body.add_child(collision)


func _draw() -> void:
	if world_grid == null:
		return
	var bounds: Rect2i = _get_viewport_tile_bounds().intersection(_last_visible_bounds)
	for cells: Array in _chunk_animated_cells.values():
		for grid_pos: Vector2i in cells:
			if not bounds.has_point(grid_pos):
				continue
			var tile_id: int = world_grid.get_tile(grid_pos.x, grid_pos.y)
			if tile_id == TILE_POWER_CABLE:
				_draw_cable_connections(grid_pos)
			elif tile_id == TILE_LAVA or tile_id == TILE_ACID:
				_draw_hazard_glint(grid_pos, tile_id)


func _draw_cable_connections(grid_pos: Vector2i) -> void:
	var center := Vector2(grid_pos * TILE_SIZE) + Vector2(7.5, 7.5)
	var pulse: float = 0.58 + sin(_animation_time * 5.0) * 0.16
	for direction: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		var neighbor := grid_pos + direction
		if not _last_visible_bounds.has_point(neighbor) or world_grid.get_tile(neighbor.x, neighbor.y) != TILE_POWER_CABLE:
			continue
		var endpoint := center + Vector2(direction) * 8.5
		draw_line(center, endpoint, Color(0.17, 0.08, 0.03, 1.0), 5.0)
		draw_line(center, endpoint, Color(0.83, 0.36, 0.07, 1.0), 3.0)
		draw_line(center, endpoint, Color(1.0, 0.78, 0.24, pulse), 1.0)
	draw_circle(center, 2.0, Color(1.0, 0.80, 0.26, pulse + 0.15))


func _draw_hazard_glint(grid_pos: Vector2i, tile_id: int) -> void:
	var center := Vector2(grid_pos * TILE_SIZE) + Vector2(8.0, 8.0)
	var wave: float = 0.5 + sin(_animation_time * (5.0 if tile_id == TILE_LAVA else 3.0)) * 0.5
	var glow_color := Color(1.0, 0.68, 0.08, 0.08 + wave * 0.12)
	if tile_id == TILE_ACID:
		glow_color = Color(0.54, 1.0, 0.18, 0.07 + wave * 0.11)
	draw_circle(center, 5.0 + wave, glow_color)


func _get_visible_tile_bounds() -> Rect2i:
	if not is_inside_tree():
		return Rect2i()
	var inverse_view_transform: Transform2D = get_global_transform_with_canvas().affine_inverse()
	var center: Vector2 = inverse_view_transform * (get_viewport_rect().size * 0.5)
	var center_cell := Vector2i(floori(center.x / TILE_SIZE), floori(center.y / TILE_SIZE))
	var start := Vector2i(maxi(0, center_cell.x - _render_distance), maxi(0, center_cell.y - _render_distance))
	var end := Vector2i(mini(GRID_SIZE, center_cell.x + _render_distance + 1), mini(GRID_SIZE, center_cell.y + _render_distance + 1))
	return Rect2i(start, Vector2i(maxi(0, end.x - start.x), maxi(0, end.y - start.y)))


func _get_viewport_tile_bounds() -> Rect2i:
	if not is_inside_tree():
		return Rect2i(0, 0, GRID_SIZE, GRID_SIZE)
	var inverse_view_transform: Transform2D = get_global_transform_with_canvas().affine_inverse()
	var local_a: Vector2 = inverse_view_transform * Vector2.ZERO
	var local_b: Vector2 = inverse_view_transform * get_viewport_rect().size
	var local_min := Vector2(minf(local_a.x, local_b.x), minf(local_a.y, local_b.y))
	var local_max := Vector2(maxf(local_a.x, local_b.x), maxf(local_a.y, local_b.y))
	var start_x: int = clampi(floori(local_min.x / TILE_SIZE) - 2, 0, GRID_SIZE)
	var start_y: int = clampi(floori(local_min.y / TILE_SIZE) - 2, 0, GRID_SIZE)
	var end_x: int = clampi(ceili(local_max.x / TILE_SIZE) + 2, 0, GRID_SIZE)
	var end_y: int = clampi(ceili(local_max.y / TILE_SIZE) + 2, 0, GRID_SIZE)
	return Rect2i(start_x, start_y, end_x - start_x, end_y - start_y)


func _get_gameplay_tile_bounds() -> Rect2i:
	var bounds: Rect2i = _get_viewport_tile_bounds()
	if not is_inside_tree():
		return bounds
	# Enemies may still simulate just beyond the screen. Keep their nearby
	# terrain solid too; no gameplay body is culled by a graphics preference.
	for group_name: StringName in [&"player", &"enemies"]:
		for candidate: Node in get_tree().get_nodes_in_group(group_name):
			var body: Node2D = candidate as Node2D
			if body == null or body.is_queued_for_deletion():
				continue
			var local_position: Vector2 = to_local(body.global_position)
			var cell := Vector2i(floori(local_position.x / TILE_SIZE), floori(local_position.y / TILE_SIZE))
			var body_bounds := Rect2i(cell - Vector2i(3, 3), Vector2i(7, 7))
			bounds = bounds.merge(body_bounds)
	return bounds.intersection(Rect2i(0, 0, GRID_SIZE, GRID_SIZE))


func _connect_signals() -> void:
	var signal_bus := SignalBus.get_instance()
	signal_bus.tile_damaged.connect(_on_signal_bus_tile_damaged)
	signal_bus.tile_broken.connect(_on_signal_bus_tile_broken)
	signal_bus.tile_placed.connect(_on_signal_bus_tile_placed)
	signal_bus.setting_changed.connect(_on_setting_changed)


func _on_signal_bus_tile_damaged(grid_pos: Vector2i, _current_hp: float, _max_hp: float) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _on_signal_bus_tile_broken(grid_pos: Vector2i, _tile_id: int) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _on_signal_bus_tile_placed(grid_pos: Vector2i, _tile_id: int) -> void:
	sync_tile(grid_pos.x, grid_pos.y)


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section != "optimization":
		return
	if key == "render_distance":
		_render_distance = clampi(int(value), 24, 128)
		_update_chunks(_get_visible_tile_bounds())
	elif key == "lighting_quality":
		_lighting_quality = clampi(int(value), 0, 1)
		_update_managed_lights()


func _discover_scene_lights() -> void:
	# Lights live beside the renderer under Player/MachineContainer, so scope
	# discovery to our world root rather than just this renderer's children.
	var world_root: Node = get_parent()
	if world_root != null:
		_register_light_subtree(world_root)


func _register_light_subtree(root: Node) -> void:
	if root is PointLight2D:
		_register_light(root)
	for child: Node in root.get_children():
		_register_light_subtree(child)


func _on_light_node_added(node: Node) -> void:
	if node is PointLight2D:
		# node_added precedes the producer's _ready procedural texture setup.
		call_deferred(&"_register_light", node)


func _register_light(node: Node) -> void:
	if not is_instance_valid(node) or node.is_queued_for_deletion():
		return
	var world_root: Node = get_parent()
	if world_root == null or not world_root.is_ancestor_of(node):
		return
	var light: PointLight2D = node as PointLight2D
	if light == null:
		return
	var id: int = light.get_instance_id()
	if not _managed_lights.has(id):
		_managed_lights[id] = {"node": light, "texture": light.texture, "shadow": light.shadow_enabled, "fast": false, "glow": null}
	_apply_light_quality(_managed_lights[id])


func _update_managed_lights() -> void:
	for id: Variant in _managed_lights.keys():
		var entry: Dictionary = _managed_lights[id]
		if not is_instance_valid(entry["node"]):
			_managed_lights.erase(id)
			continue
		var light: PointLight2D = entry["node"] as PointLight2D
		if light.is_queued_for_deletion():
			_managed_lights.erase(id)
			continue
		_apply_light_quality(entry)


func _apply_light_quality(entry: Dictionary) -> void:
	var light: PointLight2D = entry["node"] as PointLight2D
	var was_fast: bool = bool(entry["fast"])
	var glow: Sprite2D = entry["glow"] as Sprite2D
	if _lighting_quality == 0:
		if was_fast:
			light.texture = entry["texture"] as Texture2D
			light.shadow_enabled = bool(entry["shadow"])
		entry["texture"] = light.texture
		entry["shadow"] = light.shadow_enabled
		entry["fast"] = false
		if is_instance_valid(glow):
			glow.visible = false
		return
	# Cache late/replaced procedural textures. Removing the texture turns off
	# the actual PointLight2D render pass, unlike merely dimming its energy.
	if light.texture != null:
		entry["texture"] = light.texture
	if not was_fast:
		entry["shadow"] = light.shadow_enabled
	if not is_instance_valid(glow):
		glow = Sprite2D.new()
		glow.name = "FastLightGlow"
		var glow_material := CanvasItemMaterial.new()
		glow_material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		glow_material.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		glow.material = glow_material
		glow.z_index = 2
		light.add_child(glow)
		entry["glow"] = glow
	glow.texture = entry["texture"] as Texture2D
	glow.position = light.offset
	glow.scale = Vector2.ONE * light.texture_scale
	glow.modulate = Color(light.color.r, light.color.g, light.color.b, clampf(light.energy * 0.65, 0.0, 1.0))
	glow.visible = light.enabled and light.energy > 0.0 and glow.texture != null
	light.texture = null
	light.shadow_enabled = false
	entry["fast"] = true
	# Do not write visible/enabled or BatteryComponent: producers still own
	# flashlight intent, depletion, fueled generator state, and heater power.


func _process(delta: float) -> void:
	_update_managed_lights()
	_animation_time += delta
	var visible_bounds: Rect2i = _get_visible_tile_bounds()
	if visible_bounds != _last_visible_bounds:
		_update_chunks(visible_bounds)
	var viewport_bounds: Rect2i = _get_viewport_tile_bounds()
	if viewport_bounds != _last_viewport_bounds:
		_last_viewport_bounds = viewport_bounds
		queue_redraw()
	_animation_redraw_elapsed += delta
	if _animation_redraw_elapsed >= REDRAW_ANIMATION_INTERVAL:
		_animation_redraw_elapsed = 0.0
		queue_redraw()


func _physics_process(_delta: float) -> void:
	if _get_gameplay_tile_bounds() != _collision_viewport_bounds:
		_schedule_collision_rebuild()
