extends Node

class_name CraftingComponent

"""
CraftingComponent: Inventory and recipe crafting service owned by a player.
It communicates craft requests/results through SignalBus while exposing a
small storage API used by pickups, machines, and StorageCrates.
"""

signal inventory_changed(item_id: String, count: int)

var signal_bus: SignalBus
var recipe_registry: RecipeRegistry
var item_registry: ItemRegistry
var inventory: Dictionary = {}

func _ready() -> void:
	if signal_bus == null:
		signal_bus = SignalBus.get_instance()
	if recipe_registry == null:
		recipe_registry = RecipeRegistry.get_instance()
	if item_registry == null:
		item_registry = ItemRegistry.get_instance()
	if not signal_bus.craft_requested.is_connected(_on_craft_requested):
		signal_bus.craft_requested.connect(_on_craft_requested)

func _exit_tree() -> void:
	if signal_bus != null and signal_bus.craft_requested.is_connected(_on_craft_requested):
		signal_bus.craft_requested.disconnect(_on_craft_requested)

func _on_craft_requested(recipe_id: String) -> void:
	var success: bool = craft(recipe_id)
	if signal_bus != null:
		signal_bus.craft_completed.emit(recipe_id, success)

func craft(recipe_id: String) -> bool:
	if recipe_registry == null or not recipe_registry.has_recipe(recipe_id):
		return false
	var recipe: RecipeDef = recipe_registry.get_recipe(recipe_id)
	if recipe == null or not has_items(recipe.ingredients):
		return false
	for ingredient_variant: Variant in recipe.ingredients.keys():
		var ingredient_id: String = str(ingredient_variant)
		var required: int = int(recipe.ingredients[ingredient_variant])
		remove_item(ingredient_id, required)
	add_item(recipe.output_item_id, recipe.output_count)
	return true

func add_item(item_id: String, count: int = 1) -> bool:
	if count <= 0 or item_id.is_empty():
		return false
	if item_registry != null and not item_registry.validate_item_id(item_id):
		return false
	var new_count: int = get_inventory_count(item_id) + count
	inventory[item_id] = new_count
	inventory_changed.emit(item_id, new_count)
	return true

func remove_item(item_id: String, count: int = 1) -> bool:
	if count <= 0 or item_id.is_empty():
		return false
	var current: int = get_inventory_count(item_id)
	if current < count:
		return false
	var new_count: int = current - count
	if new_count == 0:
		inventory.erase(item_id)
	else:
		inventory[item_id] = new_count
	inventory_changed.emit(item_id, new_count)
	return true

func has_items(ingredients: Dictionary) -> bool:
	for item_variant: Variant in ingredients.keys():
		var item_id: String = str(item_variant)
		var required: int = int(ingredients[item_variant])
		if get_inventory_count(item_id) < required:
			return false
	return true

func get_inventory_count(item_id: String) -> int:
	return int(inventory.get(item_id, 0))

func get_inventory() -> Dictionary:
	return inventory.duplicate(true)

func get_all_items() -> Dictionary:
	return get_inventory()
