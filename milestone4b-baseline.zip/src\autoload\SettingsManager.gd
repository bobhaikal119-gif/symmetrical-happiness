extends Node

## Persistent settings service. Deliberately no class_name: the autoload owns this name.
## Only this service writes ConfigFile/InputMap; consumers react through SignalBus.
const SETTINGS_PATH: String = "user://settings.cfg"
const DEFAULTS: Dictionary = {
	"general": {"screen_shake": 1.0, "floating_popups": true, "auto_pause": true, "hud_scale": 1.0},
	"profile": {"pioneer_name": "Pioneer", "suit_color": Color.WHITE},
	"graphics": {"window_mode": 0, "vsync": true, "ambient_darkness": 0.0, "pixel_snap": true},
	"optimization": {"render_distance": 64, "lighting_quality": 0, "max_particles": 96, "fps_limit": 60, "performance_overlay": false},
	"mouse": {"smart_cursor": false, "aim_smoothing": 0.0, "swap_buttons": false},
	"keybinds": {},
}
const DEFAULT_KEYS: Dictionary = {
	"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
	"move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN],
	"jump": [KEY_SPACE], "mine_primary": [KEY_Q], "place_heater": [KEY_E],
	"toggle_crafting": [KEY_C, KEY_TAB], "toggle_smart_cursor": [KEY_CTRL],
	"interact": [KEY_F], "flashlight_toggle": [KEY_L],
	"hotbar_1": [KEY_1], "hotbar_2": [KEY_2], "hotbar_3": [KEY_3],
	"hotbar_4": [KEY_4], "hotbar_5": [KEY_5], "hotbar_6": [KEY_6],
	"hotbar_7": [KEY_7], "hotbar_8": [KEY_8], "hotbar_9": [KEY_9],
}
const ACTION_ALIASES: Dictionary = {"jump": "ui_jump", "mine_primary": "mine", "toggle_crafting": "craft"}

var config: ConfigFile = ConfigFile.new()
var settings: Dictionary = {}
var settings_menu_open: bool = false
var crafting_menu_open: bool = false
var active_world_seed: int = 12345
var _bus: SignalBus


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_bus = SignalBus.get_instance()
	_bus.settings_menu_toggled.connect(_on_settings_menu_toggled)
	_bus.crafting_menu_toggled.connect(_on_crafting_menu_toggled)
	load_settings()


func save_settings() -> void:
	config.clear()
	for section: String in settings:
		var entries: Dictionary = settings[section]
		for key: String in entries:
			config.set_value(section, key, entries[key])
	var error: Error = config.save(SETTINGS_PATH)
	if error != OK:
		_bus.show_hud_hint.emit("Settings could not be saved (error %d)." % error)


func load_settings() -> void:
	settings = DEFAULTS.duplicate(true)
	var error: Error = config.load(SETTINGS_PATH)
	if error == OK:
		for section: String in DEFAULTS:
			if section == "keybinds":
				continue
			var defaults: Dictionary = DEFAULTS[section]
			for key: String in defaults:
				settings[section][key] = _sanitize(section, key, config.get_value(section, key, defaults[key]))
	_ensure_actions()
	for action: String in DEFAULT_KEYS:
		var stored: Variant = config.get_value("keybinds", action, []) if error == OK else []
		var bindings: Array = _validated_bindings(stored)
		if bindings.is_empty():
			bindings = _default_bindings(action)
		settings["keybinds"][action] = bindings
		_apply_key_bindings(StringName(action), bindings)
	_apply_mouse_bindings()
	_apply_engine_settings()
	_broadcast_all()
	if error != OK and error != ERR_FILE_NOT_FOUND:
		_bus.show_hud_hint.emit("Unreadable settings replaced with safe defaults.")
	save_settings()


func reset_to_defaults() -> void:
	settings = DEFAULTS.duplicate(true)
	_ensure_actions()
	for action: String in DEFAULT_KEYS:
		var bindings: Array = _default_bindings(action)
		settings["keybinds"][action] = bindings
		_apply_key_bindings(StringName(action), bindings)
	_apply_mouse_bindings()
	_apply_engine_settings()
	_broadcast_all()
	save_settings()


func reset_keybinds() -> void:
	for action: String in DEFAULT_KEYS:
		var bindings: Array = _default_bindings(action)
		settings["keybinds"][action] = bindings
		_apply_key_bindings(StringName(action), bindings)
		_bus.setting_changed.emit("keybinds", action, bindings)
	_bus.keybinds_updated.emit()
	save_settings()


func rebind_key(action_name: StringName, new_event: InputEventKey) -> void:
	var action: String = String(action_name)
	if not DEFAULT_KEYS.has(action) or new_event == null:
		return
	var code: int = int(new_event.physical_keycode if new_event.physical_keycode != KEY_NONE else new_event.keycode)
	if code == KEY_NONE or code == KEY_ESCAPE:
		return
	var binding: Dictionary = {
		"physical": int(new_event.physical_keycode), "keycode": int(new_event.keycode),
		"ctrl": new_event.ctrl_pressed and code != KEY_CTRL,
		"alt": new_event.alt_pressed and code != KEY_ALT,
		"shift": new_event.shift_pressed and code != KEY_SHIFT,
		"meta": new_event.meta_pressed and code != KEY_META,
	}
	var conflicts: PackedStringArray = get_key_conflicts(action_name, new_event)
	settings["keybinds"][action] = [binding]
	_apply_key_bindings(action_name, [binding])
	_bus.setting_changed.emit("keybinds", action, [binding])
	_bus.keybinds_updated.emit()
	if not conflicts.is_empty():
		_bus.show_hud_hint.emit("Key conflict: also bound to %s" % ", ".join(conflicts))
	save_settings()


func get_setting(section: String, key: String, default_val: Variant) -> Variant:
	var entries: Dictionary = settings.get(section, {})
	return entries.get(key, default_val)


func set_setting(section: String, key: String, value: Variant) -> void:
	if section == "keybinds":
		if not DEFAULT_KEYS.has(key):
			return
		var bindings: Array = _validated_bindings(value)
		if bindings.is_empty():
			return
		settings[section][key] = bindings
		_apply_key_bindings(StringName(key), bindings)
		_bus.setting_changed.emit(section, key, bindings)
		_bus.keybinds_updated.emit()
		save_settings()
		return
	if not DEFAULTS.has(section) or not DEFAULTS[section].has(key):
		return
	var sanitized: Variant = _sanitize(section, key, value)
	if get_setting(section, key, null) == sanitized:
		return
	settings[section][key] = sanitized
	if section == "graphics" or (section == "optimization" and key == "fps_limit"):
		_apply_engine_settings()
	if section == "mouse" and key == "swap_buttons":
		_apply_mouse_bindings()
	_bus.setting_changed.emit(section, key, sanitized)
	if section == "mouse" and key == "smart_cursor":
		_bus.smart_cursor_toggled.emit(bool(sanitized))
	save_settings()


func get_key_label(action_name: StringName) -> String:
	var labels: PackedStringArray = []
	if not InputMap.has_action(action_name):
		return "Unbound"
	for event: InputEvent in InputMap.action_get_events(action_name):
		if event is InputEventKey:
			var key: InputEventKey = event as InputEventKey
			var code: int = key.get_physical_keycode_with_modifiers() if key.physical_keycode != KEY_NONE else key.get_keycode_with_modifiers()
			labels.append(OS.get_keycode_string(code))
	return " / ".join(labels) if not labels.is_empty() else "Unbound"


func get_key_conflicts(action_name: StringName, event: InputEventKey) -> PackedStringArray:
	var conflicts: PackedStringArray = []
	var code: int = int(event.physical_keycode if event.physical_keycode != KEY_NONE else event.keycode)
	for action: String in DEFAULT_KEYS:
		if action == String(action_name):
			continue
		for existing: InputEvent in InputMap.action_get_events(StringName(action)):
			if existing is not InputEventKey:
				continue
			var key: InputEventKey = existing as InputEventKey
			var existing_code: int = int(key.physical_keycode if key.physical_keycode != KEY_NONE else key.keycode)
			if code == existing_code and (code == KEY_CTRL or event.ctrl_pressed == key.ctrl_pressed) and (code == KEY_ALT or event.alt_pressed == key.alt_pressed) and (code == KEY_SHIFT or event.shift_pressed == key.shift_pressed) and (code == KEY_META or event.meta_pressed == key.meta_pressed):
				conflicts.append(action)
				break
	return conflicts


func is_gameplay_input_blocked() -> bool:
	return settings_menu_open or crafting_menu_open


func _unhandled_input(event: InputEvent) -> void:
	if is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if event.is_action_pressed("toggle_smart_cursor"):
		set_setting("mouse", "smart_cursor", not bool(get_setting("mouse", "smart_cursor", false)))
		get_viewport().set_input_as_handled()


func _ensure_actions() -> void:
	for action: String in DEFAULT_KEYS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
	for alias: String in ACTION_ALIASES.values():
		if not InputMap.has_action(alias):
			InputMap.add_action(alias)
	if not InputMap.has_action("place_secondary"):
		InputMap.add_action("place_secondary")


func _default_bindings(action: String) -> Array:
	var bindings: Array = []
	for code: int in DEFAULT_KEYS[action]:
		bindings.append({"physical": code, "keycode": 0, "ctrl": false, "alt": false, "shift": false, "meta": false})
	return bindings


func _validated_bindings(value: Variant) -> Array:
	var result: Array = []
	if value is not Array:
		return result
	for entry: Variant in value:
		if entry is not Dictionary:
			continue
		var code: Variant = entry.get("physical", 0)
		var logical: Variant = entry.get("keycode", 0)
		if code is not int or logical is not int or int(code) < 0 or int(logical) < 0:
			continue
		if (int(code) == 0 and int(logical) == 0) or int(code) == KEY_ESCAPE or int(logical) == KEY_ESCAPE:
			continue
		var clean: Dictionary = {"physical": int(code), "keycode": int(logical)}
		for modifier: String in ["ctrl", "alt", "shift", "meta"]:
			clean[modifier] = bool(entry.get(modifier, false))
		result.append(clean)
	return result


func _apply_key_bindings(action: StringName, bindings: Array) -> void:
	_replace_keyboard_events(action, bindings)
	var alias: String = String(ACTION_ALIASES.get(String(action), ""))
	if not alias.is_empty():
		_replace_keyboard_events(StringName(alias), bindings)


func _replace_keyboard_events(action: StringName, bindings: Array) -> void:
	for existing: InputEvent in InputMap.action_get_events(action):
		if existing is InputEventKey:
			InputMap.action_erase_event(action, existing)
	for binding: Dictionary in bindings:
		var event := InputEventKey.new()
		event.physical_keycode = int(binding["physical"]) as Key
		event.keycode = int(binding["keycode"]) as Key
		event.ctrl_pressed = bool(binding.get("ctrl", false))
		event.alt_pressed = bool(binding.get("alt", false))
		event.shift_pressed = bool(binding.get("shift", false))
		event.meta_pressed = bool(binding.get("meta", false))
		InputMap.action_add_event(action, event)


func _apply_mouse_bindings() -> void:
	var swapped: bool = bool(get_setting("mouse", "swap_buttons", false))
	for action: String in ["mine_primary", "mine", "place_secondary"]:
		for existing: InputEvent in InputMap.action_get_events(action):
			if existing is InputEventMouseButton:
				var mouse: InputEventMouseButton = existing as InputEventMouseButton
				if mouse.button_index == MOUSE_BUTTON_LEFT or mouse.button_index == MOUSE_BUTTON_RIGHT:
					InputMap.action_erase_event(action, existing)
		var event := InputEventMouseButton.new()
		var is_mining: bool = action != "place_secondary"
		event.button_index = MOUSE_BUTTON_RIGHT if is_mining == swapped else MOUSE_BUTTON_LEFT
		InputMap.action_add_event(action, event)


func _apply_engine_settings() -> void:
	Engine.max_fps = int(get_setting("optimization", "fps_limit", 60))
	var snap: bool = bool(get_setting("graphics", "pixel_snap", true))
	get_viewport().snap_2d_transforms_to_pixel = snap
	get_viewport().snap_2d_vertices_to_pixel = snap
	if DisplayServer.get_name() == "headless":
		return
	var fullscreen: bool = int(get_setting("graphics", "window_mode", 0)) == 1
	if fullscreen:
		DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, true)
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
		DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, false)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if bool(get_setting("graphics", "vsync", true)) else DisplayServer.VSYNC_DISABLED)


func _sanitize(section: String, key: String, value: Variant) -> Variant:
	var fallback: Variant = DEFAULTS[section][key]
	if fallback is bool:
		return value if value is bool else fallback
	if fallback is Color:
		if value is Color:
			var color: Color = value
			return Color(clampf(color.r, 0.0, 1.0), clampf(color.g, 0.0, 1.0), clampf(color.b, 0.0, 1.0), 1.0)
		return fallback
	if fallback is String:
		return str(value).strip_edges().left(32) if not str(value).strip_edges().is_empty() else fallback
	if value is not float and value is not int:
		return fallback
	var number: float = float(value)
	if not is_finite(number):
		return fallback
	match section + "/" + key:
		"general/screen_shake": return clampf(number, 0.0, 1.5)
		"general/hud_scale": return clampf(number, 0.75, 1.5)
		"graphics/ambient_darkness", "mouse/aim_smoothing": return clampf(number, 0.0, 1.0)
		"graphics/window_mode", "optimization/lighting_quality": return clampi(int(number), 0, 1)
		"optimization/render_distance": return clampi(int(number), 24, 128)
		"optimization/max_particles": return clampi(int(number), 0, 512)
		"optimization/fps_limit": return int(number) if int(number) in [0, 30, 60, 120] else 60
	return fallback


func _broadcast_all() -> void:
	for section: String in settings:
		for key: String in settings[section]:
			_bus.setting_changed.emit(section, key, settings[section][key])
	_bus.keybinds_updated.emit()
	_bus.smart_cursor_toggled.emit(bool(get_setting("mouse", "smart_cursor", false)))


func _on_settings_menu_toggled(is_open: bool) -> void:
	settings_menu_open = is_open


func _on_crafting_menu_toggled(is_open: bool) -> void:
	crafting_menu_open = is_open
