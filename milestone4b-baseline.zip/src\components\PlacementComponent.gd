extends Node

class_name PlacementComponent

const TILE_SIZE: int = 16
const TILE_AIR: int = 0
const TILE_SUPPORT_BEAM: int = 13
const TILE_POWER_CABLE: int = 14
const CAMP_HEATER_SCENE_PATH: String = "res://src/entities/structures/CampHeater.tscn"
const WALL_FLARE_SCENE_PATH: String = "res://src/entities/structures/WallFlare.tscn"

const MACHINE_SCENE_PATHS: Dictionary = {
	"coal_generator": "res://src/entities/machines/CoalGenerator.tscn",
	"auto_drill": "res://src/entities/machines/AutoDrill.tscn",
	"auto_turret": "res://src/entities/machines/AutoTurret.tscn",
	"storage_crate": "res://src/entities/machines/StorageCrate.tscn",
}

@export var signal_bus: SignalBus
@export var world_grid: WorldGrid
@export var player_reach: float = 64.0
@export var oxygen: OxygenComponent
@export var crafting: CraftingComponent
@export var structure_parent: Node
@export var cursor_reticle: CursorReticle
@export var hotbar_items: Array[String] = [
	"support_beam",
	"power_cable",
	"coal_generator",
	"auto_drill",
	"auto_turret",
	"storage_crate",
	"camp_heater",
	"wall_flare",
	"oxygen_canister",
]

var active_item: String = ""
var power_grid: PowerGridSystem


func _ready() -> void:
	if cursor_reticle == null and get_parent() != null:
		cursor_reticle = get_parent().get_node_or_null("CursorReticle") as CursorReticle
	_sync_cursor_mode()


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_signal_bus: SignalBus = null,
		p_crafting: CraftingComponent = null,
		p_oxygen: OxygenComponent = null,
		p_structure_parent: Node = null
) -> void:
	world_grid = p_world_grid
	power_grid = p_power_grid
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	if p_crafting != null:
		crafting = p_crafting
	if p_oxygen != null:
		oxygen = p_oxygen
	if p_structure_parent != null:
		structure_parent = p_structure_parent


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_signal_bus: SignalBus = null,
		p_crafting: CraftingComponent = null,
		p_oxygen: OxygenComponent = null,
		p_structure_parent: Node = null
) -> void:
	setup(p_world_grid, p_power_grid, p_signal_bus, p_crafting, p_oxygen, p_structure_parent)


func select_item(item_id: String) -> void:
	active_item = item_id
	_sync_cursor_mode()


func select_hotbar_slot(slot: int) -> bool:
	if slot < 0 or slot >= hotbar_items.size():
		return false
	select_item(hotbar_items[slot])
	return true


func _unhandled_input(event: InputEvent) -> void:
	if SettingsManager.is_gameplay_input_blocked() or (event is InputEventKey and (event as InputEventKey).echo):
		return
	if _handle_hotbar_input(event):
		get_viewport().set_input_as_handled()
		return
	if active_item.is_empty() or not (event.is_action_pressed("place_secondary") or event.is_action_pressed("place_heater")):
		return
	var player: Node2D = get_parent() as Node2D
	if player == null:
		return
	_sync_cursor_mode()
	var world_pos: Vector2 = player.global_position if active_item == "oxygen_canister" else player.get_global_mouse_position()
	if cursor_reticle != null and active_item != "oxygen_canister":
		cursor_reticle.world_grid = world_grid
		var target: Vector2i = cursor_reticle.get_build_target(player_reach)
		world_pos = cursor_reticle.grid_to_world(target)
		if active_item != "oxygen_canister" and not cursor_reticle.is_build_target_valid(target, player_reach):
			_show_hint("Out of reach" if not cursor_reticle.is_target_in_reach(target, player_reach) else "Choose an empty tile away from the player")
			get_viewport().set_input_as_handled()
			return
	if not _is_within_reach(_world_to_grid(world_pos)):
		_show_hint("Out of reach")
	else:
		deploy_item(active_item, world_pos)
	get_viewport().set_input_as_handled()


func deploy_item(item_id: String, world_pos: Vector2) -> bool:
	if item_id.is_empty() or not _has_inventory_item(item_id):
		return false
	var target_grid: Vector2i = _world_to_grid(world_pos)
	if not _is_within_reach(target_grid):
		return false

	if item_id == "oxygen_canister":
		return _use_oxygen_canister(item_id, target_grid)

	var tile_id: int = _item_to_tile_id(item_id)
	if tile_id >= 0:
		return _place_tile(item_id, tile_id, target_grid)

	if MACHINE_SCENE_PATHS.has(item_id):
		return _place_machine(item_id, target_grid)

	if item_id == "camp_heater" or item_id == "wall_flare":
		return _place_legacy_structure(item_id, target_grid)

	return false


func _use_oxygen_canister(item_id: String, target_grid: Vector2i) -> bool:
	if oxygen == null or not oxygen.has_method("restore_oxygen"):
		return false
	if not _consume_inventory_item(item_id):
		return false
	oxygen.restore_oxygen(50.0)
	_emit_structure_placed(target_grid, item_id)
	return true


func _place_tile(item_id: String, tile_id: int, target_grid: Vector2i) -> bool:
	if not _can_place_structure_at(target_grid):
		return false
	var previous_tile: int = world_grid.get_tile(target_grid.x, target_grid.y)

	world_grid.set_tile(target_grid.x, target_grid.y, tile_id)
	if world_grid.get_tile(target_grid.x, target_grid.y) != tile_id:
		return false
	if not _consume_inventory_item(item_id):
		world_grid.set_tile(target_grid.x, target_grid.y, previous_tile)
		return false

	if tile_id == TILE_POWER_CABLE and power_grid != null:
		power_grid.recalculate_networks()
	_get_signal_bus().tile_placed.emit(target_grid, tile_id)
	_emit_structure_placed(target_grid, item_id)
	return true


func _place_machine(item_id: String, target_grid: Vector2i) -> bool:
	if not _can_place_structure_at(target_grid):
		return false
	if item_id == "auto_drill" and not _has_adjacent_ore(target_grid):
		_show_hint("Auto-Drill must be adjacent to an ore vein")
		return false
	var scene_path: String = String(MACHINE_SCENE_PATHS[item_id])
	var machine_scene: PackedScene = load(scene_path) as PackedScene
	if machine_scene == null or not machine_scene.can_instantiate():
		return false
	var machine: Node2D = machine_scene.instantiate() as Node2D
	if machine == null:
		return false

	if machine.has_method("setup"):
		machine.call("setup", world_grid, power_grid, target_grid, _get_signal_bus())
	else:
		machine.set("grid_pos", target_grid)
	machine.set_meta(&"grid_pos", target_grid)
	machine.add_to_group(&"placed_structures")

	var parent_for_structure: Node = _get_structure_parent()
	if parent_for_structure == null:
		machine.free()
		return false
	machine.position = _grid_to_world(target_grid)
	parent_for_structure.add_child(machine)
	machine.global_position = _grid_to_world(target_grid)

	if not _consume_inventory_item(item_id):
		machine.free()
		return false
	_emit_structure_placed(target_grid, item_id)
	return true


func _place_legacy_structure(item_id: String, target_grid: Vector2i) -> bool:
	if not _can_place_structure_at(target_grid):
		return false
	var parent_for_structure: Node = _get_structure_parent()
	if parent_for_structure == null:
		return false
	var structure: Node2D
	if item_id == "camp_heater":
		structure = _instantiate_camp_heater(target_grid)
	else:
		structure = _instantiate_wall_flare()
	if structure == null:
		return false
	structure.set_meta(&"grid_pos", target_grid)
	structure.add_to_group(&"placed_structures")
	structure.position = _grid_to_world(target_grid)
	parent_for_structure.add_child(structure)
	structure.global_position = _grid_to_world(target_grid)
	if not _consume_inventory_item(item_id):
		structure.free()
		return false
	_emit_structure_placed(target_grid, item_id)
	return true


func _instantiate_camp_heater(target_grid: Vector2i) -> Node2D:
	var heater_scene: PackedScene = load(CAMP_HEATER_SCENE_PATH) as PackedScene
	if heater_scene == null or not heater_scene.can_instantiate():
		return null
	var heater: Node2D = heater_scene.instantiate() as Node2D
	if heater == null:
		return null
	heater.position = _grid_to_world(target_grid)
	if heater.has_method("setup"):
		heater.call("setup", target_grid, world_grid, power_grid)
	return heater


func _instantiate_wall_flare() -> Node2D:
	var flare_scene: PackedScene = load(WALL_FLARE_SCENE_PATH) as PackedScene
	if flare_scene == null or not flare_scene.can_instantiate():
		return null
	return flare_scene.instantiate() as Node2D


func _can_place_structure_at(target_grid: Vector2i) -> bool:
	if world_grid == null or not world_grid.is_valid_position(target_grid.x, target_grid.y):
		return false
	if not _is_within_reach(target_grid) or _overlaps_player(target_grid):
		return false
	if world_grid.get_tile(target_grid.x, target_grid.y) != TILE_AIR:
		return false
	if not is_inside_tree():
		return true
	for candidate: Node in get_tree().get_nodes_in_group("machines"):
		var candidate_grid_value: Variant = candidate.get("grid_pos")
		if candidate_grid_value is Vector2i and candidate_grid_value == target_grid:
			return false
	for candidate: Node in get_tree().get_nodes_in_group("placed_structures"):
		var candidate_grid_value: Variant = candidate.get_meta(&"grid_pos", Vector2i(-1, -1))
		if candidate_grid_value is Vector2i and candidate_grid_value == target_grid:
			return false
	return true


func _has_adjacent_ore(target_grid: Vector2i) -> bool:
	if world_grid == null:
		return false
	for y_offset in range(-1, 2):
		for x_offset in range(-1, 2):
			if x_offset == 0 and y_offset == 0:
				continue
			var check_pos := target_grid + Vector2i(x_offset, y_offset)
			var tile_id: int = world_grid.get_tile(check_pos.x, check_pos.y)
			if tile_id >= WorldGrid.TILE_IRON_ORE and tile_id <= WorldGrid.TILE_BIOLUME_STONE:
				return true
	return false


func _item_to_tile_id(item_id: String) -> int:
	match item_id:
		"support_beam":
			return TILE_SUPPORT_BEAM
		"power_cable":
			return TILE_POWER_CABLE
		_:
			return -1


func _has_inventory_item(item_id: String) -> bool:
	if crafting == null:
		return true
	return crafting.get_inventory_count(item_id) > 0


func _consume_inventory_item(item_id: String) -> bool:
	if crafting == null:
		return true
	return crafting.remove_item(item_id, 1)


func _emit_structure_placed(target_grid: Vector2i, item_id: String) -> void:
	var bus: SignalBus = _get_signal_bus()
	if bus != null:
		bus.structure_placed.emit(target_grid, item_id)


func _get_signal_bus() -> SignalBus:
	if signal_bus != null:
		return signal_bus
	return SignalBus.get_instance()


func _show_hint(message: String) -> void:
	var bus: SignalBus = _get_signal_bus()
	if bus != null:
		bus.show_hud_hint.emit(message)


func _handle_hotbar_input(event: InputEvent) -> bool:
	for slot: int in range(mini(hotbar_items.size(), 9)):
		if event.is_action_pressed(StringName("hotbar_%d" % (slot + 1))):
			return select_hotbar_slot(slot)
	return false


func _sync_cursor_mode() -> void:
	if cursor_reticle != null:
		cursor_reticle.build_mode = not active_item.is_empty() and active_item != "oxygen_canister"
		cursor_reticle.building_reach = player_reach


func _is_within_reach(target_grid: Vector2i) -> bool:
	# Standalone/programmatic services have no player origin and retain their
	# existing deployment API. Player-owned deployments must obey tool reach.
	var player: Node2D = get_parent() as Node2D
	return player == null or player.global_position.distance_to(_grid_to_world(target_grid)) <= player_reach


func _overlaps_player(target_grid: Vector2i) -> bool:
	if cursor_reticle != null:
		return cursor_reticle.overlaps_player(target_grid)
	var player: Node2D = get_parent() as Node2D
	if player == null:
		return false
	var collision: CollisionShape2D = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision == null or collision.shape == null:
		return false
	var bounds: Rect2 = collision.global_transform * collision.shape.get_rect()
	return bounds.intersects(Rect2(Vector2(target_grid * TILE_SIZE), Vector2.ONE * TILE_SIZE))


func _get_structure_parent() -> Node:
	if is_instance_valid(structure_parent):
		return structure_parent
	var player: Node = get_parent()
	if player != null and player.get_parent() != null:
		return player.get_parent()
	if get_tree() != null and get_tree().current_scene != null:
		return get_tree().current_scene
	return get_tree().root if get_tree() != null else null


func _world_to_grid(world_pos: Vector2) -> Vector2i:
	return Vector2i(floori(world_pos.x / TILE_SIZE), floori(world_pos.y / TILE_SIZE))


func _grid_to_world(target_grid: Vector2i) -> Vector2:
	return Vector2(target_grid * TILE_SIZE) + Vector2(TILE_SIZE * 0.5, TILE_SIZE * 0.5)
