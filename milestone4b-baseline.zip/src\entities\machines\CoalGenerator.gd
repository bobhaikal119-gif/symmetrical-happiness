extends StaticBody2D

class_name CoalGenerator

const TILE_SIZE: int = 16
const COAL_ITEM_ID: String = "coal"
const RATED_POWER_OUTPUT: float = 100.0
const POWER_OUTPUT_WATTS: float = RATED_POWER_OUTPUT
const PROCEDURAL_LIGHT_TEXTURE = preload("res://src/presentation/ProceduralLightTexture.gd")

@export var world_grid: WorldGrid
@export var signal_bus: SignalBus
@export var grid_pos: Vector2i = Vector2i.ZERO
@export var fuel_seconds_per_coal: float = 30.0
@export var max_coal: int = 20
@export var interaction_distance: float = 40.0
@export var auto_pull_interval: float = 1.0
@export var max_health: float = 120.0

var power_output: float = 0.0
var power_grid: PowerGridSystem
var coal_count: int = 0
var health: float = 120.0
var active: bool = true

var _burn_time_remaining: float = 0.0
var _pull_time_remaining: float = 0.0
var _was_producing: bool = false
var _registered_with_power_grid: bool = false
var _sprite: Sprite2D
var _light: PointLight2D


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	if _registered_with_power_grid and power_grid != null:
		power_grid.unregister_node(grid_pos)
		_registered_with_power_grid = false
	world_grid = p_world_grid
	power_grid = p_power_grid
	grid_pos = p_grid_pos
	if p_signal_bus != null:
		signal_bus = p_signal_bus
	if is_inside_tree():
		_register_power_node()
		_update_output()


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	setup(p_world_grid, p_power_grid, p_grid_pos, p_signal_bus)


func _ready() -> void:
	add_to_group("machines")
	add_to_group("base_targets")
	add_to_group("power_producers")
	health = max_health
	_ensure_scene_nodes()
	_create_procedural_sprite()
	_configure_light()
	_register_power_node()
	_update_output()


func _exit_tree() -> void:
	if _registered_with_power_grid and is_instance_valid(power_grid):
		power_grid.unregister_node(grid_pos)
	_registered_with_power_grid = false


func _process(delta: float) -> void:
	if not active:
		return

	_pull_time_remaining -= delta
	if _pull_time_remaining <= 0.0:
		_pull_time_remaining = maxf(0.1, auto_pull_interval)
		_auto_pull_coal()

	if _burn_time_remaining <= 0.0 and coal_count > 0:
		coal_count -= 1
		_burn_time_remaining = maxf(0.1, fuel_seconds_per_coal)

	if _burn_time_remaining > 0.0:
		_burn_time_remaining = maxf(0.0, _burn_time_remaining - delta)

	_update_output()


func _unhandled_input(event: InputEvent) -> void:
	if not active or not _is_interact_event(event):
		return
	var crafting: Node = _find_nearby_player_crafting()
	if crafting != null and deposit_coal(crafting) > 0:
		get_viewport().set_input_as_handled()


func deposit_coal(crafting: Node, requested_amount: int = -1) -> int:
	if crafting == null or not crafting.has_method("get_inventory_count") or not crafting.has_method("remove_item"):
		return 0
	var available: int = int(crafting.call("get_inventory_count", COAL_ITEM_ID))
	var capacity: int = maxi(0, max_coal - get_fuel_count())
	var amount: int = mini(available, capacity)
	if requested_amount >= 0:
		amount = mini(amount, requested_amount)
	if amount <= 0:
		return 0
	if not bool(crafting.call("remove_item", COAL_ITEM_ID, amount)):
		return 0
	coal_count += amount
	_update_output()
	return amount


func add_fuel(amount: int = 1) -> int:
	var accepted: int = mini(maxi(0, amount), maxi(0, max_coal - get_fuel_count()))
	coal_count += accepted
	_update_output()
	return accepted


func get_fuel_count() -> int:
	return coal_count + (1 if _burn_time_remaining > 0.0 else 0)


func is_fueled() -> bool:
	return _burn_time_remaining > 0.0 or coal_count > 0


func get_power_output() -> float:
	return power_output if active else 0.0


func is_active() -> bool:
	return active and health > 0.0 and is_fueled()


func take_damage(amount: float) -> void:
	if not active or amount <= 0.0:
		return
	health = maxf(0.0, health - amount)
	if health <= 0.0:
		active = false
		_update_output()
		queue_free()


func apply_damage(amount: float) -> void:
	take_damage(amount)


func _register_power_node() -> void:
	if power_grid != null:
		power_grid.register_node(grid_pos, power_output)
		_registered_with_power_grid = true


func _update_output() -> void:
	var producing: bool = active and is_fueled()
	power_output = RATED_POWER_OUTPUT if producing else 0.0
	if _light != null:
		_light.enabled = producing
		_light.energy = 1.15 if producing else 0.0
	if producing != _was_producing:
		_was_producing = producing
		if power_grid != null:
			power_grid.register_node(grid_pos, power_output)
			_registered_with_power_grid = true
			power_grid.recalculate_networks()


func _auto_pull_coal() -> void:
	if get_fuel_count() >= max_coal or not is_inside_tree():
		return
	for candidate: Node in get_tree().get_nodes_in_group("storage_crates"):
		if not candidate.has_method("count") or not candidate.has_method("remove_item"):
			continue
		var candidate_grid_value: Variant = candidate.get("grid_pos")
		if not candidate_grid_value is Vector2i:
			continue
		var candidate_grid: Vector2i = Vector2i(candidate_grid_value)
		if _manhattan_distance(grid_pos, candidate_grid) != 1:
			continue
		if int(candidate.call("count", COAL_ITEM_ID)) <= 0:
			continue
		if bool(candidate.call("remove_item", COAL_ITEM_ID, 1)):
			coal_count += 1
			_update_output()
			return


func _find_nearby_player_crafting() -> Node:
	var nearest_player: Node2D = null
	var nearest_distance: float = interaction_distance
	for candidate: Node in get_tree().get_nodes_in_group("player"):
		var player_2d: Node2D = candidate as Node2D
		if player_2d == null:
			continue
		var distance: float = global_position.distance_to(player_2d.global_position)
		if distance <= nearest_distance:
			nearest_distance = distance
			nearest_player = player_2d
	if nearest_player == null:
		return null
	return nearest_player.get_node_or_null("CraftingComponent")


func _is_interact_event(event: InputEvent) -> bool:
	if event is InputEventKey:
		var key_event: InputEventKey = event as InputEventKey
		return key_event.pressed and not key_event.echo and key_event.keycode == KEY_F
	return event.is_action_pressed("interact")


func _manhattan_distance(a: Vector2i, b: Vector2i) -> int:
	return absi(a.x - b.x) + absi(a.y - b.y)


func _ensure_scene_nodes() -> void:
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)

	_light = get_node_or_null("PointLight2D") as PointLight2D
	if _light == null:
		_light = PointLight2D.new()
		_light.name = "PointLight2D"
		add_child(_light)

	var collision: CollisionShape2D = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision == null:
		collision = CollisionShape2D.new()
		collision.name = "CollisionShape2D"
		add_child(collision)
	if collision.shape == null:
		var shape := RectangleShape2D.new()
		shape.size = Vector2(14.0, 14.0)
		collision.shape = shape


func _configure_light() -> void:
	if _light == null:
		return
	_light.texture = PROCEDURAL_LIGHT_TEXTURE.create_radial_texture(64)
	_light.color = Color(1.0, 0.48, 0.12, 1.0)
	_light.texture_scale = 1.35
	_light.shadow_enabled = true
	_light.enabled = false


func _create_procedural_sprite() -> void:
	if _sprite == null:
		return
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var outline := Color("20252b")
	var steel := Color("55616b")
	var steel_light := Color("7f9099")
	var brass := Color("b4772d")
	var ember := Color("ff7a24")

	for y in range(4, 14):
		for x in range(2, 14):
			image.set_pixel(x, y, outline)
	for y in range(5, 13):
		for x in range(3, 13):
			image.set_pixel(x, y, steel)
	for x in range(4, 12):
		image.set_pixel(x, 5, steel_light)
	for y in range(7, 11):
		for x in range(5, 11):
			image.set_pixel(x, y, Color("331b16"))
	image.set_pixel(7, 8, ember)
	image.set_pixel(8, 8, Color("ffd15c"))
	image.set_pixel(8, 9, ember)
	for y in range(1, 5):
		image.set_pixel(11, y, outline)
		image.set_pixel(12, y, brass)
	for x in range(3, 6):
		image.set_pixel(x, 14, outline)
	for x in range(10, 13):
		image.set_pixel(x, 14, outline)
	_sprite.texture = ImageTexture.create_from_image(image)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
