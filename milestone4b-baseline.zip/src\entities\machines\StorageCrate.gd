extends StaticBody2D

class_name StorageCrate

@export var world_grid: WorldGrid
@export var signal_bus: SignalBus
@export var grid_pos: Vector2i = Vector2i.ZERO
@export_range(1, 20, 1) var max_stacks: int = 20
@export var interaction_distance: float = 40.0
@export var max_health: float = 140.0

var items: Dictionary = {}
var power_grid: PowerGridSystem
var health: float = 140.0
var active: bool = true

var _sprite: Sprite2D


func setup(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	world_grid = p_world_grid
	power_grid = p_power_grid
	grid_pos = p_grid_pos
	if p_signal_bus != null:
		signal_bus = p_signal_bus


func configure(
		p_world_grid: WorldGrid,
		p_power_grid: PowerGridSystem,
		p_grid_pos: Vector2i,
		p_signal_bus: SignalBus = null
) -> void:
	setup(p_world_grid, p_power_grid, p_grid_pos, p_signal_bus)


func _ready() -> void:
	add_to_group("machines")
	add_to_group("base_targets")
	add_to_group("storage_crates")
	health = max_health
	_ensure_scene_nodes()
	_create_procedural_sprite()


func _unhandled_input(event: InputEvent) -> void:
	if not active or not _is_interact_event(event):
		return
	var crafting: Node = _find_nearby_player_crafting()
	if crafting == null:
		return
	var transferred: int = 0
	if _is_deposit_event(event) or items.is_empty():
		transferred = quick_deposit(crafting)
	else:
		transferred = quick_transfer(crafting)
	if transferred > 0:
		get_viewport().set_input_as_handled()


func add_item(item_id: String, amount: int = 1) -> bool:
	if not active or item_id.is_empty() or amount <= 0:
		return false
	if not items.has(item_id) and items.size() >= maxi(1, max_stacks):
		return false
	items[item_id] = count(item_id) + amount
	return true


func remove_item(item_id: String, amount: int = 1) -> bool:
	if item_id.is_empty() or amount <= 0:
		return false
	var available: int = count(item_id)
	if available < amount:
		return false
	var remainder: int = available - amount
	if remainder <= 0:
		items.erase(item_id)
	else:
		items[item_id] = remainder
	return true


func count(item_id: String) -> int:
	return int(items.get(item_id, 0))


func get_item_count(item_id: String) -> int:
	return count(item_id)


func get_items() -> Dictionary:
	return items.duplicate(true)


func get_stack_count() -> int:
	return items.size()


func quick_transfer(crafting: Node) -> int:
	if crafting == null or not crafting.has_method("add_item"):
		return 0
	var transferred: int = 0
	var item_ids: Array = items.keys()
	for item_id_value: Variant in item_ids:
		var item_id: String = String(item_id_value)
		var amount: int = count(item_id)
		if amount <= 0:
			continue
		if bool(crafting.call("add_item", item_id, amount)):
			transferred += amount
			items.erase(item_id)
	return transferred


func quick_deposit(crafting: Node) -> int:
	if crafting == null or not crafting.has_method("remove_item"):
		return 0
	var inventory: Dictionary = {}
	if crafting.has_method("get_all_items"):
		inventory = crafting.call("get_all_items") as Dictionary
	elif crafting.has_method("get_inventory"):
		inventory = crafting.call("get_inventory") as Dictionary
	var transferred: int = 0
	for item_id_value: Variant in inventory.keys():
		var item_id: String = String(item_id_value)
		var amount: int = int(inventory[item_id_value])
		if amount <= 0 or not add_item(item_id, amount):
			continue
		if bool(crafting.call("remove_item", item_id, amount)):
			transferred += amount
		else:
			remove_item(item_id, amount)
	return transferred


func is_active() -> bool:
	return active and health > 0.0


func take_damage(amount: float) -> void:
	if not active or amount <= 0.0:
		return
	health = maxf(0.0, health - amount)
	if health <= 0.0:
		active = false
		_drop_contents()
		queue_free()


func apply_damage(amount: float) -> void:
	take_damage(amount)


func _drop_contents() -> void:
	if items.is_empty() or not is_inside_tree():
		return
	var pickup_scene: PackedScene = load("res://src/entities/items/ItemPickup.tscn") as PackedScene
	if pickup_scene == null:
		items.clear()
		return
	var offset_index: int = 0
	for item_id_value: Variant in items.keys():
		var item_id: String = String(item_id_value)
		var pickup: Node2D = pickup_scene.instantiate() as Node2D
		if pickup == null:
			continue
		if pickup.has_method("setup"):
			pickup.call("setup", item_id, count(item_id))
		get_parent().add_child(pickup)
		var angle: float = float(offset_index) * TAU / maxf(1.0, float(items.size()))
		pickup.global_position = global_position + Vector2.from_angle(angle) * 10.0
		offset_index += 1
	items.clear()


func _find_nearby_player_crafting() -> Node:
	var nearest_player: Node2D = null
	var nearest_distance: float = interaction_distance
	for candidate: Node in get_tree().get_nodes_in_group("player"):
		var player_2d: Node2D = candidate as Node2D
		if player_2d == null:
			continue
		var distance: float = global_position.distance_to(player_2d.global_position)
		if distance <= nearest_distance:
			nearest_distance = distance
			nearest_player = player_2d
	if nearest_player == null:
		return null
	return nearest_player.get_node_or_null("CraftingComponent")


func _is_interact_event(event: InputEvent) -> bool:
	if event is InputEventKey:
		var key_event: InputEventKey = event as InputEventKey
		return key_event.pressed and not key_event.echo and key_event.keycode == KEY_F
	return event.is_action_pressed("interact")


func _is_deposit_event(event: InputEvent) -> bool:
	return event is InputEventWithModifiers and (event as InputEventWithModifiers).shift_pressed


func _ensure_scene_nodes() -> void:
	_sprite = get_node_or_null("Sprite2D") as Sprite2D
	if _sprite == null:
		_sprite = Sprite2D.new()
		_sprite.name = "Sprite2D"
		add_child(_sprite)
	var collision: CollisionShape2D = get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision == null:
		collision = CollisionShape2D.new()
		collision.name = "CollisionShape2D"
		add_child(collision)
	if collision.shape == null:
		var shape := RectangleShape2D.new()
		shape.size = Vector2(14.0, 14.0)
		collision.shape = shape


func _create_procedural_sprite() -> void:
	if _sprite == null:
		return
	var image := Image.create_empty(16, 16, false, Image.FORMAT_RGBA8)
	image.fill(Color.TRANSPARENT)
	var outline := Color("242126")
	var panel := Color("775438")
	var panel_light := Color("a87846")
	var metal := Color("67747c")
	var latch := Color("d0a84f")

	for y in range(3, 14):
		for x in range(2, 14):
			image.set_pixel(x, y, outline)
	for y in range(4, 13):
		for x in range(3, 13):
			image.set_pixel(x, y, panel)
	for x in range(3, 13):
		image.set_pixel(x, 4, panel_light)
		image.set_pixel(x, 8, metal)
	for y in range(4, 13):
		image.set_pixel(3, y, metal)
		image.set_pixel(12, y, metal)
	image.set_pixel(7, 8, latch)
	image.set_pixel(8, 8, latch)
	image.set_pixel(7, 9, outline)
	image.set_pixel(8, 9, outline)
	for x in range(3, 6):
		image.set_pixel(x, 14, outline)
	for x in range(10, 13):
		image.set_pixel(x, 14, outline)
	_sprite.texture = ImageTexture.create_from_image(image)
	_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
