extends Node
class_name RecipeRegistry

## Every tier/category is declared here, never inferred from item IDs by callers.
static var _instance: RecipeRegistry
var recipes: Dictionary = {}

static func get_instance() -> RecipeRegistry:
	if not is_instance_valid(_instance):
		_instance = RecipeRegistry.new()
		_instance._initialize_recipes()
	return _instance

func _initialize_recipes() -> void:
	recipes.clear()
	_register_recipe("camp_heater", "camp_heater", 1, {"stone": 6, "coal": 4, "copper_ore": 2}, "hand", "Survival")
	_register_recipe("support_beam", "support_beam", 2, {"stone": 2, "iron_ore": 3}, "hand", "Building")
	_register_recipe("wall_flare", "wall_flare", 2, {"coal": 1, "copper_ore": 1, "quartz": 1}, "hand", "Survival")
	_register_recipe("oxygen_canister", "oxygen_canister", 1, {"iron_ore": 3, "copper_ore": 2, "quartz": 1}, "hand", "Survival")
	_register_recipe("power_cable", "power_cable", 4, {"copper_ore": 3, "quartz": 1}, "hand", "Building")
	_register_recipe("ore_smelter", "ore_smelter", 1, {"stone": 12, "iron_ore": 6, "coal": 4}, "hand", "Stations")
	_register_recipe("iron_ingot", "iron_ingot", 1, {"iron_ore": 3, "coal": 1}, "smelter", "Tools")
	_register_recipe("copper_ingot", "copper_ingot", 1, {"copper_ore": 3, "coal": 1}, "smelter", "Tools")
	_register_recipe("titanium_ingot", "titanium_ingot", 1, {"titanium": 3, "coal": 2}, "smelter", "Tools")
	_register_recipe("hull_wall", "hull_wall", 8, {"iron_ingot": 1}, "hand", "Building")
	_register_recipe("steel_plate", "steel_plate", 4, {"iron_ingot": 2}, "smelter", "Building")
	_register_recipe("reinforced_glass", "reinforced_glass", 4, {"quartz": 4, "iron_ingot": 1}, "smelter", "Building")
	_register_recipe("blast_door", "blast_door", 1, {"iron_ingot": 3, "copper_ingot": 1}, "hand", "Building")
	_register_recipe("tech_fabricator", "tech_fabricator", 1, {"iron_ingot": 6, "copper_ingot": 4, "quartz": 4}, "smelter", "Stations")
	_register_recipe("coal_generator", "coal_generator", 1, {"stone": 8, "iron_ore": 8, "copper_ore": 4, "coal": 10}, "hand", "Stations")
	_register_recipe("auto_drill", "auto_drill", 1, {"iron_ingot": 5, "copper_ingot": 3, "quartz": 3, "titanium_ingot": 1}, "fabricator", "Tools")
	_register_recipe("auto_turret", "auto_turret", 1, {"iron_ingot": 4, "copper_ingot": 3, "quartz": 4, "titanium_ingot": 1}, "fabricator", "Tools")
	_register_recipe("storage_crate", "storage_crate", 1, {"stone": 4, "iron_ore": 6, "copper_ore": 2}, "hand", "Building")
	_register_recipe("fuel_cell", "fuel_cell", 1, {"coal": 4, "copper_ingot": 1, "quartz": 1}, "fabricator", "Survival")
	_register_recipe("nano_medkit", "nano_medkit", 1, {"biolume_stone": 3, "quartz": 2}, "fabricator", "Survival")
	_register_recipe("drill_overclock_module", "drill_overclock_module", 1, {"titanium_ingot": 3, "copper_ingot": 3, "precursor_schematic": 1}, "fabricator", "Tools")
	_register_recipe("extended_o2_tank", "extended_o2_tank", 1, {"titanium_ingot": 2, "iron_ingot": 4, "precursor_schematic": 1}, "fabricator", "Survival")

func _register_recipe(recipe_id: String, output_item_id: String, count: int, ingredients: Dictionary, station: String = "hand", category: String = "Survival") -> void:
	var recipe := RecipeDef.new()
	recipe.id = recipe_id
	recipe.output_item_id = output_item_id
	recipe.output_count = count
	recipe.ingredients = ingredients.duplicate()
	recipe.station_required = station
	recipe.category = category
	recipes[recipe_id] = recipe

func get_recipe(recipe_id: String) -> RecipeDef:
	return recipes.get(recipe_id) as RecipeDef

func has_recipe(recipe_id: String) -> bool:
	return recipes.has(recipe_id)

func get_all_recipes() -> Array[RecipeDef]:
	var result: Array[RecipeDef] = []
	for recipe: RecipeDef in recipes.values():
		result.append(recipe)
	return result

func _ready() -> void:
	if recipes.is_empty():
		_initialize_recipes()
	if not is_instance_valid(_instance):
		_instance = self

func _exit_tree() -> void:
	if _instance == self:
		_instance = null
