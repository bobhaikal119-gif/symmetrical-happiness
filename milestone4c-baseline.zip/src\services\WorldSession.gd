extends Node
class_name WorldSession

## Session wiring/telemetry adapter; algorithms reside in their dedicated services.
signal game_started()
signal game_paused()
signal game_resumed()
signal game_over()
var _root: Node2D
var _grid: WorldGrid
var _power: PowerGridSystem
var _integrity: StructuralIntegritySystem
var _actor: CharacterBody2D
var _presentation: SessionPresentation
var _pause: SessionPauseController
var _bridge: WorldEventBridge
var _network: MachineNetworkCoordinator
var _last_depth: int = -1
var _checking_integrity: bool = false

func configure(composition: Node2D) -> void:
	_root = composition
	_grid = composition.get("world_grid") as WorldGrid
	_power = composition.get("power_grid") as PowerGridSystem
	_integrity = composition.get("structural_integrity") as StructuralIntegritySystem
	_actor = composition.get_node("Player") as CharacterBody2D

func start_session() -> void:
	var generator: WorldGenerator = _root.get_node("WorldGenerator") as WorldGenerator
	generator.seed = int(_root.get("world_seed"))
	generator.generate(_grid)
	_actor.global_position = _grid.find_safe_spawn()
	var renderer: WorldRenderer = _root.get_node("WorldRenderer") as WorldRenderer
	renderer.world_grid = _grid
	renderer.sync_all_tiles()
	var crafting: CraftingComponent = _actor.get_node("CraftingComponent") as CraftingComponent
	var placement: PlacementComponent = _actor.get_node("PlacementComponent") as PlacementComponent
	var oxygen: OxygenComponent = _actor.get_node("OxygenComponent") as OxygenComponent
	var mining: MiningLaserComponent = _actor.get_node("MiningLaserComponent") as MiningLaserComponent
	var cursor: CursorReticle = _actor.get_node("CursorReticle") as CursorReticle
	var economy: EconomyComponent = _actor.get_node("EconomyComponent") as EconomyComponent
	mining.world_grid = _grid
	cursor.world_grid = _grid
	(_actor.get_node("HazardDetectorComponent") as HazardDetectorComponent).world_grid = _grid
	placement.setup(_grid, _power, SignalBus.get_instance(), crafting, oxygen, _root.get_node("MachineContainer"))
	placement.economy = economy
	economy.configure(crafting, oxygen, _actor.get_node("BatteryComponent") as BatteryComponent, mining)
	_bridge = WorldEventBridge.new()
	add_child(_bridge)
	_bridge.configure(_grid, SignalBus.get_instance())
	var click_feedback := UiClickFeedback.new()
	add_child(click_feedback)
	var diagnostics := PerformanceReporter.new()
	add_child(diagnostics)
	_presentation = SessionPresentation.new()
	add_child(_presentation)
	_presentation.configure(_actor, _root.get_node("Camera2D") as Camera2D, _root.get_node("CanvasModulate") as CanvasModulate, _root.get_node("ItemContainer") as Node2D, crafting)
	_network = MachineNetworkCoordinator.new()
	add_child(_network)
	_network.configure(_grid, _power, _root.get_node("MachineContainer") as Node2D)
	_pause = SessionPauseController.new()
	add_child(_pause)
	_pause.configure(_root.get_node("SettingsMenu"))
	_pause.game_paused.connect(func() -> void: game_paused.emit())
	_pause.game_resumed.connect(func() -> void: game_resumed.emit())
	var bus: SignalBus = SignalBus.get_instance()
	bus.tile_broken.connect(_on_tile_broken)
	bus.player_died.connect(func() -> void: game_over.emit())
	_integrity.cave_in_triggered.connect(func(cell: Vector2i, collapsed: Array[Vector2i]) -> void: bus.cave_in_triggered.emit(cell, collapsed))
	(_root.get_node("StormWaveDirector") as StormWaveDirector).setup(_actor, _grid, _root.get_node("EnemyContainer"))
	GlobalGameState.reset()
	_update_telemetry()
	bus.player_spawned.emit(_actor.global_position)
	bus.inventory_snapshot_requested.emit()
	game_started.emit()

func toggle_pause() -> void:
	_pause.toggle_pause()

func set_darkness_intensity(intensity: float) -> void:
	_presentation.set_darkness_intensity(intensity)

func _on_tile_broken(cell: Vector2i, tile_id: int) -> void:
	_presentation.spawn_mined_item(cell, tile_id)
	if not _checking_integrity:
		_checking_integrity = true
		_integrity.check_tile_break(cell.x, cell.y, tile_id)
		_checking_integrity = false

func _process(_delta: float) -> void:
	if _actor != null:
		_update_telemetry()

func _update_telemetry() -> void:
	var depth: int = maxi(0, floori(_actor.global_position.y / 16.0))
	GlobalGameState.set_player_position(_actor.global_position)
	(_actor.get_node("HazardDetectorComponent") as HazardDetectorComponent).player_position = _actor.global_position
	(_actor.get_node("OxygenComponent") as OxygenComponent).set_depth(depth)
	if depth != _last_depth:
		_last_depth = depth
		SignalBus.get_instance().depth_changed.emit(depth, _grid.get_biome_at_depth(depth))
