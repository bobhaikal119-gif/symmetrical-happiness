extends Node2D

class_name CursorReticle

## Single source of smoothed aim and logical tile targets for both player tools.
const INVALID_TARGET: Vector2i = Vector2i(-1, -1)
const AUTO_COLOR: Color = Color(1.0, 0.83, 0.2)
const DIRECT_COLOR: Color = Color(0.25, 0.95, 1.0)
const INVALID_COLOR: Color = Color(1.0, 0.28, 0.28)
const NEIGHBORS: Array[Vector2i] = [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]

var world_grid: WorldGrid
var placement: PlacementComponent
@export var mining_reach: float = 64.0
@export var building_reach: float = 64.0

var build_mode: bool = false
var target_grid_pos: Vector2i = INVALID_TARGET
var target_color: Color = DIRECT_COLOR
var _aim_offset: Vector2 = Vector2.RIGHT
var _aim_initialized: bool = false
var _smart_enabled: bool = false
var _smoothing: float = 0.0
var _mining_auto_locked: bool = false
var _building_auto_locked: bool = false
var _occupied_cells: Dictionary = {}
var _occupancy_frame: int = -1


func _ready() -> void:
	process_priority = -20
	placement = get_parent().get_node_or_null("PlacementComponent") as PlacementComponent
	z_index = 50
	# Keep the cursor readable under either renderer lighting mode.
	var cursor_material := CanvasItemMaterial.new()
	cursor_material.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	material = cursor_material
	_smart_enabled = bool(SettingsManager.get_setting("mouse", "smart_cursor", false))
	_smoothing = float(SettingsManager.get_setting("mouse", "aim_smoothing", 0.0))
	var bus: SignalBus = SignalBus.get_instance()
	bus.setting_changed.connect(_on_setting_changed)
	bus.settings_menu_toggled.connect(_on_menu_toggled)
	bus.crafting_menu_toggled.connect(_on_menu_toggled)
	bus.shop_toggled.connect(func(open: bool, _npc: String) -> void: _on_menu_toggled(open))


func _process(delta: float) -> void:
	visible = world_grid != null and not SettingsManager.is_gameplay_input_blocked()
	if not visible:
		return
	update_aim(get_global_mouse_position(), delta)
	var building: bool = build_mode and not Input.is_action_pressed("mine_primary")
	var reach: float = building_reach if building else mining_reach
	target_grid_pos = get_build_target(reach) if building else get_mining_target(reach)
	var valid: bool = is_build_target_valid(target_grid_pos, reach) if building else is_mining_target_valid(target_grid_pos, reach)
	var auto_locked: bool = _building_auto_locked if building else _mining_auto_locked
	target_color = AUTO_COLOR if auto_locked and valid else DIRECT_COLOR
	if not is_target_in_reach(target_grid_pos, reach) or not valid:
		target_color = INVALID_COLOR
	queue_redraw()


func _draw() -> void:
	if target_grid_pos == INVALID_TARGET:
		return
	var center: Vector2 = to_local(grid_to_world(target_grid_pos))
	# A 15px path inset by half a pixel plus its 1px stroke covers exactly the
	# 16x16 world cell. Convert world bounds without rounding moving-player space.
	var top_left: Vector2 = to_local(Vector2(target_grid_pos * WorldGrid.TILE_SIZE) + Vector2(0.5, 0.5))
	draw_rect(Rect2(top_left, Vector2(15.0, 15.0)), target_color, false, 1.0)
	draw_line(center - Vector2(3.0, 0.0), center + Vector2(3.0, 0.0), target_color, 1.0)
	draw_line(center - Vector2(0.0, 3.0), center + Vector2(0.0, 3.0), target_color, 1.0)


func update_aim(world_position: Vector2, delta: float = 0.0, snap: bool = false) -> void:
	var desired: Vector2 = world_position - _player_position()
	if snap or not _aim_initialized or _smoothing <= 0.0:
		_aim_offset = desired
		_aim_initialized = true
	else:
		var response: float = lerpf(32.0, 5.0, _smoothing)
		_aim_offset = _aim_offset.lerp(desired, 1.0 - exp(-response * maxf(delta, 0.0)))


func get_aim_world_position() -> Vector2:
	if not _aim_initialized:
		_aim_offset = get_global_mouse_position() - _player_position()
		_aim_initialized = true
	return _player_position() + _aim_offset


func get_mining_target(reach: float = -1.0) -> Vector2i:
	return _get_target(false, mining_reach if reach < 0.0 else reach)


func get_build_target(reach: float = -1.0) -> Vector2i:
	return _get_target(true, building_reach if reach < 0.0 else reach)


func _get_target(building: bool, reach: float) -> Vector2i:
	if building:
		_building_auto_locked = false
	else:
		_mining_auto_locked = false
	var direct: Vector2i = world_to_grid(get_aim_world_position())
	# Background plating is aimed behind the actor; terrain adjacency and body
	# occupancy are irrelevant. Keep the selected-layer preview truthful.
	if building and placement != null:
		var definition: ItemDef = ItemRegistry.get_instance().get_item_def(placement.active_item)
		if definition != null and definition.place_layer == "background_wall":
			return direct
	if not _smart_enabled or world_grid == null:
		return direct
	var origin: Vector2 = _player_position()
	var direction: Vector2 = (get_aim_world_position() - origin).normalized()
	if direction.is_zero_approx():
		direction = Vector2.RIGHT
	var desired: Vector2 = origin + direction * minf(origin.distance_to(get_aim_world_position()), reach)
	var player_cell: Vector2i = world_to_grid(origin)
	var radius: int = ceili(reach / WorldGrid.TILE_SIZE) + 1
	var best: Vector2i = INVALID_TARGET
	var best_score: float = INF
	for y: int in range(player_cell.y - radius, player_cell.y + radius + 1):
		for x: int in range(player_cell.x - radius, player_cell.x + radius + 1):
			var cell := Vector2i(x, y)
			var valid: bool = is_build_target_valid(cell, reach) if building else is_mining_target_valid(cell, reach)
			if not valid or overlaps_player(cell):
				continue
			var offset: Vector2 = grid_to_world(cell) - origin
			var forward: float = offset.dot(direction)
			var lateral: float = absf(offset.cross(direction))
			if forward <= 0.0 or lateral > WorldGrid.TILE_SIZE * 0.75 + forward * 0.2:
				continue
			if building and not _has_terrain_neighbor(cell):
				continue
			if not _has_clear_path(cell):
				continue
			# Mining advances from the nearest exposed terrain. Building chooses
			# an empty neighboring cell near the intended point, never the body.
			var score: float = grid_to_world(cell).distance_to(desired) + lateral if building else forward + lateral * 3.0
			if score < best_score:
				best = cell
				best_score = score
	if best != INVALID_TARGET:
		if building:
			_building_auto_locked = true
		else:
			_mining_auto_locked = true
	return direct if best == INVALID_TARGET else best


func is_target_in_reach(cell: Vector2i, reach: float) -> bool:
	return _player_position().distance_to(grid_to_world(cell)) <= maxf(0.0, reach)


func is_mining_target_valid(cell: Vector2i, reach: float = -1.0) -> bool:
	if world_grid == null or not world_grid.is_valid_position(cell.x, cell.y):
		return false
	if not is_target_in_reach(cell, mining_reach if reach < 0.0 else reach):
		return false
	var tile: int = world_grid.get_tile(cell.x, cell.y)
	return world_grid.get_tile_max_hp(tile) > 0.0 and not world_grid.is_hazard(cell.x, cell.y)


func is_build_target_valid(cell: Vector2i, reach: float = -1.0) -> bool:
	if world_grid == null or not world_grid.is_valid_position(cell.x, cell.y):
		return false
	if not is_target_in_reach(cell, building_reach if reach < 0.0 else reach):
		return false
	if placement != null and not placement.active_item.is_empty():
		return placement.can_place_item(placement.active_item, cell)
	if world_grid.get_tile(cell.x, cell.y) != WorldGrid.TILE_AIR or overlaps_player(cell):
		return false
	_refresh_occupied_cells()
	return not _occupied_cells.has(cell)


func overlaps_player(cell: Vector2i) -> bool:
	var player: Node2D = get_parent() as Node2D
	if player == null:
		return false
	var bounds := Rect2(player.global_position - Vector2(6.0, 6.0), Vector2(12.0, 16.0))
	var collision: CollisionShape2D = player.get_node_or_null("CollisionShape2D") as CollisionShape2D
	if collision != null and collision.shape != null:
		bounds = collision.global_transform * collision.shape.get_rect()
	return bounds.intersects(Rect2(Vector2(cell * WorldGrid.TILE_SIZE), Vector2.ONE * WorldGrid.TILE_SIZE))


func _refresh_occupied_cells() -> void:
	var frame: int = Engine.get_process_frames()
	if _occupancy_frame == frame:
		return
	_occupancy_frame = frame
	_occupied_cells.clear()
	if not is_inside_tree():
		return
	for group: StringName in [&"machines", &"placed_structures"]:
		for candidate: Node in get_tree().get_nodes_in_group(group):
			var cell: Variant = candidate.get_meta(&"grid_pos", null) if group == &"placed_structures" else candidate.get("grid_pos")
			if cell is Vector2i:
				_occupied_cells[cell] = true


func _has_terrain_neighbor(cell: Vector2i) -> bool:
	for direction: Vector2i in NEIGHBORS:
		var neighbor: Vector2i = cell + direction
		var tile: int = world_grid.get_tile(neighbor.x, neighbor.y)
		if world_grid.is_solid(neighbor.x, neighbor.y) or tile == WorldGrid.TILE_SUPPORT_BEAM or tile == WorldGrid.TILE_POWER_CABLE:
			return true
	return false


func _has_clear_path(cell: Vector2i) -> bool:
	var origin: Vector2 = _player_position()
	var destination: Vector2 = grid_to_world(cell)
	var steps: int = maxi(1, ceili(origin.distance_to(destination) / (WorldGrid.TILE_SIZE * 0.25)))
	for step: int in range(1, steps):
		var check: Vector2i = world_to_grid(origin.lerp(destination, float(step) / steps))
		if check == cell:
			break
		if world_grid.is_solid(check.x, check.y):
			return false
	return true


func _player_position() -> Vector2:
	var player: Node2D = get_parent() as Node2D
	return player.global_position if player != null else global_position


func world_to_grid(world_pos: Vector2) -> Vector2i:
	return Vector2i(floori(world_pos.x / WorldGrid.TILE_SIZE), floori(world_pos.y / WorldGrid.TILE_SIZE))


func grid_to_world(cell: Vector2i) -> Vector2:
	return Vector2(cell * WorldGrid.TILE_SIZE) + Vector2.ONE * (WorldGrid.TILE_SIZE * 0.5)


func _on_setting_changed(section: String, key: String, value: Variant) -> void:
	if section == "mouse" and key == "smart_cursor":
		_smart_enabled = bool(value)
	elif section == "mouse" and key == "aim_smoothing":
		_smoothing = float(value)


func _on_menu_toggled(_is_open: bool) -> void:
	visible = not SettingsManager.is_gameplay_input_blocked() and world_grid != null
	_aim_initialized = false
