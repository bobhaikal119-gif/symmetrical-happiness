extends Node

class_name WorldGenerator

"""
Deterministic procedural generator for DEEPWELL's 512x512 strata, caves,
depth-tiered ores, and hazards. It mutates only the injected WorldGrid.
"""

@export var seed: int = 12345

const CAVE_THRESHOLD: float = 0.48
const ORE_THRESHOLD: float = 0.58
const HAZARD_THRESHOLD: float = 0.66
const SURFACE_BASE_Y: int = 24

var _surface_noise: FastNoiseLite
var _cave_noise: FastNoiseLite
var _ore_noise: FastNoiseLite
var _hazard_noise: FastNoiseLite

func _ready() -> void:
	_configure_noise()

func generate(world_grid: WorldGrid) -> void:
	if world_grid == null:
		return
	_configure_noise()
	world_grid.seed = seed
	world_grid.initialize_grid()
	world_grid.generate_strata()
	_shape_surface(world_grid)
	_carve_caves(world_grid)
	_place_ore_veins(world_grid)
	_place_hazards(world_grid)
	_place_landing_outcrop(world_grid)

func _place_landing_outcrop(world_grid: WorldGrid) -> void:
	# A small, deterministic exposed mineral seam makes the first hand-built
	# smelter reachable without granting free inventory or skipping excavation.
	var center_x: int = WorldGrid.GRID_SIZE / 2
	var surface_y: int = SURFACE_BASE_Y
	for y: int in range(8, 40):
		if world_grid.is_solid(center_x, y):
			surface_y = y
			break
	var resources: Array[int] = [WorldGrid.TILE_STONE, WorldGrid.TILE_IRON_ORE, WorldGrid.TILE_COAL, WorldGrid.TILE_COPPER, WorldGrid.TILE_QUARTZ]
	for index: int in range(resources.size()):
		for x_offset: int in range(4):
			for y_offset: int in range(3):
				world_grid.set_tile(center_x - 10 + index * 4 + x_offset, surface_y + 1 + y_offset, resources[index])

func _configure_noise() -> void:
	_surface_noise = FastNoiseLite.new()
	_surface_noise.seed = seed
	_surface_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_surface_noise.frequency = 0.018

	_cave_noise = FastNoiseLite.new()
	_cave_noise.seed = seed + 101
	_cave_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_cave_noise.fractal_type = FastNoiseLite.FRACTAL_RIDGED
	_cave_noise.fractal_octaves = 3
	_cave_noise.frequency = 0.026

	_ore_noise = FastNoiseLite.new()
	_ore_noise.seed = seed + 307
	_ore_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_ore_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_ore_noise.fractal_octaves = 3
	_ore_noise.frequency = 0.075

	_hazard_noise = FastNoiseLite.new()
	_hazard_noise.seed = seed + 701
	_hazard_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_hazard_noise.frequency = 0.045

func _shape_surface(world_grid: WorldGrid) -> void:
	for x in range(WorldGrid.GRID_SIZE):
		var height_offset: int = roundi(_surface_noise.get_noise_1d(float(x)) * 6.0)
		var surface_y: int = clampi(SURFACE_BASE_Y + height_offset, 12, 38)
		for y in range(surface_y):
			world_grid.set_tile(x, y, WorldGrid.TILE_AIR)
		world_grid.set_tile(x, surface_y, WorldGrid.TILE_SNOW)

func _carve_caves(world_grid: WorldGrid) -> void:
	for y in range(SURFACE_BASE_Y + 12, WorldGrid.GRID_SIZE):
		for x in range(WorldGrid.GRID_SIZE):
			var value: float = _cave_noise.get_noise_2d(float(x), float(y))
			if value > CAVE_THRESHOLD:
				var tile_id: int = world_grid.get_tile(x, y)
				if tile_id != WorldGrid.TILE_LAVA and tile_id != WorldGrid.TILE_ACID:
					world_grid.set_tile(x, y, WorldGrid.TILE_AIR)

func _place_ore_veins(world_grid: WorldGrid) -> void:
	for y in range(64, WorldGrid.GRID_SIZE):
		for x in range(WorldGrid.GRID_SIZE):
			var current: int = world_grid.get_tile(x, y)
			if current != WorldGrid.TILE_STONE and current != WorldGrid.TILE_DIRT and current != WorldGrid.TILE_BASALT:
				continue
			var value: float = _ore_noise.get_noise_2d(float(x), float(y))
			if value <= ORE_THRESHOLD:
				continue
			var ore_id: int = _ore_for_depth(y, value)
			if ore_id != WorldGrid.TILE_AIR:
				world_grid.set_tile(x, y, ore_id)

func _ore_for_depth(depth: int, noise_value: float) -> int:
	if depth < 96:
		return WorldGrid.TILE_COAL
	if depth < 128:
		return WorldGrid.TILE_COPPER
	if depth < 160:
		return WorldGrid.TILE_QUARTZ
	if depth < 224:
		return WorldGrid.TILE_TITANIUM if noise_value > 0.64 else WorldGrid.TILE_IRON_ORE
	return WorldGrid.TILE_BIOLUME_STONE

func _place_hazards(world_grid: WorldGrid) -> void:
	for y in range(192, WorldGrid.GRID_SIZE):
		for x in range(WorldGrid.GRID_SIZE):
			if world_grid.get_tile(x, y) != WorldGrid.TILE_AIR:
				continue
			var value: float = _hazard_noise.get_noise_2d(float(x), float(y))
			if value <= HAZARD_THRESHOLD:
				continue
			world_grid.set_tile(x, y, WorldGrid.TILE_LAVA if y >= 320 else WorldGrid.TILE_ACID)
