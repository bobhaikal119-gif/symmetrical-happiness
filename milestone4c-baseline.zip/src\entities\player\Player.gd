extends CharacterBody2D
class_name Player

## Physics orchestration only; presentation, survival and interaction are components.
@export var move_speed: float = 150.0
@export var jump_velocity: float = -330.0
@onready var sprite: Sprite2D = $Sprite2D
@onready var flashlight: PointLight2D = $Flashlight
@onready var battery: BatteryComponent = $BatteryComponent
@onready var thermal: ThermalComponent = $ThermalComponent
@onready var cursor_reticle: CursorReticle = $CursorReticle
@onready var mining_laser: MiningLaserComponent = $MiningLaserComponent
@onready var hazard_detector: HazardDetectorComponent = $HazardDetectorComponent
@onready var oxygen: OxygenComponent = $OxygenComponent
@onready var crafting: CraftingComponent = $CraftingComponent
@onready var placement: PlacementComponent = $PlacementComponent
@onready var economy: EconomyComponent = $EconomyComponent
@onready var appearance: PlayerAppearanceComponent = $PlayerAppearanceComponent
@onready var interaction: InteractionComponent = $InteractionComponent
var signal_bus: SignalBus
var _gravity: float = 980.0

func _ready() -> void:
	add_to_group("player")
	signal_bus = SignalBus.get_instance()
	_gravity = float(ProjectSettings.get_setting("physics/2d/default_gravity", 980.0))
	mining_laser.cursor_reticle = cursor_reticle
	placement.cursor_reticle = cursor_reticle
	cursor_reticle.mining_reach = mining_laser.reach_distance
	cursor_reticle.building_reach = placement.player_reach
	economy.configure(crafting, oxygen, battery, mining_laser)
	appearance.configure(self)
	interaction.configure(self)
	signal_bus.settings_menu_toggled.connect(_on_menu_toggled)
	signal_bus.crafting_menu_toggled.connect(_on_menu_toggled)
	signal_bus.shop_toggled.connect(_on_shop_toggled)

func _physics_process(delta: float) -> void:
	if SettingsManager.is_gameplay_input_blocked():
		velocity = Vector2.ZERO
		mining_laser.deactivate()
		return
	var input_axis: float = Input.get_axis("move_left", "move_right")
	velocity.x = move_toward(velocity.x, input_axis * move_speed, move_speed * 8.0 * delta)
	if not is_on_floor():
		velocity.y += _gravity * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity
	move_and_slide()

func _on_menu_toggled(is_open: bool) -> void:
	if is_open:
		velocity = Vector2.ZERO
		mining_laser.deactivate()

func _on_shop_toggled(is_open: bool, _npc_name: String) -> void:
	_on_menu_toggled(is_open)

func take_damage(amount: float) -> void:
	appearance.take_damage(amount)

func get_battery() -> BatteryComponent:
	return battery

func get_thermal() -> ThermalComponent:
	return thermal

func get_mining_laser() -> MiningLaserComponent:
	return mining_laser

func get_oxygen() -> OxygenComponent:
	return oxygen

func get_crafting() -> CraftingComponent:
	return crafting

func get_economy() -> EconomyComponent:
	return economy
