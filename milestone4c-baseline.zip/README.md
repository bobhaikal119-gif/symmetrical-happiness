# DEEPWELL — Milestone 4B

Procedural 16×16-pixel survival/mining game for **Godot 4.7.2**. Open [project.godot](<project.godot>) and run. All new visuals, window frames and click audio are generated in code; no external packages/assets are needed.

## Build a subterranean outpost

1. Mine the exposed stone/iron/coal/copper/quartz seam just below the landing area. Inventory starts empty; resources are earned, not granted.
2. Open crafting with **C / Tab**. Build an **Ore Smelter** by hand, select its owned output, close the panel and right-click/E to place it. The ghost is emerald when valid and crimson when blocked or beyond reach.
3. Stand within **80px** of a smelter to refine ingots. Craft a **Tech Fabricator** at the smelter for advanced equipment. Categories and station badges explain unavailable recipes; the component rechecks physical station range on every craft.
4. Place **Steel Plate** or **Reinforced Glass** in the foreground and **Hull Wall** behind the room interior. Background plating can be placed behind the player without creating collision.
5. A habitable room needs **12–512 connected interior cells**, a closed solid boundary, Hull Wall coverage on every interior cell, a framed boundary **Blast Door**, a **Camp Heater** and a **Wall Flare** inside. A door remains a housing boundary while open. Open tunnels, hazards, missing plating or fixtures reject housing.
6. The Quartermaster moves into a valid room, patrols its safe floor and cycles nearby doors. Interact with **F**, or right-click the NPC, to trade. Invalidating the room removes its resident; repeated scans do not duplicate residents.

### Crafting and selection

The catalog has **22 recipes** across **Tools / Building / Stations / Survival**, gated by **hand / smelter / fabricator**. Click an owned output slot to select a building item, or use a consumable/upgrade. There is no separate world-object lookup in the UI.

Default quick slots:

| Key | Item |
| --- | --- |
| 1 | Support Beam |
| 2 | Power Cable |
| 3 | Hull Wall |
| 4 | Steel Plate |
| 5 | Reinforced Glass |
| 6 | Blast Door |
| 7 | Ore Smelter |
| 8 | Camp Heater |
| 9 | Wall Flare |

Other placeable items can be selected from their crafting output slots. Foreground/structures cannot overlap actors or existing structures. Background plating may overlap them. Blast Doors open on proximity or interaction and refuse to close through an actor.

## Quartermaster credits

Sell raw minerals/crystals/ingots for their catalog value. Buy Fuel Cells, Nano-Medkits, Drill Overclock Modules, Extended O2 Tanks and Precursor Schematics. Buy prices are twice the item base value; quantities are **1–99**, and permanent upgrades install once.

- **Fuel Cell:** restore 40 battery charge when used.
- **Nano-Medkit:** restore 45 integrity when used.
- **Drill Overclock Module:** install +25% manual mining speed.
- **Extended O2 Tank:** install +50 maximum oxygen.
- **Precursor Schematic:** crafting ingredient for advanced upgrades.

Transactions require an open shop and a nearby housed Quartermaster. Ingredients, item counts and credits commit atomically with reentrant callbacks blocked. UI shows installed upgrades and disables repeat purchases. Credits/upgrades are session state and reset with the expedition; preferences remain persistent.

## Settings and controls retained from 4A

**Esc** closes an active craft/shop modal first, otherwise opens settings. Settings always pause; craft/shop use the Auto-Pause preference. Gameplay input remains blocked in any menu even if simulation continues. Rebinding Escape cancels capture before closing settings.

| Action | Default |
| --- | --- |
| Move | A/D or Left/Right |
| Jump | Space |
| Mine | Left mouse / Q |
| Place/use | Right mouse / E |
| Interact | F, or right-click the interactable |
| Crafting | C / Tab |
| Smart Cursor | Ctrl / HUD badge |
| Flashlight | L |
| Settings | Esc |

All six settings sections persist through ConfigFile to `user://settings.cfg`. Remapping replaces only keyboard events and preserves mouse input. Smart Cursor, smoothing, mouse swap, suit tint, render distance, Full/Fast lighting, FPS cap and performance snapshots remain supported.

## Architecture and visual contract

See [DESIGN.md](<DESIGN.md>) and [integration contracts](<MILESTONE4B_CONTRACTS.md>).

- [Main](<src/main/Main.gd>) is a 60-line composition root; dedicated scene services own pause, presentation budgets, network wiring, housing coordination and telemetry.
- [Player](<src/entities/player/Player.gd>) is movement/physics orchestration; appearance, typed interactions, inventory/stations and economy are components.
- All classes under [simulation](<src/simulation/WorldGrid.gd>) are RefCounted with no scene/autoload dependencies. Local world events cross a [scene adapter](<src/services/WorldEventBridge.gd>) into unchanged legacy SignalBus contracts.
- ItemDef metadata controls placement/effects/value; RecipeDef controls station/category. UI receives value snapshots/events only.
- Doors, stations and colonists share the abstract [InteractableEntity](<src/entities/structures/InteractableEntity.gd>) contract.
- [AntiSlopTheme](<src/ui/AntiSlopTheme.gd>) supplies procedural nine-slice sharp frames, teal/cream/ink palettes, all five interactive states and click signals. HUD and settings use the same pixel skin.

## Validation

Run editor import first so new global classes are registered, then the tests:

```powershell
Godot_v4.7.2-stable_win64_console.exe --headless --path . --editor --quit
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/compiler_warnings.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4b_pure.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4b_integration.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4b_transactions.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_smoke.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_input.gd
Godot_v4.7.2-stable_win64_console.exe --headless --path . --script res://tests/milestone4a_reset.gd
Godot_v4.7.2-stable_win64_console.exe --path . --rendering-method gl_compatibility --script res://tests/milestone4b_visual.gd
python tests/audit_milestone4b.py
```

[Delivery gate and evidence](<verification_report.md>). The workspace is not a Git repository, so [baseline snapshot](<milestone4b-baseline.zip>) and [generated source diff](<tests/artifacts/milestone4b_review.diff>) support review. Test-only inventory fixtures are not granted by the game.
