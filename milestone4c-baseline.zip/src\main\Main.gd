extends Node2D
class_name Main

## Composition root only. Session and housing own all gameplay algorithms.
signal game_started()
signal game_paused()
signal game_resumed()
signal game_over()

@export var world_seed: int = 12345

@onready var world_generator: WorldGenerator = $WorldGenerator as WorldGenerator
@onready var world_renderer: WorldRenderer = $WorldRenderer as WorldRenderer
@onready var player: Player = $Player as Player
@onready var camera: Camera2D = $Camera2D as Camera2D
@onready var machine_container: Node2D = $MachineContainer as Node2D
@onready var enemy_container: Node2D = $EnemyContainer as Node2D
@onready var item_container: Node2D = $ItemContainer as Node2D
@onready var npc_container: Node2D = $NpcContainer as Node2D
@onready var storm_wave_director: StormWaveDirector = $StormWaveDirector as StormWaveDirector
@onready var canvas_modulate: CanvasModulate = $CanvasModulate as CanvasModulate
@onready var world_session: WorldSession = $WorldSession as WorldSession
@onready var housing_coordinator: HousingCoordinator = $HousingCoordinator as HousingCoordinator

var world_grid: WorldGrid
var power_grid: PowerGridSystem
var structural_integrity: StructuralIntegritySystem

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	process_priority = 100
	SettingsManager.active_world_seed = world_seed
	world_grid = WorldGrid.new(world_seed, TileRegistry.get_instance().get_simulation_catalog())
	power_grid = PowerGridSystem.new()
	structural_integrity = StructuralIntegritySystem.new(world_grid)
	world_session.game_started.connect(_on_session_started)
	world_session.game_paused.connect(_on_session_paused)
	world_session.game_resumed.connect(_on_session_resumed)
	world_session.game_over.connect(_on_session_game_over)
	world_session.configure(self)
	world_session.start_session()
	housing_coordinator.configure(world_grid, machine_container, npc_container, player)

func toggle_pause() -> void:
	world_session.toggle_pause()

func set_darkness_intensity(intensity: float) -> void:
	world_session.set_darkness_intensity(intensity)

func _on_session_started() -> void:
	game_started.emit()

func _on_session_paused() -> void:
	game_paused.emit()

func _on_session_resumed() -> void:
	game_resumed.emit()

func _on_session_game_over() -> void:
	game_over.emit()
